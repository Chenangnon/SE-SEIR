#'
#' Behavior-Disease SEIR model
#'
#' Solve the B-SEIR differential system with no behavior dynamic
#'
#' @param params numerical vector of parameters of the B-SEIR system whose
#' solution is desired: it must have 15 non-negative elements, some with more
#' restricted ranges. If **\code{params}** has more than 15 elements, only the first
#' 15 are used. See Section \code{Details} for more on **\code{params}**.
#'
#' @param y0 numerical 6-vector of initial sizes of different compartments of the
#' B-SEIR model (except \eqn{R}, which is obtained by subtracting
#' \code{sum(y0)} from \eqn{N}).
#'
#' @param Horizon,timestep positive numerical scalars, the time horizon and step
#' for solving the B-SEIR system.
#'
#' @param method the integrator to use. This can be a **string** (one of
#' \code{"lsoda", "lsode", "lsodes","lsodar","vode", "daspk", "euler", "rk4",
#' "ode23", "ode45", "radau", "bdf", "bdf_d", "adams", "impAdams" or
#' "impAdams_d" ,"iteration"}), a **function** that performs integration, or
#' a **list** of class \link[deSolve]{rkMethod} (define in the package
#' \code{deSolve}).
#'
#' @param ... additional arguments passed to or from other methods. Currently,
#' only use by \code{SolveB0SEIR}: all \code{...} elements are passed to the
#' integrator. Not used by \code{B0SEIR}.
#'
#' @param verbose logical, if \code{TRUE}, information is printed during the
#' running of \code{SolveBSEIR}. Defaults to \code{getOption("verbose")}.
#'
#' @param plot logical, should the numerical BSEIR model solution be plotted?
#' If \code{TRUE}, the result is passed to \link{plot.BSEIR}.
#'
#' @param op graphical parameters for plotting the BSEIR model solution. Only
#' used if \code{plot = TRUE}.
#'
#' @param save logical, if \code{TRUE} the output is saved as a \code{.RData}
#' object with name \code{paste0(filename, suffix)}.
#' Defaults to \code{save = FALSE}. The default is \code{""} (not
#' \code{"path/to/save"})
#'
#' @param filename string, base name of the \code{.RData} file to save the output in.
#' Defaults to \code{save = "out"}. Only used when \code{save = TRUE}.
#'
#' @param path,subpath strings specifying the path (location) to save the
#' output at. The used path is given by \code{paste0(path, "/", subpath)}.
#' If the directory \code{path} does not exist, \link{dir.create} is called
#' in an attempt to create it. Likely, if there is no sub-directory \code{subpath}
#' in \code{path}, \link{dir.create} is called in an attempt to create it.
#' Only used when \code{save = TRUE}.
#'
#' @param suffix optional string giving a suffix to be added to the file name
#' (i.e. \code{filename}) of the \code{.RData} structure to be created. The saved
#' file's name (with extension) is given by \code{paste0(filename, suffix, ".RData")}.
#' Only used when \code{save = TRUE}.
#'
#' @param t numerical scalar, time point to evaluate the B-SEIR system (vector
#' of derivatives) at.
#'
#' @param y numerical vector, the values of the state variables in the B-SEIR model
#' at time \code{t}.
#'
#' @aliases SolveB0SEIR B0SEIR
#'
#' @usage
#' SolveB0SEIR (params,
#'              y0 = c(S_1 = 49998, S1 = 49998, E = 2,
#'                     Ia = 1, Is = 1, Id = 0) * N / 100000,
#'              Horizon = 300, timestep = 0.25, method = "ode45", ...,
#'              verbose = getOption("verbose"),
#'              plot = FALSE, op = NULL,
#'              save = FALSE, filename = "out", suffix = "",
#'              path = "", subpath = "")
#'
#' B0SEIR (t, y, params, ...)
#'
#' @details
#' The function \code{B0SEIR} computes the values of the derivatives in the
#' information-free B-SEIR ODE system (the model definition) at time \code{t}.
#'
#' The function \code{SolveB0SEIR} use \link[deSolve]{ode} to find/approximate
#' the B-SEIR solution corresponding to the supplied parameter values in
#' \code{params}. The argument \code{method} is passed to \link[deSolve]{ode}.
#' See \link[deSolve]{ode} for details on choosing a \code{method} (i.e.
#' an integrator).
#'
#' The parameters vector \eqn{\Theta}**\code{=params}** is defined as
#' \eqn{\Theta = (\Theta_b, \Theta_d)} where \eqn{\Theta_b} is the subset of
#' behavior-related model parameters,
#'
#' \eqn{\Theta_b = (m_{-10}, m_{10}, \kappa)},
#'
#' and \eqn{\Theta_d} is the set of other model parameters (disease-related or not),
#'
#' \eqn{\Theta_d = (\beta_0, \phi_a, \phi_s, \theta, \pi, \sigma, \gamma_a, \gamma_s, \rho_a, \rho_s, \rho_d, N)}.
#'
#' Parameters \eqn{m_{-10}} and \eqn{m_{10}} (information/disease-free level of
#' prophylactic behavior in the two sub-populations) are restricted to the open
#' \eqn{(0, 1)}; \eqn{\phi_a} and \eqn{\phi_s} (probabilities of disease
#' transmissions by different groups of infectious) are restricted to the
#' semi-open \eqn{(0, 1]}; and \eqn{\kappa} (efficiency of prophylactic
#' behavior in reducing infections), \eqn{\pi} (probability of early detection
#' of exposed individuals) and \eqn{\sigma} (proportion of symptomatic
#' infectious in the population) are restricted to the closed \eqn{[0, 1]}.
#'
#' See Baumgaertner et al. (2023) for full details on parameters and model
#' definition.
#'
#' @export B0SEIR
#' @export SolveB0SEIR
#' @importFrom deSolve ode
#'
#' @return
#'
#' \code{B0SEIR} returns a list of one element, a vector
#' containing the derivatives of \code{y} with respect to time, in the same
#' order as in \code{y0} and \code{y}. This format is imposed so that \code{B0SEIR}
#' can be directly supplied to \code{ode} (see argument \code{func} of
#' \link[deSolve]{ode}).
#'
#' \code{SolveB0SEIR} returns an object of class \code{BSEIR} which is
#' a list with the following elements:
#'
#' \item{Teval}{ vector of time points where the ODE system was evaluated at.}
#' \item{Yeval}{ matrix of model state values, rows corresponding to time points
#' in \code{Teval}.}
#' \item{Ydot}{ matrix of model state derivatives, rows corresponding to time
#' points in \code{Teval}.}
#' \item{Pt}{ vector, perceived disease prevalence, evaluated at time points in \code{Teval}.}
#' \item{Ct}{ vector, new positive/detected cases, evaluated at time points in
#' \code{Teval}.}
#' \item{Qt}{ vector, the rate of change of new positive/detected cases,
#' evaluated at time points in \code{Teval}.}
#' \item{S}{ vector, total number of susceptibles individuals in the whole
#' population, evaluated at time points in \code{Teval}.}
#' \item{m}{ matrix, proportion of prophylactic individuals, at time
#' points in \code{Teval}: one column ('m') for the whole population and one column per
#' susceptible group ('m_1', and 'm1').}
#' \item{Rep.nb}{ matrix of effective reproductive number, evaluated at time
#' points in \code{Teval}.}
#' \item{Rep.nb0}{numerical scalar, basic reproductive number.}
#' \item{N}{ numeric scalar, the total population size.}
#' \item{params}{the supplied parameter vector.}
#' \item{non.negative.params}{\code{NULL}, returned for compatibility with
#' \link{SolveBSEIR}.}
#' \item{rowdelay}{\code{NULL} (when returned by \code{SolveB0SEIR}) or an
#' integer vector indicating for each time point in \code{Teval}, the index of
#' the corresponding delayed time point.}
#' \item{hom}{ logical 7-vector, indicating if the population is homogeneous
#' with respect to parameters \eqn{a}, \eqn{b}, \eqn{v}, \eqn{d}, \eqn{e},
#' \eqn{\alpha} and \eqn{m_0}. Note that when returned by \code{SolveB0SEIR},
#' the first six elements of \code{hom} are always positive.}
#' \item{call}{the matched call to \code{SolveB0SEIR}.}
#'
#' @seealso To solve a B-SEIR differential system with behavior dynamic,
#' see \link{SolveBSEIR}.
#'
#' @note
#' A \code{BSEIR} object has methods \code{print} (see \link[BSEIR]{print.BSEIR}),
#' and \code{plot} (see \link[BSEIR]{plot.BSEIR}).
#'

SolveB0SEIR <- function (params,
                         y0 = c(S_1 = 49998, S1 = 49998, E = 2, Ia = 1, Is = 1, Id = 0) * N / 100000,
                         Horizon = 300, timestep = 0.25, method = "ode45", ...,
                         verbose = getOption("verbose"),
                         plot = FALSE, op = NULL,
                         save = FALSE, filename = "out", suffix = "",
                         path = "", subpath = "") {

  # Save the call
  mcall <- match.call()

  # Extract parameters from the vector 'params'
  m0 <- kappa <-
    beta_0 <- phi_a <- phi_s <- theta <- pi_val <- sigma <-
    gamma_a <- gamma_s <- rho_a <- rho_s <- rho_d <- N <- hom <- NULL
  eval(getB0SEIRparams())
  stopifnot(sum(y0) == N)

  # Evaluate the solution at equally spaced points between t_0 and t_f
  Teval <- seq(from = 0, to = Horizon, by = timestep) # length.out = 4 * Horizon + 1
  Teval <- unique(c(Teval, Horizon))

  # Solve the differential system with no information available
  if (verbose) {
    cat("\n                * Calling 'deSolve::ode' to solve the BSEIR system ... \n")
  }

  Sol <- deSolve::ode (y = y0, times = Teval, func = B0SEIR,
                       parms = params, method = method, ...)
  Teval <- as.matrix(Sol)[, 1]
  Yeval <- as.matrix(Sol)[, -1, drop = FALSE]

  # Get P, Q, and dotCt

  # Problem Yeval[,4] should be Yeval[,3] RIGHT?

  if (verbose) {
    cat("\n                * Computing the Jacobian matrix of the system ... \n")
  }

  Ct <- pi_val * theta * Yeval[,3] + gamma_a * Yeval[,4] + gamma_s * Yeval[,5]
  Pt <- Yeval[, 6] / N
  Ydot <- get.dotB0SEIR (y = Yeval, params = params, all = TRUE)
  dotCt <- pi_val * theta * Ydot[,3] + gamma_a * Ydot[,4] + gamma_s * Ydot[,5]
  Qt <- dotCt / Ct

  # Deduce R
  R <- N - rowSums(Yeval)

  # Compute prophylactic proportions
  S <- rowSums(Yeval[, 1:2])
  m <- colSums(m0 * t(Yeval[, 1:2])) / S

  # Compute reproduction numbers
  Rep.nb0 <- beta_0 * (1 - pi_val) * (phi_a * (1 - sigma) / (gamma_a + rho_a) +
                                 phi_s * sigma / (gamma_s + rho_s))
  Rept_1 <- Rep.nb0 * Yeval[, 1] * (1 - kappa * m0[1]) / (N - Yeval[, 6])
  Rept1 <- Rep.nb0 * Yeval[, 2] * (1 - kappa * m0[2]) / (N - Yeval[, 6])
  Rep.nb <- Rept_1 + Rept1

  # Rescale Rept_1 and Rept1
  Rept_1 <- Rept_1 * S / Yeval[, 1]
  Rept1 <- Rept1 * S / Yeval[, 2]

  # Outputs
  Yeval <- cbind(Yeval, R)
  colnames(Yeval) <- c("S_1", "S1", "E", "Ia", "Is", "Id", "R")

  m <- cbind(m, m0[1], m0[2])
  colnames(m) <- c("m", "m_1", "m1")

  Rep.nb <- cbind(Rep.nb, Rept_1, Rept1)
  colnames(Rep.nb) <- c("Rep.nb", "Rep.nb_1", "Rep.nb1")

  out <- list(Teval = Teval, Yeval = Yeval, Ydot = Ydot,
              Pt = Pt, Ct = Ct, Qt = Qt, S = S, m = m,
              rowdelay = NULL,
              Rep.nb = Rep.nb, Rep.nb0 = Rep.nb0, N = N,
              params = params,
              hom = hom, call = mcall)

  out <- structure(out, class = "BSEIR")

  if (plot) {
    if (verbose) {
      cat("\n                * Plotting the results ... \n")
    }

    out$plot <- plot.BSEIR(out, op = op)
  }

  if (save) {

    if (verbose) {
      cat("\n                * Saving the results ... \n")
    }

    ### Create directory and sub-directory to save results (if non existent)
    if (!identical(path, "")) {
      if (!dir.exists(path))
        dir.create(path)
    }

    if (identical(subpath, "")) {
      savepath <- path
    }
    else {
      if (identical(path, ""))
        savepath <- subpath
      else
        savepath <- paste0(path, "/", subpath)

      if (!dir.exists(savepath))
        dir.create(savepath)
    }

    if (identical(savepath, ""))
      savepath <- filename
    else
      savepath <- paste0(savepath, "/", filename)

    if (!identical(suffix, ""))
      savepath <- paste0(savepath, suffix)

    save(out, file = paste0(savepath, ".RData"))

  }

  return(out)

}
