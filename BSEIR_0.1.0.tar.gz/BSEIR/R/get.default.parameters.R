#
get.default.parameters <- function(N = 1e5) {
  # Disease dynamic
  beta_0 <- 2
  kappa <- 0.95
  phi_a <- 1
  phi_s <- 1
  theta <- 1/4
  pi_val <- 4/6 # Early detection of Exposed
  sigma <- 1/3

  infective_time_a <- 14 # Duration (days) of infective period for asyptomatics / or say detection window
  g_prop_a <- pi_val # Proportion of Ia detected over their infective period
  gamma_a <- g_prop_a/infective_time_a # Detecting g_prop_a of Ia, over 'infective_time' days
  rho_a <- (1 - g_prop_a)/infective_time_a # Removal: (1-g_prop_a) of Ia, over 'infective_time' days

  infective_time_s <- 14 # Duration (days) of infective period for syptomatics
  g_prop_s <- 4/10 # Proportion of Is detected over their infective period
  gamma_s <- g_prop_s/infective_time_s # Detecting g_prop_s of Is, over 'infective_time' days
  rho_s <- (1 - g_prop_s)/infective_time_s # Removal: (1-g_prop_s) of Is, over 'infective_time' days

  rho_d <- 1/30 # Removal: 100% of Id, over 20 days (from COVID-19 length of hospital stay in Eleanor . Rees et al. (2020))

  # Behavior dynamic
  m0 <- c(0.05, 0.05)
  a <- c(20, 20)
  b0 <- c(0, 0)
  v <- c(0, 0)
  d0 <- c(56.5, 56.5)
  e <- c(0, 0)
  alpha <- rep(1, length(a))
  tau <- 3

  # Build a vector of all parameters
  params <- c(tau = tau,
              a = a, #
              b0 = b0, #
              v = v, #
              d0 = d0, #
              e = e, #
              alpha = alpha, #
              m0 = m0, #
              kappa = kappa,
              beta_0 = beta_0,
              phi_a = phi_a, phi_s = phi_s,
              theta = theta,
              pi_val = pi_val,
              sigma = sigma,
              gamma_a = gamma_a, gamma_s = gamma_s,
              rho_a = rho_a, rho_s = rho_s, rho_d = rho_d,
              N = N)

  y0 <- c(49998, 49998, 2, 1, 1, 0) * N / 100000
  return(list(params = params, y0=y0))
}
