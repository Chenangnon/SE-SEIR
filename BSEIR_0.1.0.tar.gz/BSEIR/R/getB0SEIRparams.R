
getB0SEIRparams <- function() {
  expression({

    m0 <- params[1:2] #

    kappa <- params[3] #

    beta_0 <- params[4] #

    phi_a <- params[5] #

    phi_s <- params[6] #

    theta <- params[7] #

    pi_val <- params[8] #

    sigma <- params[9] #

    gamma_a <- params[10] #

    gamma_s <- params[11] #

    rho_a <- params[12] #

    rho_s <- params[13] #

    rho_d <- params[14] #

    N <- params[15] #

    # Check for homogeneity
    hom <- c(rep(TRUE, 6),
             m0[1] == m0[2])

    names(hom) <- c("a", "b", "v", "d", "e", "alpha", "m0")

  })
}
