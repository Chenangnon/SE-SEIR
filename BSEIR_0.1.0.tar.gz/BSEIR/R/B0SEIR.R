#
B0SEIR <- function(t, y, params, ...) {
  # Real state variables
  S_1 <- y[1]
  S1 <- y[2]
  E <- y[3]
  Ia <- y[4]
  Is <- y[5]
  Id <- y[6]

  # Extract parameters from the vector 'params'
  m0 <- kappa <-
    beta_0 <- phi_a <- phi_s <- theta <- pi_val <- sigma <-
    gamma_a <- gamma_s <- rho_a <- rho_s <- rho_d <- N <- hom <- NULL
  eval(getB0SEIRparams())

  # Total mixing population
  NId <- N - Id

  # Compute contact rates
  beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
  beta_is <- beta_0 * (1 - kappa * m0) * phi_s

  # Compute forces of infection
  lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
  lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

  # Initialize 'ydot'
  ydot <- numeric(6)

  # Differential equations
  ydot[1] <- -lambda_1 * S_1                                                  # dot{S}_1
  ydot[2] <- -lambda1 * S1                                                    # dot{S}1
  ydot[3] <- -ydot[1] - ydot[2] - theta * E                                   # dot{E}
  ydot[4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia  # dot{I}a
  ydot[5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is        # dot{I}s
  ydot[6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id    # dot{I}d
  #names(ydot) <- c("S_1", "S1", "E", "Ia", "Is", "Id")

  return(list(ydot = ydot))
}

# Internal routine to compute a matrix of derivatives (the differential system)
get.dotB0SEIR <- function (t, y, params, all = TRUE) {
  # Real state variables
  S_1 <- y[,1]
  S1 <- y[,2]
  E <- y[,3]
  Ia <- y[,4]
  Is <- y[,5]
  Id <- y[,6]

  # Extract parameters from the vector 'params'
  m0 <- kappa <-
    beta_0 <- phi_a <- phi_s <- theta <- pi_val <- sigma <-
    gamma_a <- gamma_s <- rho_a <- rho_s <- rho_d <- N <- hom <- NULL
  eval(getB0SEIRparams())

  # Total mixing population
  NId <- N - Id

  # Compute contact rates
  beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
  beta_is <- beta_0 * (1 - kappa * m0) * phi_s

  # Compute forces of infection
  lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
  lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

  if (all[1]) {
    # Initialize 'ydot'
    ydot <- matrix(0, nrow = NROW(y), ncol = 6)

    # Differential equations
    ydot[,1] <- -lambda_1 * S_1                                                 # dot{S}_1
    ydot[,2] <- -lambda1 * S1                                                   # dot{S}1
    ydot[,3] <- -ydot[,1] - ydot[,2] - theta * E                                # dot{E}
    ydot[,4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia # dot{I}a
    ydot[,5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is       # dot{I}s
    ydot[,6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id   # dot{I}d

    colnames(ydot) <- paste0("dot", c("S_1", "S1", "E", "Ia", "Is", "Id"))
  }
  else {
    # Initialize 'ydot'
    ydot <- matrix(0, nrow = NROW(y), ncol = 3)

    # Differential equations for Ia, Is and Id
    ydot[,1] <- lambda_1 * S_1 + lambda1 * S1 - theta * E                       # dot{E}
    ydot[,2] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia # dot{I}a
    ydot[,3] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is       # dot{I}s

    colnames(ydot) <- paste0("dot.", c("E", "Ia", "Is"))
  }

  return(ydot)
}

