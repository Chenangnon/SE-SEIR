
#'
#' Combinations of BSEIR model parameters for simulations
#'
#' Generate combinations of BSEIR model parameters under a factorial design.
#' Each combination corresponds to a specific simulation setting with a more or
#' less heterogeneous population.
#'
#' @param tau.vec numerical vector of time delays (days) in the acquisition of
#' disease risk information.
#'
#' @param a.vec,b.vec numerical vectors of linear (\eqn{a_i}) and quadratic terms
#' (\eqn{b_i}) of the response of a susceptible group \eqn{S_{i}} to perceived
#' disease prevalence (\eqn{P}). When \code{a_1.a1} is specified, \code{a.vec}
#' is ignored, and \code{b.vec} is ignored when \code{b0_1.b01} is specified.
#'
#' @param v.vec numerical vector, responsiveness (\eqn{c_i}) of \eqn{S_i} to the
#' interaction \eqn{P \times Q}. When \code{a_1.a1} is specified, \code{a.vec}
#' is ignored
#'
#' @param d.vec,e.vec numerical vectors of linear (\eqn{d_i}) and quadratic
#' terms (\eqn{e_i}) of the response of a susceptible group \eqn{S_i} to
#' the rate of change (\eqn{Q}) of new positive/detected/reported cases.
#'
#' @param b0.vec,d0.vec numerical vectors, transforms of vectors \code{b.vec}
#' and \code{d.vec}. See Section \code{Details}.
#'
#' @param alpha.vec numerical vector, strength (\eqn{\alpha_i}) of in-group
#' non-prophylactic behavior in susceptible group \eqn{S_i}.
#'
#' @param m0.vec numerical vector, information-free proportion (\eqn{m_{i0}}) of
#' prophylactic individuals in susceptible group \eqn{S_i} (i.e. in the
#' absence of risk evidence).
#'
#' @param kappa.vec numerical vector, average efficiency of prophylactic behavior
#' in protecting susceptibles against infection.
#'
#' @param beta_0.vec numerical vector, baseline contact rate, i.e. the rate of
#' contacts between susceptibles and infectious individuals when there is
#' no engagement in prophylactic behavior.
#'
#' @param phi_a.vec,phi_s.vec numerical vectors, probability of disease
#' transmission by \eqn{I_a} and \eqn{I_s} infectious, respectively.
#'
#' @param theta.vec numerical vector, 1/duration of incubation (latent) period
#' (days).
#'
#' @param pi_val.vec numerical vector, early detection probability for exposed
#' individuals.
#'
#' @param sigma.vec numerical vector, proportion of symptomatic infectious.
#'
#' @param gamma_a.vec,gamma_s.vec numerical vectors, detection rates of \eqn{I_a}
#' and \eqn{I_s} infectives.
#'
#' @param rho_a.vec,rho_s.vec,rho_d.vec numerical vectors, removal rates of
#' \eqn{I_a}, \eqn{I_s} and \eqn{I_d} infectives.
#'
#' @param S0.vec,E0.vec numerical vectors, numbers of \eqn{S_{i}} susceptibles
#' and exposed individuals (\eqn{E}) in the initial population.
#'
#' @param Ia0.vec,Is0.vec,Id0.vec numerical vectors, numbers of \eqn{I_a}, \eqn{I_s}
#' and \eqn{I_d} infectives in the initial population.
#'
#' @param a_1.a1,b0_1.b01,v_1.v1,d0_1.d01,e_1.e1,alpha_1.alpha1,m0_1.m01,S0_1.S01 character
#' vectors of doublets of the corresponding parameters (e.g. \code{a_1.a1} for \code{a.vec}).
#' For the defaults (\code{NULL}), these doublets are formed by passing the
#' corresponding parameter vector to \code{form.doublets}. When a parameter
#' vector is specified and the corresponding doublet is also given, only the
#' doublet is used (the parameter vector is ignored). Only specify these
#' arguments when you know what you are doing.
#'
#' @param only.homogeneous logical, should combinations of parameters
#' give only fully homogeneous populations? See Section \code{Details}.
#'
#' @param fully.heterogeneous logical, should combinations of parameters
#' give fully heterogeneous populations? Not used when
#' \code{only.homogeneous = TRUE}. See Section \code{Details}.
#'
#' @param sep character, separation symbol used to collapse values of parameters
#' which are susceptible group-specific. These parameters include \eqn{a}, \eqn{b},
#' \eqn{v}, \eqn{d}, \eqn{e}, \eqn{\alpha} and \eqn{m_0}. For each such model
#' parameter \eqn{\Theta}, a parameter vector has two values \eqn{\Theta_{-1}}
#' and \eqn{\Theta_{1}}. The character \code{sep} is used to collapse these two
#' values into one character. For instance, for the model parameter \eqn{\Theta = a},
#' with values \eqn{a_{-1}=50} and \eqn{a_{1} = 100}, the combined value obtained
#' using \code{sep = '+'} is \code{'50+100'}.
#'
#' @param x.vec numeric vector of the values of a parameter.
#'
#' @details
#' When \code{only.homogeneous = TRUE}, a combination of parameter will always
#' correspond to an homogeneous population with respect to all parameters
#' (i.e. both susceptible groups \eqn{S_{-1}} and \eqn{S_{1}} have the same
#' value for each group specific model parameter).
#'
#' Otherwise, if a parameter has one distinct value, both sub-populations
#' (\eqn{S_{-1}} and \eqn{S_{1}}) have this unique value and are thus
#' homogeneous with respect to that parameter.
#'
#' When a parameter has two or more distinct values, combinations of parameters
#' giving fully heterogeneous populations (with respect to all parameters) are
#' first generated. Then, if \code{fully.heterogeneous = FALSE} (the default),
#' partially heterogeneous populations (i.e. heterogeneous with respect to some
#' parameters) are also generated.
#'
#' The arguments \code{a_1.a1, b0_1.b01, v_1.v1, d0_1.d01, e_1.e1, alpha_1.alpha1, m0_1.m01, S0_1.S01}
#' are provided to allow flexibility in the combination of different parameters to be investigated.
#' Indeed, the default values of all these character arguments are obtained with
#' the same values of the arguments \code{only.homogeneous} and \code{fully.heterogeneous}.
#' This may be restrictive in some situations. The user can then call \code{form.doublets}
#' for each of the corresponding parameters separately and then pass the results
#' to \code{get.sim.scenarios}.
#'
#' The transformation of \code{b0.vec} into \code{b.vec} and \code{d0.vec} into
#' \code{d.vec} is internal to \link{SolveBSEIR}. The purpose is to allow a more
#' flexible relationship between information (\eqn{P} and \eqn{Q}) and engagement
#' or disengagement in prophylactic behaviors.The transformation depends on the
#' logical argument \code{non.negative.params} of \code{SolveBSEIR}.
#' If \code{non.negative.params = TRUE} (the default), no transformation is
#' applied (or identity transform). The actual transformation when
#' \code{non.negative.params = FALSE} is nonlinear and depends on the
#' additional arguments \code{minQ} and \code{maxQ} of \code{SolveBSEIR}
#' (see \link{SolveBSEIR}).
#'
#' @usage
#' get.sim.scenarios (tau.vec = c(1, 3, 7),
#'                    a.vec = c(0, 40, 100),
#'                    b.vec = c(0, 100, 300),
#'                    v.vec = c(0, 100, 300),
#'                    d.vec = c(0, 100, 300),
#'                    e.vec = c(0, 10, 30),
#'                    b0.vec = b.vec,
#'                    d0.vec = d.vec,
#'                    alpha.vec = c(0.1, 1, 3),
#'                    m0.vec = 0.05,
#'                    kappa.vec = c(0.5, 0.75, 1),
#'                    beta_0.vec = c(0.5, 2, 3),
#'                    phi_a.vec = 1, phi_s.vec = 1,
#'                    theta.vec = 0.25,
#'                    pi_val.vec = c(0.25, 0.5, 2/3),
#'                    sigma.vec = 0.5,
#'                    gamma_a.vec = 2/70, gamma_s.vec = 4/70,
#'                    rho_a.vec = 3/70, rho_s.vec = 1/70, rho_d.vec = 1/70,
#'                    S0.vec = 49998,
#'                    E0.vec = 2,
#'                    Ia0.vec = 1,
#'                    Is0.vec = 1,
#'                    Id0.vec = 0,
#'                    a_1.a1 = NULL, b0_1.b01 = NULL,
#'                    v_1.v1 = NULL,
#'                    d0_1.d01 = NULL, e_1.e1 = NULL,
#'                    alpha_1.alpha1 = NULL,
#'                    m0_1.m01 = NULL,
#'                    S0_1.S01 = NULL,
#'                    only.homogeneous = FALSE,
#'                    fully.heterogeneous = FALSE,
#'                    sep = "+"))
#'
#' form.doublets (x.vec, only.homogeneous, fully.heterogeneous, sep)
#'
#' @export get.sim.scenarios
#'
#' @export form.doublets
#'
#' @aliases form.doublets
#'
#' @importFrom utils combn
#'

get.sim.scenarios <- function (tau.vec = c(1, 3, 7),
                               a.vec = c(0, 40, 100),
                               b.vec = c(0, 100, 300),
                               v.vec = c(0, 100, 300),
                               d.vec = c(0, 100, 300),
                               e.vec = c(0, 10, 30),
                               b0.vec = b.vec,
                               d0.vec = d.vec,
                               alpha.vec = c(0.1, 1, 3),
                               m0.vec = 0.05,
                               kappa.vec = c(0.5, 0.75, 1),
                               beta_0.vec = c(0.5, 2, 3),
                               phi_a.vec = 1, phi_s.vec = 1,
                               theta.vec = 0.25,
                               pi_val.vec = c(0.25, 0.5, 2/3),
                               sigma.vec = 0.5,
                               gamma_a.vec = 2/70, gamma_s.vec = 4/70,
                               rho_a.vec = 3/70, rho_s.vec = 1/70, rho_d.vec = 1/70,
                               S0.vec = 49998,
                               E0.vec = 2,
                               Ia0.vec = 1,
                               Is0.vec = 1,
                               Id0.vec = 0,
                               a_1.a1 = NULL,
                               b0_1.b01 = NULL,
                               v_1.v1 = NULL,
                               d0_1.d01 = NULL,
                               e_1.e1 = NULL,
                               alpha_1.alpha1 = NULL,
                               m0_1.m01 = NULL,
                               S0_1.S01 = NULL,
                               only.homogeneous = FALSE,
                               fully.heterogeneous = FALSE,
                               sep = "+") {

  # All parameters must be numeric vectors of length 1 or more
  stopifnot(all(sapply(list(a.vec, b0.vec, v.vec, d0.vec, e.vec, alpha.vec,
                            m0.vec, kappa.vec, beta_0.vec, phi_a.vec,
                            sigma.vec, gamma_a.vec, gamma_s.vec,
                            rho_a.vec, rho_s.vec, rho_d.vec,
                            S0.vec, E0.vec, Ia0.vec, Is0.vec, Id0.vec),
                       FUN = function(x) { is.numeric(x) & length(x) })))

  # Generate doublet (a_1, a1)
  if (is.null(a_1.a1)) {
    a_1.a1 <- form.doublets (a.vec,
                             only.homogeneous = only.homogeneous,
                             fully.heterogeneous = fully.heterogeneous,
                             sep = sep)
  }

  # Generate doublet (b_1, b1)
  if (is.null(b0_1.b01)) {
    b0_1.b01 <- form.doublets (b0.vec,
                               only.homogeneous = only.homogeneous,
                               fully.heterogeneous = fully.heterogeneous,
                               sep = sep)
  }

  # Generate doublet (v_1, v1)
  if (is.null(v_1.v1)) {
    v_1.v1 <- form.doublets (v.vec,
                             only.homogeneous = only.homogeneous,
                             fully.heterogeneous = fully.heterogeneous,
                             sep = sep)
  }

  # Generate doublet (d0_1, d01)
  if (is.null(d0_1.d01)) {
    d0_1.d01 <- form.doublets (d0.vec,
                               only.homogeneous = only.homogeneous,
                               fully.heterogeneous = fully.heterogeneous,
                               sep = sep)
  }

  # Generate doublet (e_1, e1)
  if (is.null(e_1.e1)) {
    e_1.e1 <- form.doublets (e.vec,
                             only.homogeneous = only.homogeneous,
                             fully.heterogeneous = fully.heterogeneous,
                             sep = sep)
  }

  # Generate doublet (alpha_1, alpha1)
  if (is.null(alpha_1.alpha1)) {
    alpha_1.alpha1 <- form.doublets (alpha.vec,
                                     only.homogeneous = only.homogeneous,
                                     fully.heterogeneous = fully.heterogeneous,
                                     sep = sep)
  }

  # Generate doublet (m0_1, m01)
  if (is.null(m0_1.m01)) {
    m0_1.m01 <- form.doublets (m0.vec,
                               only.homogeneous = only.homogeneous,
                               fully.heterogeneous = fully.heterogeneous,
                               sep = sep)
  }

  # Generate doublet (m0_1, m01)
  if (is.null(S0_1.S01)) {
    S0_1.S01 <- form.doublets (S0.vec,
                               only.homogeneous = only.homogeneous,
                               fully.heterogeneous = fully.heterogeneous,
                               sep = sep)
  }

  scenarios <- expand.grid(tau = tau.vec,
                           a_1.a1 = a_1.a1, #
                           b0_1.b01 = b0_1.b01, #
                           v_1.v1 = v_1.v1, #
                           d0_1.d01 = d0_1.d01, #
                           e_1.e1 = e_1.e1, #
                           alpha_1.alpha1 = alpha_1.alpha1, #
                           m0_1.m01 = m0_1.m01, # ...
                           kappa = kappa.vec,
                           beta_0 = beta_0.vec,
                           phi_a = phi_a.vec, phi_s = phi_s.vec,
                           theta = theta.vec,
                           pi_val = pi_val.vec,
                           sigma = sigma.vec,
                           gamma_a = gamma_a.vec, gamma_s = gamma_s.vec,
                           rho_a = rho_a.vec, rho_s = rho_s.vec, rho_d = rho_d.vec,
                           S0 = S0_1.S01, # ...
                           E0 = E0.vec,
                           Ia0 = Ia0.vec,
                           Is0 = Is0.vec,
                           Id0 = Id0.vec)

  # drop attributes names, row.names, and out.attrs; and add a 'sep' attribute
  attributes(scenarios) <- list(names = attr(scenarios, "names"),
                                row.names = attr(scenarios, "row.names"),
                                sep = sep)

  return(
    structure(
      as.data.frame(scenarios),
      class = c("data.frame", "sim.scenarios")
    )
  )

}

form.doublets <- function (x.vec, only.homogeneous, fully.heterogeneous, sep) {
  # Generate doublet (a_1, a1)
  x.vec <- unique(x.vec)
  if (length(x.vec) > 1) {
    if (only.homogeneous) {
      # Fully Homogeneous Combinations if many distinct parameters values

      x_1.x1 <- paste0(x.vec, sep, x.vec)

    }
    else {
      # (Fully) Heterogeneous Combinations if many distinct parameters values

      x_1.x1 <- combn(x.vec, m = 2,
                      FUN = function(x) {
                        paste0(x[1], sep, x[2])
                      }, simplify = TRUE)

      if (!fully.heterogeneous) {
        x_1.x1 <- c(paste0(x.vec, sep, x.vec),
                    x_1.x1)
      }

    }

  } # (Fully) Heterogeneous Combinations if many distinct parameters values
  else {
    # Homogeneous Combination if only one distinct parameter value

    x_1.x1 <- paste0(x.vec[1], sep, x.vec[1])

  } # Homogeneous Combination if only one distinct parameter value

  return(x_1.x1)
}
