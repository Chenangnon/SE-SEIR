
#' Find BSEIR solutions for a Batch of Parameters
#'
#' Wrap \link{SolveBSEIR} over a set of simulation scenarios.
#'
#' @param scenarios an object inheriting from class \code{sim.scenarios},
#' typically returned by \link{get.sim.scenarios}.
#'
#' @param ... named arguments passed to \link{SolveBSEIR} which solves the BSEIR
#' system for each simulation scenario. These can be one or more of \code{Horizon},
#' \code{timestep}, \code{closed.eval.time}, \code{eps}, \code{fQ},
#' \code{non.negative.params}, \code{minP}, \code{minQ}, \code{maxQ},
#' \code{method}, and \code{control}. See \link{SolveBSEIR} for details.
#'
#' @param verbose integer scalar, if positive, information is printed during the
#' running of \code{Batch.solveBSEIR}. Larger values may give more detailed
#' information. Defaults to \code{verbose = 1L}.
#'
#' @param add.homogeneous logical, should homogeneous scenarios equivalent
#' to supplied heterogeneous scenarios (if any) be add to \code{scenarios}?
#'
#' @param cl a cluster object, created by package **parallel** or **snow**.
#' If \code{NULL}, the registered default cluster is used.
#'
#' @param chunk.size scalar number; number of scenarios per chunk, a chunk being
#' a unit for scheduling.
#'
#' @param save logical, if \code{TRUE} the output is saved as a table named
#' \code{filename} with extension \code{file.ext}. Defaults to \code{save = FALSE}.
#'
#' @param filename character string, name of the file to save the output in.
#' Defaults to \code{save = "Batch.out"}. Only used when \code{save = TRUE}.
# or a \link{connection} open for writing.
#'
#' @param path,subpath strings specifying the path (location) to save the
#' outputs at. The used path is given by \code{paste0(path, "/", subpath)}.
#' If the directory \code{path} does not exist, \link{dir.create} is called
#' in an attempt to create it. Likely, if there is no sub-directory \code{subpath}
#' in \code{path}, \link{dir.create} is called in an attempt to create it.
#' Only used when \code{save = TRUE}. The default is \code{path = ""} which
#' means the working directory.
#'
#' @param file.ext character specifying the type of file to save the table
#' output in. Defaults to \code{'.csv'}. Alternatives include \code{'.csv2'} and
#' \code{'.txt'}, any other value being ignored (replaced by the default).
#'
#' @param append,quote,eol,na,row.names,fileEncoding arguments passed to the
#' saving function (\link{write.csv}, \link{write.csv2}, or \link{write.table},
#' depending on \code{file.ext}).
#'
#' @param sep,dec,qmethod,col.names arguments passed to \link{write.table}.
#'
#' @param save.each logical, if \code{TRUE} the output for each scenario (an
#' object of class \code{'BSEIR'}) is saved as a \code{.RData} structure.
#' Defaults to \code{save.each = FALSE}.
#'
#' @param filename.each string, base name of the file to save the output from
#' each scenario in. The output file name (with extension) for each supplied
#' scenario is obtained \code{paste0(filename.each, sce.nb, ".RData")} where
#' \code{sce.nb} is the row number of the scenario in \code{scenarios}. When
#' \code{add.homogeneous = TRUE}, the file name for a scenario obtained as the
#' homogeneous scenario corresponding to one supplied heterogeneous scenario is
#' given by \code{paste0(filename.each, sce.nb, suffix.hom, ".RData")}.
#' Defaults to \code{filename.each = "out"}.
#' Only used when \code{save.each = TRUE}.
#'
#' @param suffix.hom string giving a suffix to be added to the file name for
#' saving each homogeneous scenario derived from a supplied heterogeneous
#' scenario when \code{add.homogeneous = TRUE}. Defaults to \code{save = ".hom"}.
#' Only used when \code{save.each = TRUE} (and \code{add.homogeneous = TRUE}).
#'
# @param attachBSEIRNamespace logical, should the \code{BSEIR} packages's
# namespace be explicitly attached in the local environment? This is useful
# when running on hpc cluster with \code{BSEIR} installed only in a personal
# library.
#'
#' @details
#'
#' \code{verbose = 0} means no report, and the larger \code{verbose} is, the more
#' detailed is the printed information if \code{cl = NULL}. When \code{cl} is
#' not \code{NULL}, any \code{verbose} larger than one is equivalent to
#' \code{verbose = 1} (no information is printed from procedures running on
#' parallel nodes).
#'
#' @export Batch.solveBSEIR
#'
#' @importFrom stringi stri_split_fixed
#' @importFrom utils write.csv
#' @importFrom utils write.csv2
#' @importFrom utils write.table
#' @importFrom pracma findpeaks
#' @importFrom parallel parApply
#' @importFrom parallel parSapply
#' @importFrom parallel parLapply

# If 'add.homogeneous = TRUE' (the default) and the scenario is heterogeneous
# with respect to any parameter, then a second row gives the corresponding
# homogeneous scenario, using the median (average) of each parameter for
# both sub-populations
Batch.solveBSEIR <- function (scenarios,
                              ...,
                              add.homogeneous = TRUE,
                              verbose = 1L,
                              cl = parallel::getDefaultCluster(),
                              chunk.size = NULL,
                              save = FALSE,
                              path = "",
                              subpath = "",
                              filename = "Batch.out",
                              file.ext = ".csv",
                              append = FALSE, quote = TRUE, sep = " ",
                              eol = "\n", na = "NA", dec = ".",
                              row.names = TRUE,
                              col.names = TRUE,
                              qmethod = c("escape", "double"),
                              fileEncoding = "",
                              save.each = FALSE,
                              filename.each = "out",
                              suffix.hom = ".hom") {
  stopifnot(inherits(scenarios, "sim.scenarios"))

  verbose <- as.numeric(verbose)
  stopifnot(is.numeric(verbose))
  verbose <- verbose[1]
  if (verbose) {
    cat("\n    # Converting scenarios into corresponding parameter values ... \n")
  }

  params.mat <- scenario2params (scenarios, sep = attr(scenarios, "sep"),
                                 cl = cl, chunk.size = chunk.size, name.cols = TRUE)
  nb.scenarios <- NROW(params.mat)

  if (verbose) {
    if (nb.scenarios > 1)
      cat(paste0("\n    # Solving the BSEIR ODE system for the ", nb.scenarios, " settings in 'scenarios' ... \n"))
    else
      cat(paste0("\n    # Solving the BSEIR ODE system for the unique setting in 'scenarios' ... \n"))
  }

  Batch.out <- matteApply (X = cbind(1:nb.scenarios, params.mat),
                           MARGIN = 1,
                           FUN = Call.solveBSEIR,
                           ...,
                           verbose = max(0, verbose - 1),
                           save = save.each,
                           filename = filename.each,
                           path = path,
                           subpath = subpath,
                           chunk.size = chunk.size,
                           simplify = FALSE,
                           cl = cl)

  Batch.out <- do.call("rbind", Batch.out)

  nb.eval <- Batch.out[1, NCOL(Batch.out)]
  colnames(Batch.out) <- c("Hom",
                           paste0("Hom.", c("a", "b", "v", "d", "e", "alpha", "m0")),
                           colnames(params.mat)[1:27], "N",
                           "Rep.nb0",
                           "Tc1",
                           "MaxRnbTc1",
                           "Nb.spikes",
                           "Horizon",
                           "FHorizon",
                           paste0("t", 1:nb.eval),
                           c("user.self", "sys.self", "elapsed"),
                           "nb.evals")
  rnames <- paste0("scn", 1:nb.scenarios)

  if (add.homogeneous & any(!(homogeneous <- Batch.out[,1] == 1))) {

    if (verbose) {
      cat(paste0("\n    # Generating homogeneous equivalents (median parameter values) for ", sum(!homogeneous), " heterogeneous 'scenarios' ... \n"))
    }

    params.hom <- get.hom.params (params.mat[!homogeneous, , drop = FALSE])

    if (verbose) {
      cat(paste0("\n    # Solving BSEIR model for the ", NROW(params.hom), " homogeneous settings ... \n"))
    }

    if (identical(suffix.hom, ""))
      suffix.hom <- ".hom"

    Batch.hom <- matteApply (X = cbind(which(!homogeneous), params.hom),
                             MARGIN = 1,
                             FUN = Call.solveBSEIR,
                             ...,
                             verbose = max(0, verbose - 1),
                             path = path,
                             subpath = subpath,
                             save = save.each,
                             filename = filename.each,
                             suffix = suffix.hom,
                             chunk.size = chunk.size,
                             simplify = FALSE,
                             cl = cl)

    Batch.hom <- do.call("rbind", Batch.hom)

    Batch.out <- rbind(Batch.out, Batch.hom)

    rnames <- c(rnames, paste0(rnames[!homogeneous], suffix.hom))

  }

  rownames(Batch.out) <- rnames

  Batch.out <- as.data.frame(Batch.out)

  if (save) {
    if (verbose) {
      cat(paste0("\n    # Saving the batch of results ... \n"))
    }

    ### Create directory and sub-directory to save results (if non existent)
    if (!identical(path, "")) {
      if (!dir.exists(path))
        dir.create(path)
    }

    if (identical(subpath, "")) {
      savepath <- path
    }
    else {
      if (identical(path, ""))
        savepath <- subpath
      else
        savepath <- paste0(path, "/", subpath)

      if (!dir.exists(savepath))
        dir.create(savepath)
    }

    if (identical(savepath, ""))
      savepath <- filename
    else
      savepath <- paste0(savepath, "/", filename)

    if (identical(file.ext, ".txt")) {

      write.table (Batch.out, file = paste0(savepath, ".txt"),
                   append = append, quote = quote, sep = sep,
                   eol = eol, na = na, dec = dec,
                   row.names = row.names,
                   col.names = col.names,
                   qmethod = qmethod,
                   fileEncoding = fileEncoding)

    }
    else if (identical(file.ext, ".csv2")) {

      write.csv2 (Batch.out, file = paste0(savepath, ".csv2"),
                   quote = quote,
                   eol = eol, na = na,
                   row.names = row.names,
                   fileEncoding = fileEncoding)

    }
    else {

      write.csv (Batch.out, file = paste0(savepath, ".csv"),
                 quote = quote,
                 eol = eol, na = na,
                 row.names = row.names,
                 fileEncoding = fileEncoding)
    }
  }

  return(Batch.out)

}

# Returns a matrix, one row for a scenario
#
# The function uses 'catch.conditions' to handle special conditions/errors

#
# @export Call.solveBSEIR
#
Call.solveBSEIR <- function (params,
                             Horizon = 1000, timestep = 0.5, closed.eval.time = TRUE,
                             eps = 1e-20, fQ = 1, non.negative.params = TRUE,
                             minP = 1e-10, minQ = -maxQ, maxQ = 3,
                             method = "lsoda", control = NULL, verbose = 0L,
                             save = FALSE, filename = "out", suffix = "",
                             path = "path/to/save", subpath = "") {
  # Scenario number
  sce.nb <- params[1]
  params <- params[-1]

  # Initial value
  y0 <- params[28:33]
  N <- sum(y0)

  params <- c(params[1:27], N = N)

  if (verbose) {
    cat("\n          **  Solving BSEIR model for scenario k = ", sce.nb, " with parameter set: \n")
    print(rbind(params))
    if (verbose < 2)
      cat("\n             may take a few seconds ... ")
  }

  # Solve the model for 'params'
  ETime <- system.time({
    output <- catch.conditions({
      SolveBSEIR(params = params,
                 y0 = y0,
                 Horizon = Horizon, timestep = timestep,
                 closed.eval.time = closed.eval.time,
                 eps = eps, fQ = fQ, non.negative.params = non.negative.params,
                 minP = minP, minQ = minQ, maxQ = maxQ,
                 method = method, control = control, verbose = max(0, verbose - 1),
                 save = save, filename = filename, suffix = paste0(sce.nb, suffix),
                 path = path, subpath = subpath)
    })$value
  })

  if (verbose & verbose < 2) {
    cat("Done! \n")
  }

  # Extract parameters from the vector 'params'
  tau <- hom <- NULL
  eval(getBSEIRparams())
  stopifnot(sum(y0) == N)

  if (any(class(output) %in% c("simpleError", "error", "condition"))) {
    # Some required quantities
    Horizon <- max(2*tau + 1, Horizon)
    Teval <- seq(from = 0, to = Horizon, by = timestep) # length.out = 4 * Horizon + 1
    Teval <- unique(c(Teval, Horizon))
    if (closed.eval.time)
      Teval <- sort(unique(c(Teval, pmax(0, Teval - tau))))

    output <- c(all(hom),
                hom,
                params,
                NA,
                NA,
                NA,
                NA,
                Teval[length(Teval)],
                NA,
                rep(NA, length(Teval)),
                rep(NA, 3),
                length(Teval))

  }
  else {
    output$proc_time <- ETime
    output <- extract.sim.out (out = output, tau = tau)
  }

  return(output)

}

#
# @export extract.sim.out
#
extract.sim.out <- function(out, tau) {

  Tc1 <- which(out$Rep.nb[,1] <= 1)
  if (length(Tc1)) {

    # First time the reproduction number falls below/reaches 1
    Tc1 <- out$Teval[Tc1[1]]

    # Maximum of the reproductive number after Tc1
    Rep.nb.max.after.Tc1 <- which(out$Teval > Tc1)
    if (length(Rep.nb.max.after.Tc1)) {
      Rep.nb.max.after.Tc1 <- max(out$Rep.nb[Rep.nb.max.after.Tc1,1])
    }
    else
      Rep.nb.max.after.Tc1 <- NA
  }
  else {
    Tc1 <- tau
    Rep.nb.max.after.Tc1 <- NA
  }

  Nb.spikes <- NROW(pracma::findpeaks(out$Ct))

  out <- c(all(out$hom),
           out$hom,
           out$params,
           out$Rep.nb0,
           Tc1,
           Rep.nb.max.after.Tc1,
           Nb.spikes,
           out$Teval[length(out$Teval)],
           1 - out$S[length(out$Teval)] / out$N,
           out$Ct,
           out$proc_time[1:3],
           length(out$Ct))

  return(out)

}

#
# @export get.hom.params
#
get.hom.params <- function (params) {
  if (is.matrix(params)) {
    params[, 2] <- rowMeans(params[,2:3])
    params[, 3] <- params[, 2]

    params[, 4] <- rowMeans(params[,4:5])
    params[, 5] <- params[, 4]

    params[, 6] <- rowMeans(params[,6:7])
    params[, 7] <- params[, 6]

    params[, 8] <- rowMeans(params[,8:9])
    params[, 9] <- params[, 8]

    params[, 10] <- rowMeans(params[,10:11])
    params[, 11] <- params[, 10]

    params[, 12] <- rowMeans(params[,12:13])
    params[, 13] <- params[, 12]

    params[, 14] <- rowMeans(params[,14:15])
    params[, 15] <- params[, 14]

  }
  else {

    params[2:3] <- mean(params[2:3])
    params[4:5] <- mean(params[4:5])
    params[6:7] <- mean(params[6:7])
    params[8:9] <- mean(params[8:9])
    params[10:11] <- mean(params[10:11])
    params[12:13] <- mean(params[12:13])
    params[14:15] <- mean(params[14:15])

  }

  return(params)
}


#
# @export scenario2params
#
# Get parameters corresponding to a given scenario
scenario2params <- function (scenarios,
                             sep = "+",
                             cl = parallel::getDefaultCluster(),
                             chunk.size = NULL,
                             name.cols = FALSE) {

  if (is.null(sep))
    sep <- "+"

  if (NROW(scenarios) == 1) {

    params <- matteSapply(X = scenarios,
                          FUN = function(x) {
                            if(is.numeric(x)) {
                              return(x)
                            }
                            else {
                              return(char_par2num(x, sep = sep))
                            }
                          },
                          cl = cl,
                          chunk.size = chunk.size)

    params <- unlist(params, recursive = TRUE)

    params <- rbind(params)
  }
  else {
    params <- matteApply(X = scenarios, MARGIN = 2,
                         FUN = function(x) {
                           if(is.numeric(x)) {
                             return(x)
                           }
                           else {
                             return(char_par2num(x, sep = sep))
                           }
                         },
                         cl = cl,
                         chunk.size = chunk.size)

    if (is.list(params)) {
      params <- do.call("cbind", params)
    }
  }

  if (name.cols) {
    colnames(params) <- c("tau",
                          "a_1", "a1",
                          "b0_1", "b01",
                          "v_1", "v1",
                          "d0_1", "d01",
                          "e_1", "e1",
                          "alpha_1", "alpha1",
                          "m0_1", "m01",
                          "kappa",
                          "beta_0",
                          "phi_a",
                          "phi_s",
                          "theta",
                          "pi_val",
                          "sigma" ,
                          "gamma_a",
                          "gamma_s",
                          "rho_a",
                          "rho_s",
                          "rho_d",
                          "S0_1", "S01",
                          "E0",
                          "Ia0",
                          "Is0",
                          "Id0")
  }

  return(
    structure(params, class = c("matrix", "sim.params"))
  )

}


#'
# @export char_par2num
#'
# Transform character parameter into numeric parameter vector/matrix
char_par2num <- function(x, sep = "+") {

  out <- as.character(x)

  out <- stringi::stri_split_fixed (out, pattern = sep, simplify = TRUE)

  if (is.null(dim(out))) {
    out <- as.numeric(out)
  }
  else {
    out <- apply(out, MARGIN = 2, FUN = as.numeric)
  }

  return(out)

}
