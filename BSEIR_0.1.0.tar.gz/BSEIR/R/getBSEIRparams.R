getBSEIRparams <- function(params) {

  expression({
    # Extract parameter values
    tau <- max(0.001, params[1])

    a <- params[2:3]
    stopifnot(a >= 0)

    if (non.negative.params) {
      b <- params[4:5] # This is b_i
      stopifnot(b >= 0)
    }
    else {
      b0 <- params[4:5] # This is bo_i, i.e. b0 =  2*b_i + a_i, so b0 = a_i implies 'b_i' = 0
      b <- 0.5 * (b0 - a)
    }

    v <- params[6:7]
    stopifnot(v >= 0)

    if (non.negative.params) {
      d <- params[8:9]
      stopifnot(d >= 0)

      e <- params[10:11]
      stopifnot(e >= 0)
    }
    else {
      d0 <- plogis(params[8:9])
      e <- params[10:11]
      stopifnot(e >= 0)

      d <- e * (-1/(2 * maxQ) + d0 * ((minQ - 1)/minQ + 1/(2*maxQ)))
    }

    alpha <- params[12:13]
    stopifnot(alpha > 0)

    m0 <- params[14:15]
    stopifnot(m0 >= 0, m0 <= 1)

    kappa <- params[16]
    stopifnot(kappa >= 0, kappa <= 1)

    beta_0 <- params[17]
    stopifnot(beta_0 > 0)

    phi_a <- params[18]
    stopifnot(phi_a >= 0, phi_a <= 1)

    phi_s <- params[19]
    stopifnot(phi_s >= 0, phi_s <= 1)

    theta <- params[20]
    stopifnot(theta > 0)

    pi_val <- params[21]
    stopifnot(pi_val >= 0, pi_val <= 1)

    sigma <- params[22]
    stopifnot(sigma >= 0, sigma <= 1)

    gamma_a <- params[23]
    stopifnot(gamma_a > 0)

    gamma_s <- params[24]
    stopifnot(gamma_s > 0)

    rho_a <- params[25]
    stopifnot(rho_a > 0)

    rho_s <- params[26]
    stopifnot(rho_s > 0)

    rho_d <- params[27]
    stopifnot(rho_d > 0)

    N <- params[28]
    stopifnot(N > 0)

    # Check for homogeneity
    hom <- c(a[1] == a[2],
             b[1] == b[2],
             v[1] == v[2],
             d[1] == d[2],
             e[1] == e[2],
             alpha[1] == alpha[2],
             m0[1] == m0[2])

    names(hom) <- c("a", "b", "v", "d", "e", "alpha", "m0")

  })

}
