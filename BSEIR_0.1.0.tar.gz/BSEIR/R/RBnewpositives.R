#'
#' Richards prevalence
#'
#' Prevalence from a Richards' growth curve-based number of new positive cases.
#'
#' @param t numerical vector, real-valued time points at which growth rates
#' are desired.
#'
#' @param rho_d numeric, removal rate from the class of detected cases.
#'
#' @param tau numeric, time offset, determines the growth rate at time \code{t = 0}.
#'
#' @param omega numeric, positive intrinsic growth rate.
#'
#' @param nu numeric, positive shape parameter of the Richards growth curve.
#' \code{nu = 1} corresponds to logistic growth.
#'
#' @param K numeric, total population size (positive).
#'
#' @param t_0,P_0 numerical, outbreak time (\eqn{t_0}) and prevalence (\eqn{P_0}).
#'  Prevalence is \eqn{P_0} for \eqn{t}\code{ = 0}, and zero for \eqn{t \leq t_0}.
#'
#' @details
#' The function simulate observable quantities from an epidemic using Richards
#' growth curve \insertCite{richards1959flexible}{BSEIR} to generate daily counts
#' of new positive (infectious) cases. The prevalence is obtained by integrating
#' removals (recovery and death) from the cumulative new positive cases to
#' obtain the daily prevalence of the target disease.
#'
#' @return
#' A named list with elements:
#' \item{P}{ vector of prevalence values at \code{t} time points.}
#' \item{Npos}{ vector of growth rate, timely count of new positive/detected/reported cases.}
#' \item{dlogNpos}{ vector of logarithmic derivatives of \code{Npos}.}
#' \item{exp_eta}{ vector of exponentiated negative linear predictors used to
#' obtain \code{Npos}: \eqn{exp_{eta} = exp(-\nu \omega (t - \tau))} and
#' \eqn{Npos = K \omega \frac{exp_{eta}}{(1 + exp_{eta})^{(\nu + 1) / \nu}}}.}
#'
#' @export Rprevalence
#'
#' @importFrom stats sigma
#' @importFrom stats integrate
#' @importFrom Rdpack insert_all_ref
#'
#' @references
#' \insertAllCited{}
#'

Rprevalence <- function(t, rho_d, tau, omega, nu = 1, K = 1, t_0 = min(t), P_0 = 0) {
  # New positives
  exp_eta <- exp(-nu * omega * (t - tau))
  Npos <- K * omega * exp_eta / ((1 + exp_eta)^((nu + 1) / nu))

  # dlog of New positives
  dlogNpos <- nu * omega * (((nu + 1) / nu) * exp_eta / (1 + exp_eta) - 1)
  zeroQ <- t <= t_0
  dlogNpos[zeroQ] <- dlogNpos[zeroQ] * 0

  # Child function: integrand to find P
  integrand <- function(time) {
    expeta <- exp(-nu * omega * (time - tau))
    Cdot <- K * omega * expeta / ((1 + expeta)^((nu + 1) / nu))
    return(Cdot * exp(rho_d * time))
  }

  # Prevalence
  P <- Npos
  for (tj in 1:length(t)) {
    P[tj] <- integrate(integrand, lower = t_0, upper = t[tj], rel.tol = 1e-6, abs.tol = 1e-10)$value
  }

  F_0 <- exp(rho_d * t_0)
  P <- (P_0 * F_0 + P) / exp(rho_d * t)

  return(list(P = P, Npos = Npos, dlogNpos = dlogNpos, exp_eta = exp_eta))
}

RBnewpositives <- Rprevalence
