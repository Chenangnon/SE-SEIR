
#'
#' Prophylactic proportion
#'
#' Compute prophylactic proportion(s) \eqn{m_i} given disease-risk information
#' i.e. perceived prevalence \eqn{P} and the rate of change \eqn{Q} of new
#' positive/detected/reported cases.
#'
# @param t numerical vector of time points.
#'
#' @param P numerical vector, perceived prevalence (\eqn{P}) evaluated at some
#' time points \code{t}.
#'
#' @param Q numerical vector, first log-derivative (\eqn{Q}) of the timely
#' number of new positive cases at time points \code{t}.
#'
#' @param alpha numerical vector of shape parameters \eqn{\alpha_i} of the
#' generalized (Richard) growth curve: \eqn{\alpha_i} measures the strength of
#' in-group non-prophylactic behavior in susceptible group \eqn{S_{i}}.
#'
#' @param delta numerical vector of location parameters \eqn{\delta_i} which is
#' determined by the shape \eqn{\alpha_i} and the information-free proportion
#' \eqn{m_{i0}} of individuals behaving prophylactically in susceptible group
#' \eqn{i} as: \eqn{\delta_i = \log (m_{i0}^{-\alpha_i} - 1)}.
#'
#' @param a,b,v,d,e numerical vectors of coefficients (\eqn{a_i}, \eqn{b_i},
#' \eqn{v_i}, \eqn{d_i} and \eqn{e_i}) of \eqn{P}, \eqn{P^2}, \eqn{P \times Q}
#' \eqn{Q^2} and \eqn{Q}, respectively, in the linear predictor \eqn{\eta_i}
#' (a bivariate polynomial that passes through the origin).
#'
#' @details
# \insertCite{richards1959flexible}{BSEIR}
#
#' The function uses \insertCite{richards1959flexible;textual}{BSEIR}'s
#' growth equation to compute the proportion of prophylactic individuals given
#' disease risk-related information (\code{P} and \code{Q}) and coefficients
#' (\code{a,b,v,d,e}).
#'
#' The prophylactic proportion \eqn{m_i} is defined as
#'
#' \eqn{m_i = \left[1 + exp \left(\delta_i - \eta_i\right) \right]^{-\alpha_i}}
#'
#' where the linear predictor \eqn{\eta_i} is given by
#'
#' \eqn{\eta_i = a_i P + b_i P^2 + c_i P \times Q + d_i Q^2 + e_i Q}.
#'
#' @export m_i
#' @importFrom Rdpack insert_all_ref
#'
#' @return
#' A named list with two elements:
#' \item{m}{ matrix of prophylactic proportion \eqn{m_i} where the \eqn{j}th
#' row corresponds to the \eqn{j}th time points \code{t}, and the \eqn{i}th
#' column corresponds to the \eqn{i}th standard of evidence level (susceptible
#' group \eqn{S_i}).}
#' \item{eta}{ matrix of linear predictors \eqn{\eta_i} corresponding to values
#' in \code{m}.}
#'
#' @references
#' \insertAllCited{}
#'
#' @examples
#' m_i (P = .1, Q = .01,
#'      alpha = c(1, 2),
#'      delta = c(2, 2),
#'      a = c(20, 20),
#'      b = c(0, 0),
#'      v = c(0, 150),
#'      d = c(0, 0),
#'      e = c(0, 0))
#'
#

m_i <- function (P, Q, alpha, delta, a, b, v, d, e) {
  # Number of i levels in 'i' (standard of evidence groups)
  ni <- length(delta)

  # Initialize the matrix of prophylactic proportions
  m <- matrix(0, nrow = length(P), ncol = ni)
  eta <- m

  for (i in 1:ni) {
    eta[, i] <- a[i] * P + b[i] * P^2 + v[i] * P * Q + d[i] * Q^2 + e[i] * Q
    ppi <- 1 / (1 + exp(delta[i] - eta[, i]))
    m[, i] <- ppi^(1 / alpha[i])
  }

  return(list(m = m, eta = eta))
}

mi_t <- m_i
