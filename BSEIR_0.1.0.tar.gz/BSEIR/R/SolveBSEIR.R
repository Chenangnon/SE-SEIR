#'
#' Behavior-Disease SEIR model
#'
#' Solve the B-SEIR differential system with risk information feedback and behavior dynamics
#'
# Horizon = max(2*tau + 1, Horizon)
#
#' @param params numerical vector of parameters of the B-SEIR system whose
#' solution is desired: it must have 28 elements, some with
#' restricted ranges. If **\code{params}** has more than 28 elements, only the first
#' 28 are used. See Section \code{Details} for more on **\code{params}**.
#'
#' @param y0 numerical 6-vector of initial sizes of different compartments of the
#' B-SEIR model (except \eqn{R}, which is obtained by subtracting
#' \code{sum(y0)} from \eqn{N}).
#'
#' @param Horizon,timestep positive numerical scalars, the time horizon and step
#' for solving the B-SEIR system.
#'
#' @param closed.eval.time logical, if \code{TRUE}, the set of evaluation points
#' is built such that any element \eqn{t} has its delayed value \eqn{t - \tau}
#' in the set if \eqn{t - \tau \geq 0}.
#'
#' @param eps small positive real, minimum value of the parameter \eqn{\tau}.
#' If \eqn{\tau <}\code{eps}, it is reset to \eqn{\tau =}\code{eps}.
#'
#' @param fQ numeric, indicating whether the rate of change (\code{Q}) of new positive
#' cases should be considered in the model (\code{fQ = 1}) or not (\code{fQ = 0}).
#'
#' @param non.negative.params logical, is it prohibited for parameters
#' \eqn{b_{-1}}, \eqn{b_{1}}, \eqn{d_{-1}} and \eqn{d_{1}} to be negative?
#' See argument \code{params} in section \code{Details}. Defaults to \code{TRUE}.
#'
#' @param minP,minQ,maxQ numeric, \code{minP} is a small tolerance value, under
#' which prevalence (\code{P}) is considered zero; \code{minQ} and \code{maxQ} define the
#' range of the rate of change of new positive cases, both are used when
#' \code{non.negative.params = FALSE} to convert \eqn{b_{-10}}, \eqn{b_{10}},
#' \eqn{d_{-10}}, and \eqn{d_{10}} into \eqn{b_{-1}}, \eqn{b_{1}},
#' \eqn{d_{-1}} and \eqn{d_{1}}, respectively.
#'
#' @param splineQ logical, should smoothing spline be used to derive the rate of
#' change \code{Q} from the number of new positive cases? If
#' \code{splineQ = TRUE} (the default), polynomial smoothing spline from
#' package \code{pspline} is used.
#'
#' @param method the integrator to use. This can be a **string** (one of
#' \code{"lsoda", "lsode", "lsodes", "lsodar", "vode", "daspk", "bdf", "adams",
#' "impAdams", "radau"}) or a **function** that performs integration. Defaults
#' to \code{method = 'lsoda'}.
#'
#' @param control a list of control arguments for the solver (\code{dede}). See
#' \link[deSolve]{dede} for details.
#'
#' @param ... additional arguments passed to or from other methods. Currently,
#' only use by \code{SolveBSEIR}: all \code{...} elements are passed to
#' \link[deSolve]{dede} which then passes them to the integrator.
#' Not used by \code{BSEIR}.
#'
#' @param verbose logical, if \code{TRUE}, information is printed during the
#' run of \code{SolveBSEIR}. Defaults to \code{getOption("verbose")}.
#'
#' @param plot logical, should the numerical BSEIR model solution be plotted?
#' If \code{TRUE}, the result is passed to \link{plot.BSEIR}.
#'
#' @param op named list of graphical parameters for plotting the BSEIR model
#' solution. See \link{plot.BSEIR} for possible elements of the list.
#' Only used if \code{plot = TRUE}.
#'
#' @param save logical, if \code{TRUE} the output is saved as a \code{.RData}
#' object with name \code{paste0(filename, suffix)}. Defaults to \code{save = FALSE}.
#'
#' @param filename string, base name of the \code{.RData} file to save the output in.
#' Defaults to \code{save = "out"}. Only used when \code{save = TRUE}.
#'
#' @param path,subpath strings specifying the path (location) to save the
#' output at. The used path is given by \code{paste0(path, "/", subpath)}.
#' If the directory \code{path} does not exist, \link{dir.create} is called
#' in an attempt to create it. Likely, if there is no sub-directory \code{subpath}
#' in \code{path}, \link{dir.create} is called in an attempt to create it.
#' Only used when \code{save = TRUE}. The default is \code{path = ""} which
#' means the working directory.
#'
#' @param suffix optional string giving a suffix to be added to the file name
#' (i.e. \code{filename}) of the \code{.RData} structure to be created. The saved
#' file's name (with extension) is given by \code{paste0(filename, suffix, ".RData")}.
#' Only used when \code{save = TRUE}.
#'
#' @param t numerical scalar, time point to evaluate the B-SEIR system (vector
#' of derivatives) at.
#'
#' @param y numerical vector, values of the state variables in the B-SEIR model
#' at time \eqn{t=}\code{t}.
#'
#' @param ydel numerical vector, values of the state variables in the B-SEIR model
#' at time \eqn{t - \tau} (delayed state variables).
#'
#' @param ydotdel numerical vector, values of the derivative of state variables
#' in the B-SEIR model at time \eqn{t - \tau} (delayed derivatives).
#'
#' @aliases SolveBSEIR BSEIR
#'
#' @usage
#' SolveBSEIR (params,
#'             y0 = c(S_1 = 49998, S1 = 49998, E = 2,
#'                    Ia = 1, Is = 1, Id = 0) * N / 100000,
#'             Horizon = 300, timestep = 0.25, closed.eval.time = TRUE,
#'             eps = 0.01, fQ = 1, non.negative.params = TRUE,
#'             minP = 1e-10, minQ = -maxQ, maxQ = 3,
#'             method = "lsoda", control = NULL, ...,
#'             verbose = getOption("verbose"),
#'             plot = FALSE, op = NULL,
#'             save = FALSE, path = "", subpath = "",
#'             filename = "out", suffix = "")
#'
#' BSEIR (t, y, params,
#'        fQ = 1, non.negative.params = TRUE,
#'        minP = 1e-10, minQ = -maxQ, maxQ = 3,
#'        ydel = NULL, ydotdel = NULL, ...)
#'
#' @details
#' The function \code{BSEIR} computes the values of the derivatives in the
#' information-dependent B-SEIR ODE system (the model definition) at time \code{t}.
#'
#' The arguments \code{ydel} and \code{ydotdel} for \code{BSEIR} are usually
#' not available at the user level. Calling directly \code{BSEIR} with
#' \code{ydel = NULL} and \code{ydotdel = NULL} will run into error if the
#' evaluation time point \code{t} satisfies \code{t}\eqn{\geq\tau}. When solving
#' the B-SEIR ODE system, \code{BSEIR} is called with \code{ydel = NULL}
#' and \code{ydotdel = NULL}, but the function \link[deSolve]{lagderiv} of the
#' library \code{deSolve} allows then to obtain \code{ydel} and
#' \code{ydotdel} from the solving environment.
#'
#' The function \code{SolveBSEIR} uses \link[deSolve]{dede} to find/approximate
#' the B-SEIR solution corresponding to the supplied parameter values in
#' \code{params}. The arguments \code{method} and \code{control} are passed to
#' \link[deSolve]{dede}. See \link[deSolve]{dede} for details on choosing
#' a \code{method} (i.e. an integrator).
#'
#' The parameter vector \eqn{\Theta}**\code{=params}** is defined as
#' \eqn{\Theta = (\Theta_b, \Theta_d)} where \eqn{\Theta_b} is the subset of
#' behavior-related model parameters,
#'
#'
#' \eqn{\Theta_b = (\tau, a_{-1}, a_{1}, b_{-10}, b_{10}, c_{-1}, c_{1}, d_{-10}, d_{10}, e_{-1}, e_{1}, \alpha_{-1}, \alpha_{1}, m_{-10}, m_{10}, \kappa)},
#'
#'
#' and \eqn{\Theta_d} is the set of other model parameters (disease-related or not),
#'
#'
#' \eqn{\Theta_d = (\beta_0, \phi_a, \phi_s, \theta, \pi, \sigma, \gamma_a, \gamma_s, \rho_a, \rho_s, \rho_d, N)}.
#'
#' All parameters must have non-negative values, except that when
#' \code{non.negative.params = FALSE}, each of parameters \eqn{b_{-10}},
#' \eqn{b_{10}}, \eqn{d_{-10}}, and \eqn{d_{10}} has the real line as support.
#'
#' Parameters \eqn{m_{-10}} and \eqn{m_{10}} (information/disease-free level of
#' prophylactic behavior in the two sub-populations) are restricted to the open
#' \eqn{(0, 1)}; \eqn{\phi_a} and \eqn{\phi_s} (probabilities of disease
#' transmission by different groups of infectious) are restricted to the
#' semi-open \eqn{(0, 1]}; and \eqn{\kappa} (efficiency of prophylactic
#' behavior in reducing infections), \eqn{\pi} (probability of early detection
#' of exposed individuals) and \eqn{\sigma} (proportion of symptomatic
#' infectious in the population) are restricted to the closed \eqn{[0, 1]}.
#'
#' If \code{non.negative.params = TRUE}, \eqn{b_{-1} = b_{-10}},
#' \eqn{b_{1} = b_{10}}, \eqn{d_{-1} = d_{-10}} and \eqn{d_{1} = d_{10}}.
#' If \code{non.negative.params = FALSE}:
#'
#' (1) \eqn{b_{i0} = 2 b_{i} + a_i} so that
#' \eqn{b_{i0} = a_i} implies \eqn{b_{i} = 0}. The transformation is thus
#' \eqn{b_i = \frac{b_{i0} - a_{i}}{2}}; and
#'
#' (2) \eqn{d_i = e_i \left[F(d_{i0}) \times \frac{minQ - 1}{minQ} - \left[1 - F(d_{i0})\right] \times \frac{1}{2 maxQ} \right]}.
#'
#' where \eqn{F(d_{i0})} is the inverse logit link function (mapping the real
#' line into the open \code{(0, 1)}), evaluated at \eqn{d_{i0}},
#' i.e., \eqn{F(d_{i0}) = \left[1 + \exp (- d_{i0}) \right]^{-1}}.
#'
#' See \link{get.sim.scenarios} for succinct definitions of all model parameters.
#' See Baumgaertner et al. (2023) for further details on model and parameter
#' definitions.
#'
#' @return
#'
#' \code{BSEIR} returns a list of one element, a vector
#' containing the derivatives of \code{y} with respect to time, in the same
#' order as in \code{y0} and \code{y}. This format is imposed so that \code{BSEIR}
#' can be directly supplied to \code{dede} (see argument \code{func} of
#' \link[deSolve]{dede}).
#'
#' \code{SolveBSEIR} returns an object of class \code{BSEIR} which is
#' a list with the following elements:
#'
#' \item{Teval}{ vector of time points where the ODE system was evaluated.}
#' \item{Yeval}{ matrix of model state values, rows corresponding to time points
#' in \code{Teval}.}
#' \item{Ydot}{ matrix of model state derivatives, rows corresponding to time
#' points in \code{Teval}.}
#' \item{Pt}{ vector, perceived disease prevalence, evaluated at time points in \code{Teval}.}
#' \item{Ct}{ vector, new positive/detected cases, evaluated at time points in
#' \code{Teval}.}
#' \item{Qt}{ vector, the rate of change of new positive/detected cases,
#' evaluated at time points in \code{Teval}.}
#' \item{S}{ vector, total number of susceptibles individuals in the whole
#' population, evaluated at time points in \code{Teval}.}
#' \item{m}{ matrix, proportion of prophylactic individuals, at time
#' points in \code{Teval}: one column ('m') for the whole population and one column per
#' susceptible group ('m_1', and 'm1').}
#' \item{Rep.nb}{ matrix, effective reproductive number, evaluated at time
#' points in \code{Teval}.}
#' \item{Rep.nb0}{numerical scalar, basic reproductive number.}
#' \item{N}{ numeric scalar, the total population size.}
#' \item{params}{the supplied parameter vector.}
#' \item{non.negative.params}{the supplied argument.}
#' \item{rowdelay}{ integer vector indicating for each time point in \code{Teval},
#' the index of the corresponding delayed time point, or \code{NULL} (when returned by \code{SolveB0SEIR}).}
#' \item{hom}{ logical 7-vector, indicating if the population is homogeneous
#' with respect to parameters \eqn{a}, \eqn{b}, \eqn{v}, \eqn{d}, \eqn{e},
#' \eqn{\alpha} and \eqn{m_0}.}
#' \item{call}{the matched call to \code{SolveBSEIR}.}
#'
#' @seealso
#' To solve a B-SEIR differential system without behavior dynamic,
#' see \link{SolveB0SEIR}.
#'
#' @note
#' A \code{BSEIR} object has methods \code{print} (see
#' \link[BSEIR]{print.BSEIR}), and \code{plot} (see
#' \link[BSEIR]{plot.BSEIR}).
#'
#' @export BSEIR
#' @export SolveBSEIR
#'
#' @importFrom deSolve dede
#'
#' @importFrom pspline sm.spline
#'
#' @examples
#' ## Simulation of an homogeneous population reactive to prevalence only
#' ## 95% protection level, with neutral in-group pressure
#' params0 <- list (
#'   # model parameters
#'   params = c(tau = 3,                 # Risk information delay
#'              a1 = 20, a2 = 20,        # Linear reaction to prevalence
#'              b01 = 0, b02 = 0,        # Quadratic reaction to prevalence
#'              v1 = 0, v2 = 0,          # Interaction prevalence x rate of change
#'              d01 = 0, d02 = 0,        # Quadratic reaction to rate of change
#'              e1 = 0, e2 = 0,          # Linear reaction to rate of change
#'              alpha1 = 1, alpha2 = 1,  # In-group pressure (neutral)
#'              m01 = 0.05, m02 = 0.05,  # Prophylactic proportion in disease/info-free conditions
#'              kappa = 0.95,            # level of protection from prophylactic behavior
#'              beta_0 = 2,              # Baseline (disease/info-free) transmission rate
#'              phi_a = 1, phi_s = 1,    # Probability of disease transmission by asymptomatic/syptomatic infectives
#'              theta = 1/4,             # 1/Duration of incubation (latent) period
#'              pi_val = 2/3,            # Early detection probability for exposed individuals
#'              sigma = 1/3,             # Proportion of symptomatic infectious
#'              gamma_a = 2/(3*14),      # Detection rate of asymptomatic infectives
#'              gamma_s = 4/(10*14),     # Detection rate of symptomatic infectives
#'              rho_a = (1 - 2/3)/14,    # Removal rate of asymptomatic infectious
#'              rho_s = (1 - 4/10)/14,   # Removal rate of symptomatic infectious,
#'              rho_d = 1/30,            # Removal rate of detected infectious
#'              N = 1e+5),
#'   # Initial state
#'   y0 = c(S_1 = 49998, S1 = 49998, E = 2, Ia = 1, Is = 1, Id = 0)
#' )
#'
#' ## Run the simulation
#' library(BSEIR)
#' sim0 <- SolveBSEIR (params = params0$params,
#'                     y0 = params0$y0,
#'                     Horizon = 300, timestep = 0.5,
#'                     verbose = TRUE, plot = FALSE)
#'
#' ## Print a summary of the results
#' sim0
#'
#' # plot the results
#' plot(sim0, which = "Solution")
#' plot(sim0, which = "New positive cases")
#' plot(sim0, which = "Prophylactic proportions")
#' plot(sim0, which = "Reproductive numbers")
#'
SolveBSEIR <- function (params, y0 = c(S_1 = 49998, S1 = 49998, E = 2, Ia = 1, Is = 1, Id = 0) * N / 100000,
                        Horizon = 300, timestep = 0.25, closed.eval.time = TRUE,
                        eps = 0.01, fQ = 1, non.negative.params = TRUE,
                        minP = 1e-10, minQ = -maxQ, maxQ = 3, splineQ = TRUE,
                        method = "lsoda", control = NULL, ...,
                        verbose = getOption("verbose"),
                        plot = FALSE, op = NULL,
                        save = FALSE, path = "", subpath = "",
                        filename = "out", suffix = "") {
  # Save the call
  mcall <- match.call()

  # Extract parameters from the vector 'params'
  stopifnot(is.finite(minP), is.finite(minQ), is.finite(maxQ))
  stopifnot(minP >= 0, minQ < 0, maxQ > 0)
  tau <- a <- b <- v <- d <- e <- alpha <- m0 <- kappa <-
    beta_0 <- phi_a <- phi_s <- theta <- pi_val <- sigma <-
    gamma_a <- gamma_s <- rho_a <- rho_s <- rho_d <- N <- hom <- NULL
  eval(getBSEIRparams())
  stopifnot(sum(y0) == N)

  if (tau < eps) {
    tau <- eps
    warning("tau < 'eps' found and set to 'eps'")
  }

  # Compute delta from m0 and alpha
  delta <- log(1 / (m0 ^ alpha) - 1)

  # Evaluate the solution at equally spaced points between t_0 and t_f
  Horizon <- max(2*tau + 1, Horizon)
  Teval <- seq(from = 0, to = Horizon, by = timestep) # length.out = 4 * Horizon + 1
  Teval <- unique(c(Teval, Horizon))

  Teval0 <- Teval
  # Ensure that Teval contains its delayed version
  Teval <- sort(unique(c(Teval, pmax(0, Teval - tau))))
  if (!closed.eval.time)
    KeepTeval <- Teval %in% Teval0
  else
    KeepTeval <- rep(TRUE, length(Teval))

  if (verbose) {
    cat("\n                * Calling 'deSolve::dede' to solve the BSEIR system ... \n")
  }

  Sol <- deSolve::dede (y = y0, times = Teval, func = BSEIR, parms = params,
                        method = method, control = control, fQ = fQ,
                        minP = minP, maxQ = maxQ,
                        non.negative.params = non.negative.params, ...)
  Teval <- as.matrix(Sol)[, 1]
  Yeval <- as.matrix(Sol)[, -1, drop = FALSE]

  # Get P, Q, and dotCt
  Ct <- pi_val * theta * Yeval[,3] + gamma_a * Yeval[,4] + gamma_s * Yeval[,5]
  Pt <- Yeval[, 6] / N

#  if (any(is.na(Yeval))) {
#    browser()
#  }

  if (verbose) {
    cat("\n                * Computing the Jacobian matrix of the system ... \n")
  }

  # Initialize matrices for Ydot (nedded to compute 'Qt')
  Ydot <- matrix(NA, nrow = length(Teval), ncol = 6)

  # Compute Ydot for Teval < tau
  beforeoutbreak <- Teval < tau
  Ydot[beforeoutbreak,] <- get.dotBSEIR (t = Teval[beforeoutbreak],
                                         y = Yeval[beforeoutbreak,],
                                         params = params, fQ = fQ, minP = minP)
  # Matrix Ydel
  Tdel <- Teval - tau
  Ydel <- matrix(0, nrow = length(Teval), ncol = 6)
  rowdelay <- c(rep(NA, sum(beforeoutbreak)),
                sapply(Tdel[!beforeoutbreak], FUN = function(t) which(Teval == t)[1]))
  Ydel[!beforeoutbreak,] <- Yeval[rowdelay[!beforeoutbreak],]

  # Compute Ydot for tau <= Teval < 2*tau ### Error HERE WHEN timestep = 0.01 (Run3)
  before2tau <- !beforeoutbreak & (Teval < 2*tau)
  Ydot[before2tau,] <- get.dotBSEIR (t = Teval[before2tau],
                                     y = Yeval[before2tau,],
                                     ydel = Ydel[before2tau,],
                                     params = params, fQ = fQ, minP = minP)

  # Compute Ydot for tau <= Teval < 2*tau
  after2tau <- which(Teval >= 2 * tau)
  for (j in after2tau) {
    Ydot[j,] <- BSEIR (t = Teval[j],
                       y = Yeval[j,],
                       ydel = Ydel[j,],
                       ydotdel = Ydot[rowdelay[j],],
                       params = params, fQ = fQ, minP = minP)$ydot
  }

  if (verbose) {
    cat("\n                * Computing number of new positive/detected cases (Ct) and its rate of change (Qt) ... \n")
  }

  # Log Derivative of Ct (Qt)
  dotCt <- pi_val * theta * Ydot[,3] + gamma_a * Ydot[,4] + gamma_s * Ydot[,5]
  if (splineQ[1]) {
  #  dotCt <- predict(pspline::sm.spline(x = Teval, y = Ct),
   #                  xarg = Teval, nderiv = 1)
    Qt <- predict(pspline::sm.spline(x = Teval, y = log(Ct)),
                     xarg = Teval, nderiv = 1)
  }
  else {
    Qt <- dotCt / Ct
  }

  Pt[beforeoutbreak] <-
    Ct[beforeoutbreak] <-
    dotCt[beforeoutbreak] <-
    Qt[beforeoutbreak] <- 0

  if (verbose) {
    cat("\n                * Computing prophylactic proportions and reproductive numbers ... \n")
  }

  # Deduce R
  R <- N - rowSums(Yeval)

  # Compute prophylactic proportions
  S <- rowSums(Yeval[, 1:2])
  m_i <- mi_t(P = Pt, Q = fQ * Qt, alpha = alpha, delta = delta, a = a, b = b,
              v = v, d = d, e = e)$m
  m <- rowSums(Yeval[, 1:2] * m_i) / S

  # Compute reproduction numbers
  Rep.nb0 <- beta_0 * (1 - pi_val) * (phi_a * (1 - sigma) / (gamma_a + rho_a) + phi_s * sigma / (gamma_s + rho_s))
  Rept_1 <- Rep.nb0 * Yeval[, 1] * (1 - kappa * m_i[,1]) / (N - Yeval[, 6])
  Rept1 <- Rep.nb0 * Yeval[, 2] * (1 - kappa * m_i[,2]) / (N - Yeval[, 6])
  Rep.nb <- Rept_1 + Rept1

  # Rescale Rept_1 and Rept1
  Rept_1 <- Rept_1 * S / Yeval[, 1]
  Rept1 <- Rept1 * S / Yeval[, 2]

  # Outputs
  Yeval <- cbind(Yeval, R)
  colnames(Yeval) <- c("S_1", "S1", "E", "Ia", "Is", "Id", "R")

  m <- cbind(m, m_i)
  colnames(m) <- c("m", "m_1", "m1")

  Rep.nb <- cbind(Rep.nb, Rept_1, Rept1)
  colnames(Rep.nb) <- c("Rep.nb", "Rep.nb_1", "Rep.nb1")

  if (all(KeepTeval)) {
    out <- list(Teval = Teval,
                Yeval = Yeval,
                Ydot = Ydot,
                Pt = Pt,
                Ct = Ct,
                Qt = Qt,
                S = S,
                m = m,
                rowdelay = rowdelay,
                Rep.nb = Rep.nb,
                Rep.nb0 = Rep.nb0, N = N,
                params = params,
                non.negative.params = non.negative.params,
                hom = hom,
                call = mcall)
  }
  else {
    out <- list(Teval = Teval[KeepTeval],
                Yeval = Yeval[KeepTeval, , drop = FALSE],
                Ydot = Ydot[KeepTeval, , drop = FALSE],
                Pt = Pt[KeepTeval],
                Ct = Ct[KeepTeval],
                Qt = Qt[KeepTeval],
                S = S[KeepTeval],
                m = m[KeepTeval, , drop = FALSE],
                rowdelay = rowdelay[KeepTeval],
                Rep.nb = Rep.nb[KeepTeval, , drop = FALSE],
                Rep.nb0 = Rep.nb0, N = N,
                params = params, hom = hom,
                call = mcall)
  }

  out <- structure(out, class = "BSEIR")

  if (plot) {
    if (verbose) {
      cat("\n                * Plotting the results ... \n")
    }

    out$plot <- plot.BSEIR(out, op = op)
  }

  if (save) {

    if (verbose) {
      cat("\n                * Saving the results ... \n")
    }

    ### Create directory and sub-directory to save results (if non existent)
    if (!identical(path, "")) {
      if (!dir.exists(path))
        dir.create(path)
    }

    if (identical(subpath, "")) {
      savepath <- path
    }
    else {
      if (identical(path, ""))
        savepath <- subpath
      else
        savepath <- paste0(path, "/", subpath)

      if (!dir.exists(savepath))
        dir.create(savepath)
    }

    if (identical(savepath, ""))
      savepath <- filename
    else
      savepath <- paste0(savepath, "/", filename)

    if (!identical(suffix, ""))
      savepath <- paste0(savepath, suffix)

    save(out, file = paste0(savepath, ".RData"))

  }

  return(out)
}
