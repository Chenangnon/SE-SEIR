
# Differential system of equations
BSEIR <- function (t, y, params,
                   fQ = 1, non.negative.params = TRUE,
                   minP = 1e-10, minQ = -maxQ, maxQ = 3,
                   ydel = NULL, ydotdel = NULL, ...) {
  # Before outbreak
  if (t < 0) {
    return(list(ydot = c(S_1 = 0, S1 = 0, E = 0, Ia = 0, Is = 0, Id = 0)))
  }

  # Real state variables
  S_1 <- y[1]
  S1 <- y[2]
  E <- y[3]
  Ia <- y[4]
  Is <- y[5]
  Id <- y[6]

  # Extract parameters from the vector 'params'
  tau <- a <- b <- v <- d <- e <- alpha <- m0 <- kappa <-
  beta_0 <- phi_a <- phi_s <- theta <- pi_val <- sigma <-
  gamma_a <- gamma_s <- rho_a <- rho_s <- rho_d <- N <- hom <- NULL
  eval(getBSEIRparams())

  # Total mixing population
  NId <- N - Id

  # Before risk information reach out
  if (t < tau) {
    # Compute contact rates
    beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
    beta_is <- beta_0 * (1 - kappa * m0) * phi_s

    # Compute forces of infection
    lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
    lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

    # Initialize 'ydot'
    ydot <- numeric(6)

    # Differential equations
    ydot[1] <- -lambda_1 * S_1                                                  # dot{S}_1
    ydot[2] <- -lambda1 * S1                                                    # dot{S}1
    ydot[3] <- -ydot[1] - ydot[2] - theta * E                                   # dot{E}
    ydot[4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia  # dot{I}a
    ydot[5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is        # dot{I}s
    ydot[6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id    # dot{I}d
    #names(ydot) <- c("S_1", "S1", "E", "Ia", "Is", "Id")

    return(list(ydot = ydot))
  }

  # Get delayed information
  if (is.null(ydel))
    ydel <- deSolve::lagvalue (t - tau, nr = NULL)
  if (is.null(ydotdel))
    ydotdel <- deSolve::lagderiv (t - tau, nr = NULL)
  else {
    if (length(ydotdel) == 3)
      ydotdel <- c(NA, NA, ydotdel, NA)
  }

  # Compute delta from m0 and alpha
  delta <- log(1 / (m0 ^ alpha) - 1)

  # Prevalence of the disease (delayed)
  Pt <- ydel[6] / N

  # Dynamics of new positive cases (delayed)
  # Delayed timely number of new positive cases and its first derivative
  Ctau <- pi_val * theta * ydel[3] + gamma_a * ydel[4] + gamma_s * ydel[5]
  dCtau <- pi_val * theta * ydotdel[3] + gamma_a * ydotdel[4] + gamma_s * ydotdel[5]

#  if (any(is.na(c(Ctau, dCtau)))) {
#    browser()
#  }

  # d log C(t-tau) / dt
  if (fQ[1] > 0) {
    if (Ctau == 0) {
      Qt <- 0
    }
    else {
      Qt <- dCtau / Ctau
    }

    if ((Qt < 0 & Pt < minP) | (Pt < minP / 4 & Qt > 0)) {
      Qt <- 0
    }
  }
  else {
    Qt <- 0
  }

  # Compute prophylactic proportions
  m_i <- c(mi_t(P = Pt, Q = Qt, alpha = alpha, delta = delta,
              a = a, b = b, v = v, d = d, e = e)$m)

  # Compute contact rates
  beta_ia <- beta_0 * (1 - kappa * m_i) * phi_a
  beta_is <- beta_0 * (1 - kappa * m_i) * phi_s

  # Compute forces of infection
  lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
  lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

  # Initialize 'ydot'
  ydot <- numeric(6)

  # Differential equations
  ydot[1] <- -lambda_1 * S_1                                                   # dot{S}_1
  ydot[2] <- -lambda1 * S1                                                     # dot{S}1
  ydot[3] <- -ydot[1] - ydot[2] - theta * E                                    # dot{E}
  ydot[4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia   # dot{I}a
  ydot[5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is         # dot{I}s
  ydot[6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id     # dot{I}d

  return(list(ydot = ydot))
}


### MAKE USE of argument 'all'
# Internal routine to compute a matrix of derivatives (each row has the six elements of the differential system)
get.dotBSEIR <- function (t, y, params, fQ = 1, minP = 1e-10, minQ = -maxQ,
                          non.negative.params = TRUE,
                          maxQ = 3, ydel = NULL, ydotdel = NULL,
                          all = TRUE) {

  if(is.matrix(y) & NROW(y) == 1)
    y <- c(y)

  if(is.vector(y)) {
    if(length(t) > 1)
      stop("'t' must be a scalar (length one) when 'y' is a vector. For a vector 't', 'y' must be a matrix.")

    # Before outbreak
    if (t < 0) {
      if (all[1])
        return(ydot = c(S_1 = 0, S1 = 0, E = 0, Ia = 0, Is = 0, Id = 0))
      else
        return(ydot = c(E = 0, Ia = 0, Is = 0))
    }

    # Real state variables
    stopifnot(length(y) == 6)
    S_1 <- y[1]
    S1 <- y[2]
    E <- y[3]
    Ia <- y[4]
    Is <- y[5]
    Id <- y[6]

    # Extract parameters from the vector 'params'
    tau <- a <- b <- v <- d <- e <- alpha <- m0 <- kappa <-
      beta_0 <- phi_a <- phi_s <- theta <- pi_val <- sigma <-
      gamma_a <- gamma_s <- rho_a <- rho_s <- rho_d <- N <- hom <- NULL
    eval(getBSEIRparams())

    # Total mixing population
    NId <- N - Id

    if (t < tau) {
      # Compute contact rates
      beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
      beta_is <- beta_0 * (1 - kappa * m0) * phi_s

      # Compute forces of infection
      lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
      lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

      if (all[1]) {
        # Initialize 'ydot'
        ydot <- numeric(6)

        # Differential equations
        ydot[1] <- -lambda_1 * S_1                                                  # dot{S}_1
        ydot[2] <- -lambda1 * S1                                                    # dot{S}1
        ydot[3] <- -ydot[1] - ydot[2] - theta * E                                   # dot{E}
        ydot[4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia  # dot{I}a
        ydot[5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is        # dot{I}s
        ydot[6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id    # dot{I}d
        names(ydot) <- paste0("dot.", c("S_1", "S1", "E", "Ia", "Is", "Id"))

        return(ydot)
      }
      else {
        # Initialize 'ydot'
        ydot <- numeric(3)

        # Differential equations
        ydot[1] <- lambda_1 * S_1 + lambda1 * S1 - theta * E                        # dot{E}
        ydot[2] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia  # dot{I}a
        ydot[3] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is        # dot{I}s
        names(ydot) <- paste0("dot.", c("E", "Ia", "Is"))

        return(ydot)
      }
    }

    # Get delayed information
    if (is.null(ydel))
      stop("'ydel' must be provided when 't >= tau'")
    stopifnot(length(ydel) == 6)

    if (is.null(ydotdel)) {
      if (t - tau <= tau) {
        # Compute contact rates
        beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
        beta_is <- beta_0 * (1 - kappa * m0) * phi_s

        # Compute forces of infection
        lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
        lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

        # Initialize 'ydotdel'
        ydotdel <- numeric(6)

        # Differential equations
        ydotdel[1] <- -lambda_1 * ydel[1]                                                  # dot{S}_1
        ydotdel[2] <- -lambda1 * ydel[2]                                                    # dot{S}1
        ydotdel[3] <- -ydotdel[1] - ydotdel[2] - theta * ydel[3]                            # dot{E}
        ydotdel[4] <- (1 - sigma) * (1 - pi_val) * theta * ydel[3] - (gamma_a + rho_a) * ydel[4]  # dot{I}a
        ydotdel[5] <- sigma * (1 - pi_val) * theta * ydel[3] - (gamma_s + rho_s) * ydel[5]        # dot{I}s
        ydotdel[6] <- pi_val * theta * ydel[3] + gamma_a * ydel[4] + gamma_s * ydel[5] - rho_d * ydel[6]    # dot{I}d
      }
      else {
        stop("'ydotdel' must be provided when 't > 2*tau'")
      }
    }
    else if (length(ydotdel) == 3) {
        ydotdel <- c(NA, NA, ydotdel, NA)
    }
    else {
      stopifnot(length(ydotdel) == 6)
    }

    # Compute delta from m0 and alpha
    delta <- log(1 / (m0 ^ alpha) - 1)

    # Prevalence of the disease (delayed)
    Pt <- ydel[6] / N

    # Dynamics of new positive cases (delayed)
    # Delayed timely number of new positive cases and its first derivative
    Ctau <- pi_val * theta * ydel[3] + gamma_a * ydel[4] + gamma_s * ydel[5]
    dCtau <- pi_val * theta * ydotdel[3] + gamma_a * ydotdel[4] + gamma_s * ydotdel[5]

    # d log C(t-tau) / dt
    if (fQ[1] > 0) {
      if (Ctau == 0) {
        Qt <- 0
      }
      else {
        Qt <- dCtau / Ctau
      }

      if ((Qt < 0 & Pt < minP) | (Pt < minP / 4 & Qt > 0)) {
        Qt <- 0
      }
    }
    else {
      Qt <- 0
    }

    # Compute prophylactic proportions
    m_i <- c(mi_t(P = Pt, Q = Qt, alpha = alpha, delta = delta,
                  a = a, b = b, v = v, d = d, e = e)$m)

    # Compute contact rates
    beta_ia <- beta_0 * (1 - kappa * m_i) * phi_a
    beta_is <- beta_0 * (1 - kappa * m_i) * phi_s

    # Compute forces of infection
    lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
    lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

    if (all[1]) {
      # Initialize 'ydot'
      ydot <- numeric(6)

      # Differential equations
      ydot[1] <- -lambda_1 * S_1                                                   # dot{S}_1
      ydot[2] <- -lambda1 * S1                                                     # dot{S}1
      ydot[3] <- -ydot[1] - ydot[2] - theta * E                                    # dot{E}
      ydot[4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia   # dot{I}a
      ydot[5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is         # dot{I}s
      ydot[6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id     # dot{I}d
      names(ydot) <- paste0("dot", c("S_1", "S1", "E", "Ia", "Is", "Id"))

      return(ydot)
    }
    else {
      # Initialize 'ydot'
      ydot <- numeric(3)

      # Differential equations
      ydot[1] <- lambda_1 * S_1 + lambda1 * S1 - theta * E                        # dot{E}
      ydot[2] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia   # dot{I}a
      ydot[3] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is         # dot{I}s
      names(ydot) <- paste0("dot.", c("E", "Ia", "Is"))

      return(ydot)
    }
  }

  # Real state variables
  stopifnot(NCOL(y) == 6)
  S_1 <- y[,1]
  S1 <- y[,2]
  E <- y[,3]
  Ia <- y[,4]
  Is <- y[,5]
  Id <- y[,6]

  # Extract parameters from the vector 'params'
  eval(getBSEIRparams())

  # Total mixing population
  NId <- N - Id

  # Indicator of time period (Before risk information reach out to susceptibles, or after)
  period0 <- t < tau

  if (all(period0)) {
    # Compute contact rates
    beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
    beta_is <- beta_0 * (1 - kappa * m0) * phi_s

    # Compute forces of infection
    lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
    lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

    if (all[1]) {
      # Initialize 'ydot'
      ydot <- matrix(0, nrow = length(Id), ncol = 6)

      # Differential equations
      ydot[,1] <- -lambda_1 * S_1                                                  # dot{S}_1
      ydot[,2] <- -lambda1 * S1                                                    # dot{S}1
      ydot[,3] <- -ydot[,1] - ydot[,2] - theta * E                                 # dot{E}
      ydot[,4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia  # dot{I}a
      ydot[,5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is        # dot{I}s
      ydot[,6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id    # dot{I}d

      negtvalue <- t < 0
      if (any(negtvalue)) {
        ydot[negtvalue,] <- 0
      }

      colnames(ydot) <- paste0("dot", c("S_1", "S1", "E", "Ia", "Is", "Id"))

      return(ydot)
    }
    else {
      # Initialize 'ydot'
      ydot <- matrix(0, nrow = length(Id), ncol = 3)

      # Differential equations
      ydot[,1] <- lambda_1 * S_1 + lambda1 * S1 - theta * E                        # dot{E}
      ydot[,2] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia  # dot{I}a
      ydot[,3] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is        # dot{I}s

      negtvalue <- t < 0
      if (any(negtvalue)) {
        ydot[negtvalue,] <- 0
      }

      colnames(ydot) <- paste0("dot", c("E", "Ia", "Is"))

      return(ydot)
    }
  }

  if (is.null(ydel))
    stop("'ydel' must be provided when 't >= tau'")
  stopifnot(NCOL(ydel) == 6)

  if (is.null(ydotdel)) {
    if (all(t - tau <= tau)) {
      # Compute contact rates
      beta_ia <- beta_0 * (1 - kappa * m0) * phi_a
      beta_is <- beta_0 * (1 - kappa * m0) * phi_s

      # Compute forces of infection
      lambda_1 <- (beta_ia[1] * Ia + beta_is[1] * Is) / NId
      lambda1 <- (beta_ia[2] * Ia + beta_is[2] * Is) / NId

      # Initialize 'ydotdel'
      ydotdel <- matrix(0, nrow = length(Id), ncol = 6)

      # Differential equations
      ydotdel[,1] <- -lambda_1 * ydel[,1]                                                          # dot{S}_1
      ydotdel[,2] <- -lambda1 * ydel[,2]                                                           # dot{S}1
      ydotdel[,3] <- -ydotdel[,1] - ydotdel[,2] - theta * ydel[,3]                                 # dot{E}
      ydotdel[,4] <- (1 - sigma) * (1 - pi_val) * theta * ydel[,3] - (gamma_a + rho_a) * ydel[,4]  # dot{I}a
      ydotdel[,5] <- sigma * (1 - pi_val) * theta * ydel[,3] - (gamma_s + rho_s) * ydel[,5]        # dot{I}s
      ydotdel[,6] <- pi_val * theta * ydel[,3] + gamma_a * ydel[,4] + gamma_s * ydel[,5] - rho_d * ydel[,6]    # dot{I}d
    }
    else
      stop("'ydotdel' must be provided when 't > 2*tau'")
  }
  else if (NCOL(ydotdel) == 3) {
      ydotdel <- cbind(NA, NA, ydotdel, NA)
  }
  else {
    stopifnot(NCOL(ydotdel) == 6)
  }

  # Compute delta from m0 and alpha
  delta <- log(1 / (m0 ^ alpha) - 1)

  # Prevalence of the disease (delayed)
  Pt <- ydel[,6] / N

  # Dynamics of new positive cases (delayed)
  # Delayed timely number of new positive cases and its first derivative
  Ctau <- pi_val * theta * ydel[,3] + gamma_a * ydel[,4] + gamma_s * ydel[,5]
  dCtau <- pi_val * theta * ydotdel[,3] + gamma_a * ydotdel[,4] + gamma_s * ydotdel[,5]

  # d log C(t-tau) / dt
  if (fQ[1] > 0) {
    Qt <- numeric(length(Pt))
    zeroCtau <- Ctau == 0
    if (any(!zeroCtau)) {
      Qt[!zeroCtau] <- dCtau[!zeroCtau] / Ctau[!zeroCtau]
    }

    minorPt <- (Qt < 0 & Pt < minP) | (Pt < minP / 4 & Qt > 0)
    if (any(minorPt)) {
      Qt[minorPt] <- numeric(sum(minorPt))
    }
  }
  else {
    Qt <- numeric(length(Pt))
  }

  # Compute prophylactic proportions
  m_i <- mi_t(P = Pt, Q = Qt, alpha = alpha, delta = delta,
              a = a, b = b, v = v, d = d, e = e)$m

  # Compute contact rates
  beta_ia <- beta_0 * (1 - kappa * m_i) * phi_a
  beta_is <- beta_0 * (1 - kappa * m_i) * phi_s

  # Compute forces of infection
  lambda_1 <- (beta_ia[,1] * Ia + beta_is[,1] * Is) / NId
  lambda1 <- (beta_ia[,2] * Ia + beta_is[,2] * Is) / NId

  if (all[1]) {
    # Initialize 'ydot'
    ydot <- matrix(0, nrow = length(Id), ncol = 6)

    # Differential equations
    ydot[,1] <- -lambda_1 * S_1                                                   # dot{S}_1
    ydot[,2] <- -lambda1 * S1                                                     # dot{S}1
    ydot[,3] <- -ydot[,1] - ydot[,2] - theta * E                                  # dot{E}
    ydot[,4] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia   # dot{I}a
    ydot[,5] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is         # dot{I}s
    ydot[,6] <- pi_val * theta * E + gamma_a * Ia + gamma_s * Is - rho_d * Id     # dot{I}d

    colnames(ydot) <- paste0("dot", c("S_1", "S1", "E", "Ia", "Is", "Id"))

    negtvalue <- t < 0
    if (any(negtvalue)) {
      ydot[negtvalue,] <- 0
    }

    return(ydot)
  }
  else {
    # Initialize 'ydot'
    ydot <- matrix(0, nrow = length(Id), ncol = 3)

    # Differential equations
    ydot[,1] <- lambda_1 * S_1 + lambda1 * S1 - theta * E                         # dot{E}
    ydot[,2] <- (1 - sigma) * (1 - pi_val) * theta * E - (gamma_a + rho_a) * Ia   # dot{I}a
    ydot[,3] <- sigma * (1 - pi_val) * theta * E - (gamma_s + rho_s) * Is         # dot{I}s

    negtvalue <- t < 0
    if (any(negtvalue)) {
      ydot[negtvalue,] <- 0
    }

    colnames(ydot) <- paste0("dot", c("E", "Ia", "Is"))

    return(ydot)
  }
}
