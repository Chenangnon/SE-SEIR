# Vector of initial states

RunBSEIR_ONE <- function (Horizon = 500,
                          tau = 3,
                          a = c(20, 20),
                          b = c(0, 0),
                          b0 = b,
                          v = c(0, 0),
                          d = if (non.negative.params) c(0, 0) else c(-Inf, -Inf),
                          d0 = d,
                          e = c(0, 0),
                          alpha = c(1, 1),
                          kappa = 0.95,
                          beta_0 = 2,
                          pi_val = 4/6, # Early detection of Exposed
                          m0 = c(0.05, 0.05),
                          phi_a = 1,
                          phi_s = 1,
                          theta = 1/4,
                          sigma = 1/2,
                          y0 = c(49998, 49998, 2, 1, 1, 0) * N / 100000,
                          fQ = 1, minP = 1e-10, minQ = -maxQ, maxQ = 3,
                          eps = 1e-20, timestep = 0.25, N = 1e5,
                          closed.eval.time = TRUE, non.negative.params = TRUE,
                          method = "lsoda", control = NULL) {
  stopifnot(is.finite(minP), is.finite(minQ), is.finite(maxQ))
  stopifnot(minP >= 0, minQ < 0, maxQ > 0)

  # Disease dynamic
  infective_time_a <- 14 # Duration (days) of infective period for asyptomatics / or say detection window
  g_prop_a <- pi_val # Proportion of Ia detected over their infective period
  gamma_a <- g_prop_a/infective_time_a # Detecting g_prop_a of Ia, over 'infective_time' days
  rho_a <- (1 - g_prop_a)/infective_time_a # Removal: (1-g_prop_a) of Ia, over 'infective_time' days

  infective_time_s <- 14 # Duration (days) of infective period for syptomatics
  g_prop_s <- 4/10 # Proportion of Is detected over their infective period
  gamma_s <- g_prop_s/infective_time_s # Detecting g_prop_s of Is, over 'infective_time' days
  rho_s <- (1 - g_prop_s)/infective_time_s # Removal: (1-g_prop_s) of Is, over 'infective_time' days

  rho_d <- 1/30 # Removal: 100% of Id, over 20 days (from COVID-19 length of hospital stay in Eleanor . Rees et al. (2020))

  # Build a vector of all parameters
  params <- c(tau = tau,
              a = a, #
              b0 = b0, #
              v = v, #
              d0 = d0, #
              e = e, #
              alpha = alpha, #
              m0 = m0, #
              kappa = kappa,
              beta_0 = beta_0,
              phi_a = phi_a, phi_s = phi_s,
              theta = theta,
              pi_val = pi_val,
              sigma = sigma,
              gamma_a = gamma_a, gamma_s = gamma_s,
              rho_a = rho_a, rho_s = rho_s, rho_d = rho_d,
              N = N)

  # Solve the model
  output <- SolveBSEIR(params, y0 = y0, Horizon = Horizon, timestep = timestep,
                       fQ = fQ, minP = minP, eps = eps,
                       closed.eval.time = closed.eval.time,
                       non.negative.params = non.negative.params,
                       method = method, control = control)

  # Plot New positives
  plot(output$Teval, output$Ct, type = "l", lwd = 1.5,
       xlim = c(0, Horizon), # ylim = c(min(output$Qt), max(output$Ct)),
       xlab = "t (day)", ylab = "New positive cases")
  #lines(output$Teval, output$Qt, type = "l", lwd = 1.5, lty = "dotted")
  grid()

  return(output)
}
