function [m, C, P, Q, eta, t] = Run4mi (PlotC, PlotPQ)

%%
m0 = [0.05 0.05 0.05 0.05]';
ap = [20   20     20    20]' ;
aq = [0     0      0     7]' ;
up = [0     0      0     0]' ;
uq = [0     0   56.5     0]' ;
v =  [0   150      0   150]' ;
alpha = 1 .* ones(length(ap), 1);
delta = log(1./ (m0.^alpha) - 1) ;

%ap = [30 15 0]' ;
%aq = [0 15 30]' ;

%%
if nargin == 0
    PlotC = 0 ;
    PlotPQ = 0 ;
elseif nargin == 1
    PlotPQ = 0 ;
end

N = 100000 ;
tauC = 75.46;
t_0 = 0 ;
maxt = 2 * tauC ;
omegaC = 1/8;
nuC = 1;
KC = 1;
rho_d = omegaC * nuC + 0.001; %  have rho_d > omegaC * nuC  to ensure P is never too high, like 50%!

%%
t = ((t_0):0.1:maxt)' ;

[P, Q, C, ~] = RBnewpositives (t, rho_d, tauC, omegaC, nuC, KC, t_0-.01) ;
C = N.* C ;
%display(C)

[m, eta] = mi_t(P, Q, alpha, delta, ap, aq, up, uq, v);

%% Plot New positives
if PlotC
    figure ('Name' , 'New positives')
    FC = plot(t, C) ;
    FC.Color = [0 0 0]; %  Black
    FC.LineWidth = 1.5;
    hold on
    grid on
    xlabel("{\it t} (day)")
    % ylim([-0.2, 1])
    ylabel('Confirmed new positive cases')
    %legend('$\mathcal{R}_{-1}(t)$', '$\mathcal{R}_{1}(t)$', '$\mathcal{R}(t) = \mathcal{R}_{-1}(t) + \mathcal{R}_{1}(t)$', 'Interpreter','latex')
end

%% Plot of P and Q
if PlotPQ
    figure ('Name' , 'P and Q')
    Fp = plot(t, P) ;
    Fp.Color = [0 0 0]; % Black
    Fp.LineWidth = 1.5;
    hold on 
    Fq = plot(t, Q) ;
    Fq.Color = [0 0 0]; %  Black
    Fq.LineWidth = 1.5;
    Fq.LineStyle = "--" ;
    hold on
    grid on
    xlabel("{\it t} (day)")
    % ylim([-0.2, 1])
    ylabel('P(t), Q(t)')
    legend('$P(t)$', '$Q(t)$', 'Interpreter','latex')
end

%Fe = plot(t, eta(:,1)) ;
%Fe.Color = [0 0 0]; %  Black
%Fe.LineWidth = 1.5;
%hold on

figure ('Name' , 'm vs t')
if PlotPQ == 0
    Fp = plot(t, P) ;
    Fp.Color = [0 0 0]; % Black
    Fp.LineWidth = 1.5;
    hold on 
    Fq = plot(t, Q) ;
    Fq.Color = [0 0 0]; %  Black
    Fq.LineWidth = 1.5;
    Fq.LineStyle = "--" ;
    hold on
end
Fm1 = plot(t, m(:,1)) ;
Fm1.Color = [0 0 1]; % Blue
Fm1.LineWidth = 1.5;
hold on

Fm3 = plot(t, m(:,2)) ;
Fm3.Color = [0.3010 0.7450 0.9330]; % Light Blue
Fm3.LineWidth = 1.5;
hold on

Fm3 = plot(t, m(:,3)) ;
Fm3.Color = "#E68000" ; %"#8040E6"; % 
Fm3.LineWidth = 1.5;
hold on

Fm4 = plot(t, m(:,4)) ;
Fm4.Color = [1 0 0]; % Red
Fm4.LineWidth = 1.5;
hold on

grid on
xlabel("{\it t} (day)")
% ylim([-0.2, 1])
if PlotPQ == 0
    ylabel('P(t), Q(t), $m_i(t)$', 'Interpreter','latex')
    legend('$P(t)$', '$Q(t)$', '$m_1(t)$', '$m_2(t)$', '$m_3(t)$', '$m_4(t)$', 'Interpreter','latex')
else
    ylabel('$m_i(t)$', 'Interpreter','latex')
    legend('$m_1(t)$', '$m_2(t)$', '$m_3(t)$', '$m_4(t)$', 'Interpreter','latex')
end

% xlabel("{\it t} (day)")
% ylim([-0.2, 1])
%ylabel(strcat('${\mathcal{R}_{-1}(t), \mathcal{R}_{1}(t), \mathcal{R}(t)}$'), 'Interpreter','latex')
%legend('$\mathcal{R}_{-1}(t)$', '$\mathcal{R}_{1}(t)$', '$\mathcal{R}(t) = \mathcal{R}_{-1}(t) + \mathcal{R}_{1}(t)$', 'Interpreter','latex')

%%
figure ('Name' , 'm vs P')
Fm1 = plot(P, m(:,1)) ;
Fm1.Color = [0 0 1]; % Blue
Fm1.LineWidth = 1.5;
hold on

Fm3 = plot(P, m(:,2)) ;
Fm3.Color = [0.3010 0.7450 0.9330]; % Light Blue
Fm3.LineWidth = 1.5;
hold on

Fm3 = plot(P, m(:,3)) ;
Fm3.Color = "#E68000" ; %"#8040E6"; % 
Fm3.LineWidth = 1.5;
hold on

Fm4 = plot(P, m(:,4)) ;
Fm4.Color = [1 0 0]; % Red
Fm4.LineWidth = 1.5;
hold on

grid on

end