%% Calculate Numerical Jacobian Matrix
% Calculate a numerical approximation to the Jacobian matrix of a p-vector 
% valued function at a sigle parameter vector value using 'Richardson'
% method.
function J = numjacobian(func, x, side, d, r, v, eps, zero_tol, varargin)
% This is a reproduction of the 'jacobian' function from the R package
% 'numDeriv'. 
%% Dimensions
  f = func(x, varargin{:});
  p = length(f);
  n = length(x);
%% Default values for inputs
  if nargin < 3
    side = nan(n,1);
    d = 1e-4;
    r = 4 ; 
    v = 2 ; 
    eps = 1e-4 ; 
    zero_tol = 1.781029e-05;
  else
    if (n ~= length(side))
      error("Non-NULL argument 'side' should have the same length as x")
    end
    if any(1 ~= abs(side(isnan(side))))
        error("Non-NULL argument 'side' should have values NA, +1, or -1.");
    end 
    if nargin == 3
        d = 1e-4;
        r = 4 ; 
        v = 2 ; 
        eps = 1e-4 ;
        zero_tol = 1.781029e-05;
    elseif nargin == 4
         r = 4 ; 
         v = 2 ; 
         eps = 1e-4 ;
         zero_tol = 1.781029e-05;
    elseif nargin == 5
         v = 2 ; 
         eps = 1e-4 ;
         zero_tol = 1.781029e-05;
    elseif nargin == 6
         eps = 1e-4 ;
         zero_tol = 1.781029e-05;
    elseif nargin == 7
        zero_tol = 1.781029e-05;
    end
    
    %Add code to check arguments 4 to 8
  end
  
  % Initialize the output matrix as an array first
  a = nan(p, r, n) ;
  h = abs(d .* x) + eps .* (abs(x) < zero_tol) ;
  pna = ((side == 1) + (~isnan(side))) == 2 ;
  mna = ((side == -1) + (~isnan(side))) == 2 ;
  seqn = 1:1:n ;
  
  % Computations
  for k = 1:r
    ph = h ;
    ph(pna) = 2 * ph(pna) ;
    ph(mna) = 0 ;
    mh = h ;
    mh(mna) = 2 * mh(mna) ;
    mh(pna) = 0 ;
    for i = 1:n
      a(:, k, i) = (func(x + ph .* (i == seqn), varargin{:}) -  func(x - mh .* (i == seqn), varargin{:}))./(2 * h(i)) ;
    end
    h = h./v ;
  end
  for m = 1:(r - 1)
      a = (a(:, 2:1:(r + 1 - m),:) .* (4^m) -  a(:, 1:1:(r - m),:))./(4^m - 1) ;
  end
  J = zeros(p,n) ;
  for i = 1:n
      J(:,i) = a(:,:,i);
  end
end
