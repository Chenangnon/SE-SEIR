function [m, eta] = mi_t (P, Q, alpha, delta, ap, aq, up, uq, v)
%% Task: compute prophylactic proportion(s) m_i given perceived prevalence P and the related quantity Q.

%% ------------------------------------------------------------------------
%% %%%%%%%%%%%%%-------------- INPUT PARAMETERS --------------%%%%%%%%%%%%%
%% -------------------------------------------------------------------------
% t                     = vector of time points.
% P                     = numeric vector, perceived prevalence at a vector
%                         of time points t (no delay: tau = 0).
% Q                     = numeric vector, first log-derivative of the
%                         timely number of new positive cases at time t.
% alpha                 = shape parameter of the growth curve.
% a, b, u, v            = vectors of coefficients of a bivariate polynomial
%                          in P and Q as a linear predictor for 'mi_t'.

%% ------------------------------------------------------------------------
%% %%%%%%%%%%%%%%%%%%-------------- OUTPUTS --------------%%%%%%%%%%%%%%%%%
%% ------------------------------------------------------------------------
% m          =   matrix of prophylactic proportion(s)
%            the jth row corresponds to the jth time point in 
%            the kth column corresponds to the kth standard of evidence level

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Number of i levels in 'i' (standard of evidence group)
ni = length(delta);

% Initialize the matrix of prophylactic proportion
m = zeros(length(P), ni);
eta = m ;
for i=1:ni
    eta(:,i) = ap(i) .* P + up(i) .* P.^2 + aq(i) .* Q + uq(i) .* Q.^2 + v(i) .* P .* Q;
    ppi = 1 ./ ( 1 + exp(delta(i) - eta(:,i)) );
    m(:,i) = ppi .^ (1./alpha(i));
end
end
