function [m, C, P, Q, eta] = Testmi_t0 (PlotC, PlotPQ)

%%
m0 = [0.15 0.15 0.15]';
alpha = [1 1 1]';
delta = log(1./ (m0.^alpha) - 1) ;
ap = [20 20 20]' ;
aq = [0   2  0]' ;
up = [0   0  0]' ;
uq = [0   0  5]' ;
v =  [0   5  5]' ;

%ap = [30 15 0]' ;
%aq = [0 15 30]' ;

%%
if nargin == 0
    PlotC = 0 ;
    PlotPQ = 0 ;
elseif nargin == 1
    PlotPQ = 0 ;
end

N = 100000 ;
tauI = 60;
maxt = (2 * tauI) ;
omegaI = 1/7;
nuI = 1;
KI = 2.5;
rho_d = omegaI * nuI + 0.1; % must have rho_d > omegaI * nuI

%%
t = ((0):0.1:maxt)' ;

[C, Q, P, ~] = RBnewpositives0 (t, rho_d, tauI, omegaI, nuI, KI) ;
C = N.* C ;
%display(C)

[m, eta] = mi_t(P, Q, alpha, delta, ap, aq, up, uq, v);

%% Plot New positives
if PlotC
    figure ('Name' , 'New positives')
    FC = plot(t, C) ;
    FC.Color = [0 0 0]; %  Black
    FC.LineWidth = 1.5;
    hold on
    grid on
end

%% Plot of P and Q
if PlotPQ
    figure ('Name' , 'P and Q')
    Fp = plot(t, P) ;
    Fp.Color = [0 0 0]; % Black
    Fp.LineWidth = 1.5;
    hold on 
    Fq = plot(t, Q) ;
    Fq.Color = [0 0 0]; %  Black
    Fq.LineWidth = 1.5;
    Fq.LineStyle = "--" ;
    hold on
end

%Fe = plot(t, eta(:,1)) ;
%Fe.Color = [0 0 0]; %  Black
%Fe.LineWidth = 1.5;
%hold on

figure ('Name' , 'm vs t')
Fm1 = plot(t, m(:,1)) ;
Fm1.Color = [0 0 1]; % Blue
Fm1.LineWidth = 1.5;
hold on

Fm3 = plot(t, m(:,2)) ;
Fm3.Color = [0.3010 0.7450 0.9330]; % Light Blue
Fm3.LineWidth = 1.5;
hold on

Fm3 = plot(t, m(:,3)) ;
Fm3.Color = [1 0 0]; % Red
Fm3.LineWidth = 1.5;
hold on

grid on
% xlabel("{\it t} (day)")
% ylim([-0.2, 1])
%ylabel(strcat('${\mathcal{R}_{-1}(t), \mathcal{R}_{1}(t), \mathcal{R}(t)}$'), 'Interpreter','latex')
%legend('$\mathcal{R}_{-1}(t)$', '$\mathcal{R}_{1}(t)$', '$\mathcal{R}(t) = \mathcal{R}_{-1}(t) + \mathcal{R}_{1}(t)$', 'Interpreter','latex')

figure ('Name' , 'm vs P')
Fm1 = plot(P, m(:,1)) ;
Fm1.Color = [0 0 1]; % Blue
Fm1.LineWidth = 1.5;
hold on

Fm3 = plot(P, m(:,2)) ;
Fm3.Color = [0.3010 0.7450 0.9330]; % Light Blue
Fm3.LineWidth = 1.5;
hold on

Fm3 = plot(P, m(:,3)) ;
Fm3.Color = [1 0 0]; % Red
Fm3.LineWidth = 1.5;
hold on

grid on

%% Child functions
    function dval = dlogis (t)
        dval = pdf('Logistic', t, tauI, omegaI);
    end

    function Cval = Cfun (t)
        Pt = dlogis (t);
        dPt = t .* 0;
        for j = 1:length(t)
          dPt(j) = numjacobian(@dlogis, t(j)) ;  
        end        
        Cval = dPt + rho_d .* Pt ;
    end

    function Qval = logitQ (t)
        Ct = Cfun (t) ;
        dCt = t .* 0 ;
        for j = 1:length(t)
            dCt(j) = numjacobian(@Cfun, t(j)) ; 
        end
        Qval = dCt ./ Ct;
        is_na = isnan(Qval);
        Qval(is_na) = is_na(is_na) .* 0 ;
    end

    logitQ (0);
end