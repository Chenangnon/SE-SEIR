function [Teval, Xeval, Pt, Ct, Qt, Id, Rept, Rept1, Rept_1, Rep0, S, m] = RunB0SEIRSc0 (Horizon, Ylim, PlotC)

% Set model parameters
m0    = [.05, .05] ;
beta_0 = 0.45; % From Tyson et al. (2020)
kappa = 0.5;
phi_a = 1;
phi_s = 1;
theta = 1/3;
pi = 2/6; % Early detection of Exposed
sigma = 1/3;
gamma_a = 2/30; % Detecting 1/3 of Ia, over 5 days
gamma_s = 9/150;% Detecting 90% of Is, over 15 days
rho_a = 4/30;   % Removal: 2/3 of Ia, over 5 days
rho_s = 1/150;  % Removal: 10% of Is, over 15 days
rho_d = 1/15;   % Removal: 100% of Id, over 20 days
N = 100000;

% Build a vector of all parameters
vparam = [m0, beta_0, kappa, phi_a, phi_s, sigma, theta, pi, gamma_a, gamma_s, rho_a, rho_s, rho_d, N];

% Vector of initial states
x0 = [49998 49598 2 1 1 0];

% Call B0SEIR
%xdot = B0SEIR (.5, x0, vparam, L) ;
%display (xdot)

% Set Horizon
if nargin == 0
    Horizon = 500 ;
    Ylim = N;
    PlotC = 1;
elseif nargin == 1
    Ylim = N;
    PlotC = 1;
elseif nargin == 2
    PlotC = 1;
end
[Teval, Xeval, Pt, Ct, Qt, Id, Rept, Rept1, Rept_1, Rep0, S, m] = SolveB0SEIR(vparam, x0, Horizon, Ylim, PlotC) ;

end