function [P, dlogNpos, Npos, exp_eta] = RBnewpositives (t, rho_d, tau, omega, nu, K, t_0, P_0)
%% Prevalence from a Bertalanffy-Richards growth curve-based New positive cases 

%% Inputs
% t       = time points at which growth rate ... are desired
% rho_d   = removal rate from the class of detected cases
% tau     = time offset, determines the growth rate at time t = 0
% omega   = intrisic growth rate (>0)
% nu      = shape parameter of the Richards growth curve (>0); nu = 1 <==> logistic growth
% t_0      = outbreak time, so prevalence is P_0 for t = 0, and zero for t <= t0
% P_0      = Prevalence is P_0 for t = 0, and zero for t <= t0

%% Outputs
% Npos       = growth rate ( ~ C = daily count of new cases)
% exp_eta = exponential of the negative of the linear predictor in the
% growth curve for Npos

%% Default arguments
if nargin == 4
    nu = 1 ;
    K = 1 ;
    t_0 = min(t);
    P_0 = 0;
elseif nargin == 5
    K = 1 ;
    t_0 = min(t) ;
    P_0 = 0 ;
elseif nargin ==  6
    t_0 = min(t) ;
    P_0 = 0;
elseif nargin ==  7
    P_0 = 0;
end

%if nu * omega >= rho_d
%    error("nu * omega < rho_d does not hold.")
%end

%% Function body
% New positves
exp_eta = exp(-nu .* omega .* (t - tau)) ;
Npos = K .* omega .* exp_eta ./ ( (1 + exp_eta).^((nu+1)./nu) ) ;

% dlog of New positves
dlogNpos = nu .* omega .* ( ((nu+1)./nu) .* exp_eta ./ (1 + exp_eta) - 1 ) ;
zeroQ = t <= t_0;
dlogNpos(zeroQ) = dlogNpos(zeroQ) .* 0;

% Prevalence
P = Npos ;
for tj = 1:length(t)
    P(tj) = integral(@integrand, t_0, t(tj), 'RelTol',1e-6,'AbsTol',1e-10) ;
end

F_0 = exp(rho_d .* t_0) ;
P = (P_0 .* F_0 + P) ./ exp(rho_d .* t) ;


%% Child function: integrand to find P
    function int = integrand (time)
        expeta = exp(-nu .* omega .* (time - tau)) ;
        Cdot = K .* omega .* expeta ./ ( (1 + expeta).^((nu+1)./nu) ) ;
        int = Cdot .* exp(rho_d .* time) ;
    end
end