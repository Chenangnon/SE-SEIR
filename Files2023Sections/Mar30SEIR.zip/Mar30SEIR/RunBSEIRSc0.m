function [Teval, Xeval, Pt, Ct, Qt, Rept, Rept1, Rept_1, Rep0, alpha, ap, up, v, uq, aq, S, m, m_i] = RunBSEIRSc0 (Horizon, fQ, minP, Ylim, PlotC, eps)

%% Set model parameters
N = 100000;
% Disease dynamic
beta_0 = 0.4; % From Tyson et al. (2020)
kappa = 0.5;
phi_a = 1;
phi_s = 1;
theta = 1/3;
pi = 1/5; % Early detection of Exposed
sigma = 1/3;
gamma_a = 1/20; % Detecting 1/4 of Ia, over 5 days
gamma_s = 9/100;% Detecting 90% of Is, over 10 days
rho_a = 3/40;   % Removal: 3/4 of Ia, over 10 days
rho_s = 1/200;  % Removal: 10% of Is, over 20 days
rho_d = 1/20;   % Removal: 100% of Id, over 15 days

% Behavior dynamic
m0 = [0.05    0.05]';
ap = [50        50]' ;
aq = [500        0]' ;
up = [0        500]' ;
uq = [0        500]' ;
v =  [500        0]' ;
alpha = 0.05 .* ones(length(ap), 1);
tau = 7;

% Build a vector of all parameters
vparam = [m0; beta_0; kappa; phi_a; phi_s; sigma; theta; pi; gamma_a; gamma_s; rho_a; rho_s; rho_d; N; alpha; ap; up; v; uq; aq; tau];

% Vector of initial states
x0 = [0.6666, 0.333, 0.0002, 0.0001, 0.0001 0] * N;
%x0 = [49998 49998 2 1 1 0] * N / 100000;

% Set Horizon
if nargin == 0
    Horizon = 500 ;
    fQ = 0;
    minP = 10/N;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 1
    fQ = 0;
    minP = 10/N;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 2
    minP = 10/N;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 3
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 4
    PlotC = 1;
    eps = 0.01;
elseif nargin == 5
    eps = 0.01;
end

[Teval, Xeval, Pt, Ct, Qt, Rept, Rept1, Rept_1, Rep0, alpha, ap, up, v, uq, aq, S, m, m_i] = SolveBSEIR(vparam, x0, Horizon, fQ, minP, Ylim, PlotC, eps);

%% Plot New positives
% figure ('Name' , 'New positives')
% PCt = plot(Teval, Ct);
% PCt.LineWidth = 1.5;
% hold on
% grid on
% xlabel("{\it t} (day)")
% ylabel("{\it New positive cases}")
% f = gca;
% Ffile = append("Plot", num2str(109), ".png");
% exportgraphics(f, Ffile)

end