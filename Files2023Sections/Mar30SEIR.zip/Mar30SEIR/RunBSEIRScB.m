function [Teval, Xeval, Pt, Ct, Qt, Rept, Rept1, Rept_1, Rep0, alpha, ap, up, v, uq, aq, S, m, m_i] = RunBSEIRScB (Horizon, fQ, minP, Ylim, PlotC, eps)

% [Teval, Xeval, Pt, Ct, Qt, Rept, Rept1, Rept_1, Rep0, alpha, ap, up, v, uq, aq, S, m, m_i] = RunBSEIRSc1(2000, 1, .0000001);
%
% [maxEt tmaxEt] = max(Xeval(:,3))
% Teval(tmaxEt)
%
% [maxCt tmaxCt] = max(Ct)
% Teval(tmaxCt)
%
% [ReptEq1 tReptEq1] = min(abs(Rept-1))
% Rept((tReptEq1-1):(tReptEq1+1))
% Teval(tReptEq1)
%
% [maxPt tmaxPt] = max(Pt)
% Teval(tmaxPt)

%% Set model parameters
N = 100000;
% Disease dynamic
beta_0 = 2; % Not From Tyson et al. (2020)
kappa = 0.5;
phi_a = 1;
phi_s = 1;
theta = 1/4;
pi = 4/6; % Early detection of Exposed
sigma = 1/3;

infective_time_a = 14 ; % Duration (days) of infective period for asyptomatics / or say detection window
g_prop_a = pi; % Proportion of Ia detected over their infective period
gamma_a = g_prop_a/infective_time_a; % Detecting g_prop_a of Ia, over 'infective_time' days
rho_a = (1 - g_prop_a)/infective_time_a;   % Removal: (1-g_prop_a) of Ia, over 'infective_time' days

infective_time_s = 14 ; % Duration (days) of infective period for syptomatics
g_prop_s = 4/10; % Proportion of Is detected over their infective period
gamma_s = g_prop_s/infective_time_s;% Detecting g_prop_s of Is, over 'infective_time' days
rho_s = (1 - g_prop_s)/infective_time_s;  % Removal: (1-g_prop_s) of Is, over 'infective_time' days

rho_d = 1/30 ;   % Removal: 100% of Id, over 20 days (from COVID-19 length of hospital stay in Eleanor . Rees et al. (2020))

%display(rho_d)

% Behavior dynamic
m0 = [0.05      0.05]';
ap = [20          20]' ;
aq = [0            0]' ;
up = [0            0]' ;
uq = [0            0]' ;
v =  [150        150]' ;
alpha = 1 .* ones(length(ap), 1);
tau = 0.01;

% Build a vector of all parameters
vparam = [m0; beta_0; kappa; phi_a; phi_s; sigma; theta; pi; gamma_a; gamma_s; rho_a; rho_s; rho_d; N; alpha; ap; up; v; uq; aq; tau];

% Vector of initial states
%x0 = [0, 0.99996, 0.00002, 0.00001, 0.00001 0] * N;
%x0 = [0.6666, 0.333, 0.0002, 0.0001, 0.0001 0] * N;
x0 = [49998 49998 2 1 1 0] * N / 100000;

% Set Horizon
if nargin == 0
    Horizon = 500 ;
    fQ = 0;
    minP = 10/N;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 1
    fQ = 0;
    minP = 10/N;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 2
    minP = 10/N;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 3
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 4
    PlotC = 1;
    eps = 0.01;
elseif nargin == 5
    eps = 0.01;
end

[Teval, Xeval, Pt, Ct, Qt, Rept, Rept1, Rept_1, Rep0, alpha, ap, up, v, uq, aq, S, m, m_i] = SolveBSEIR(vparam, x0, Horizon, fQ, minP, Ylim, PlotC, eps);

%% Plot New positives
% figure ('Name' , 'New positives')
% PCt = plot(Teval, Ct);
% PCt.LineWidth = 1.5;
% hold on
% grid on
% xlabel("{\it t} (day)")
% ylabel("{\it New positive cases}")
% f = gca;
% Ffile = append("Plot", num2str(109), ".png");
% exportgraphics(f, Ffile)

end