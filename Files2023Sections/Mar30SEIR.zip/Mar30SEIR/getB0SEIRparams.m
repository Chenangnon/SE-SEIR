function [m0, beta_0, kappa, phi_a, phi_s, sigma, theta, pi, gamma_a, gamma_s, rho_a, rho_s, rho_d, N] = getB0SEIRparams(vparam)
m0 = vparam(1:2);
beta_0 = vparam(3);
kappa = vparam(4);
phi_a = vparam(5);
phi_s = vparam(6);
sigma = vparam(7);
theta = vparam(8);
pi = vparam(9);
gamma_a = vparam(10);
gamma_s = vparam(11);
rho_a = vparam(12);
rho_s = vparam(13);
rho_d = vparam(14);
N = vparam(15);
end