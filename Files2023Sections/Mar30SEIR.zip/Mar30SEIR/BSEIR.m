function xdot = BSEIR(~,x,xdel,xdotdel,vparam, fQ, minP) % BSEIR(t,x,xdel,xdotdel,vparam, fQ)

%display(t)
%display(x)
%display(xdel)
%display(xdotdel)

%% Differential system of equations

% Real state variables
S_1 = x(1);
S1 = x(2);
E = x(3);
Ia = x(4);
Is = x(5);
Id = x(6);

% Extract parameters from the vector 'vparam'
[m0, beta_0, kappa, phi_a, phi_s, sigma, theta, pi, gamma_a, gamma_s, rho_a, rho_s, rho_d, N, alpha, ap, up, v, uq, aq, ~] = getBSEIRparams(vparam);

% Compute delta from m0 and alpha
delta = log(1./(m0.^(alpha)) - 1);

% Total mixing population
NId = N - Id;

% Prevalence of the disease (delayed)
Pt = xdel(6)/N;

% Dynamics of new positive cases (delayed)
%%% Delayed timely number of new positive cases and its first derivative
Ctau = pi .* theta .* xdel(3) + gamma_a .* xdel(4) + gamma_s .* xdel(5);
dCtau = pi .* theta .* xdotdel(3) + gamma_a .* xdotdel(4) + gamma_s .* xdotdel(5);
%%% d log C(t-tau)/ dt ;
if fQ > 0
    if Ctau == 0
        Qt = 0;
    else
        Qt = dCtau ./ Ctau;
    end
else
    Qt = 0 .* Pt;
end

if (Pt < minP) * (Qt < 0) + (Pt < minP/4) * (Qt > 0) > 0
    Qt = 0;
end

%Pt = Ctau / N;

% Compute prophylactic proportions
m_i = mi_t (Pt, Qt, alpha, delta, ap, aq, up, uq, v);

% Compute contact rates
beta_ia = beta_0 * (1 - kappa .* m_i) * phi_a;
beta_is = beta_0 * (1 - kappa .* m_i) * phi_s;

% Compute forces of infection
lambda_1 = (beta_ia(1) * Ia + beta_is(1) * Is) / NId;
lambda1  = (beta_ia(2) * Ia + beta_is(2) * Is) / NId;

% Initialize 'xdot'
xdot = zeros(6,1);

% Differential equations
xdot(1)= - lambda_1 .* S_1;                                               % dot{S}_1
xdot(2)= - lambda1 .* S1;                                                 % dot{S}1
xdot(3)= - xdot(1) - xdot(2) - theta .* E;                                % dot{E}
xdot(4)= (1 - sigma) .* (1 - pi) .* theta .* E - (gamma_a + rho_a) .* Ia; % dot{I}a
xdot(5)= sigma .* (1 - pi) .* theta .* E - (gamma_s + rho_s) .* Is;       % dot{I}s
xdot(6)= pi .* theta .* E + gamma_a .* Ia + gamma_s .* Is - rho_d .* Id;  % dot{I}d
end