function [Teval, XevalR, Pt, Ctau, Qt, Rept, Rept1, Rept_1, Rep0, alpha, ap, up, v, uq, aq, S, m, m_i] = SolveBSEIR(vparam, x0, Horizon, fQ, minP, Ylim, PlotC, eps)

% Extract parameters from the vector 'vparam'
[m0, beta_0, kappa, phi_a, phi_s, sigma, theta, pi, gamma_a, gamma_s, rho_a, rho_s, ~, N, alpha, ap, up, v, uq, aq, tau] = getBSEIRparams(vparam);

if nargin == 4
    minP = 0.00001;
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 5
    Ylim = N;
    PlotC = 1;
    eps = 0.01;
elseif nargin == 6
    PlotC = 1;
    eps = 0.01;
elseif nargin == 7
    eps = 0.01;
end

if tau < eps
    tau = eps;
    warning("tau <= 'eps' found and set to 'eps'")
end

% Compute delta from m0 and alpha
delta = log(1./(m0.^(alpha)) - 1);

% Time delay function
%    function td = dtime (t, ~) % dtime (t, x)
%        td = t - tau ;
%    end
dtime = tau * ones(6,1);

% Solution History Function: t <= tau
% Here we solve the differential system with no information available
% Assume an exponential growth epidemic in each group (ignoring prophylaxy)
Hsol = ode45(@(t,y) B0SEIR(t,y, vparam), [0, tau], x0);
function x = BSEIRhistory(t)
    if t < 0                               % Before first case introduction
        x = x0;                
        x(1:2) = x0(1:2) + sum(x0((3):(6)))/2; % Evenly redistribute cases in 'S' classes
    elseif t == 0                          % At first case introduction
        x = x0;
    else                                   % Use the system solution here
        x = deval(Hsol, t);
    end
end

%% Define the interval of integration [t_0 t_f] and solve the DDE using the ddensd solver.
tspan = [tau, Horizon];
Sol = ddensd(@(t,x,xdel,xdotdel)BSEIR(t,x,xdel,xdotdel, vparam, fQ, minP), dtime, dtime, @BSEIRhistory, tspan);

%% Evaluate the solution at equally spaced points between t_0 and t_f
Teval = linspace(tau,Horizon,4*Horizon+1);
Xeval = deval(Sol, Teval);

%% Get P and Q
tpq = Teval >= (2 * tau);
Ttau = Teval(tpq) - tau;
Xtau = deval(Sol, Ttau);
Ctau = pi .* theta .* Xtau(3,:) + gamma_a .* Xtau(4,:) + gamma_s .* Xtau(5,:);
Idtau = Xtau(6,:);
if (any(tpq == 0))
    Ttau1 = Teval(tpq == 0) - tau;
    Xtau = deval(Hsol, Ttau1);
    Ctau1 = pi .* theta .* Xtau(3,:) + gamma_a .* Xtau(4,:) + gamma_s .* Xtau(5,:);
    Ttau = [Ttau1, Ttau];
    Ctau = [Ctau1, Ctau];
    Idtau1 = Xtau(6,:);
    Idtau = [Idtau1, Idtau];
end

Pt = Idtau' ./ N;
%Pt = Ctau' ./ N;
dCtau = gradient(Ctau(:)) ./ gradient(Ttau(:));
Qt = dCtau ./ Ctau(:);
lessminP = (Pt < minP) .* (Qt < 0) + (Pt < minP/4) .* (Qt > 0) > 0;
Qt(lessminP) = Qt(lessminP) .* 0;

%% Add some evaluations points before time tau
if tau >= .5
    T0eval = linspace(0.01,tau - .01,max(3, ceil(tau)));
    X0eval = deval(Hsol, T0eval);
    Teval = [T0eval'; Teval'];
    Xeval = [X0eval'; Xeval']; 
    Pt = [zeros(length(T0eval),1); Pt];
    Qt = [zeros(length(T0eval),1); Qt];    
    Ctau = [zeros(length(T0eval),1);Ctau(:)];
else
    Teval = Teval';
    Xeval = Xeval';
    Ctau = Ctau(:);
end

%% Deduce R
R = N - sum(Xeval, 2);
XevalR = [Xeval, R];

%% Compute prophylactic proportions
m_i = mi_t (Pt, fQ .* Qt, alpha, delta, ap, aq, up, uq, v);
S = sum(Xeval(:,1:2), 2) ;
m = sum(Xeval(:,1:2) .* m_i, 2) ./ S ;

%% Compute reproduction numbers
Rep0 = beta_0 * (1 - pi) * (phi_a * (1 - sigma) / (gamma_a + rho_a) + phi_s * sigma / (gamma_s + rho_s));
Rept_1 = Rep0 .* Xeval(:,1) .* (1 - kappa * m_i(:,1)) ./ (N - Xeval(:,6));
Rept1 = Rep0 .* Xeval(:,2) .* (1 - kappa * m_i(:,2)) ./ (N - Xeval(:,6));
Rept = Rept_1 + Rept1;

%% Rescale Rept_1 and Rept1
Rept_1 = Rept_1 .* S ./ Xeval(:,1) ;
Rept1 = Rept1 .* S ./ Xeval(:,2) ;

%% Plot the solution and C(t - tau) = Ctau
figure ('Name' , 'BSEIR')
s_1 = plot(Teval, Xeval(:,1)) ;
s_1.Color = [0.3010 0.7450 0.9330]; % Degraded Blue
s_1.LineWidth = 1.5;
hold on
s1 = plot(Teval, Xeval(:,2));
s1.Color = [0 0 1]; % Blue
s1.LineWidth = 2.5;
hold on
E = plot(Teval, Xeval(:,3));
E.Color = [0.4940 0.1840 0.5560]; % Purpule like [0.6350 0.0780 0.1840]; % Brown?
E.LineWidth = 2.5;
hold on
Ia = plot(Teval, Xeval(:,4));
Ia.Color = [0.9290 0.6940 0.1250]; % Yellow like
Ia.LineWidth = 2.5;
Ia.LineStyle = ':';
hold on
Is = plot(Teval, Xeval(:,5));
Is.Color = [1 0 0]; % Red
Is.LineWidth = 2.5;
Is.LineStyle = '--';
hold on
Id = plot(Teval, Xeval(:,6));
Id.Color = [1 0 1]; % Magenta
Id.LineWidth = 2.5;
hold on
R = plot(Teval, R);
R.Color = [0.2 0.6740 0.1880]; % Green
R.LineWidth = 2.5;
hold on

if PlotC == 1
   grid on
   %grid minor
   xlabel("{\it t} (day)")
   ylabel(strcat("{\it S_{i}(t), E(t), I_{j}(t), R(t)}"))
   ylim([0 Ylim]) % ylim([0 max(max(XevalR))])
   yticks(N *[0 0.2 0.4 0.6 0.8 1])
   legend(["\it S_{-1}(t)", "\it S_{1}(t)", "\it E(t)", "\it I_{a}(t)", "\it I_{s}(t)", "\it I_{d}(t)", "\it R(t)"])
      
    %% Plot New positives
    figure ('Name' , 'New positives cases')
   Ctp = plot(Teval, Ctau);
   Ctp.Color = [0 0 0]; % Black
   Ctp.LineWidth = 1.5;
   hold on
   grid on
   %grid minor
   
    maxC = N * ceil(100 * max(Ctau) / N) / 100;

    grid on
    %grid minor
    xlabel("{\it t} (day)")
    ylabel(strcat("{\it C(t)}"))
    ylim([0 maxC]) % ylim([0 max(max(XevalR))])
    %yticks(N *[0 0.2 0.4 0.6 0.8 1])
    legend("\it New confirmed positives")
else
   Ctp = plot(Teval, Ctau);
   Ctp.Color = [0 0 0]; % Black
   Ctp.LineWidth = 1.5;
   hold on
   grid on
   %grid minor
   xlabel("{\it t} (day)")
   ylabel(strcat("{\it S_{i}(t), E(t), I_{j}(t), R(t), C(t)}"))
   ylim([0 Ylim]) % ylim([0 max(max(XevalR))])
   yticks(N *[0 0.2 0.4 0.6 0.8 1])
   legend(["\it S_{-1}(t)", "\it S_{1}(t)", "\it E(t)", "\it I_{a}(t)", "\it I_{s}(t)", "\it I_{d}(t)", "\it R(t)", "\it C(t)"]) 
end

%% Plot Prophylatic proportion
figure ('Name' , 'Prophylactic proportions')
sp = plot(Teval, Pt); % scatter(P, m_i(:,1),10,"filled", "blue", 'LineWidth',2) ;
sp.Color = [0 0 0]; % Black
sp.LineWidth = 2.5;
sp.LineStyle = '--';
hold on
t0 = length(Pt) - sum(Pt > 0) + 1;
sq = plot(Teval(t0:length(Qt)), Qt(t0:length(Qt))); 
sq.Color = [0 0 0]; % Black
sq.LineWidth = 1.5;
sq.LineStyle = '-.';
hold on

validm_11 = any(m_i(:,1) ~= m_i(:,2)) ;
if validm_11
    s_1 = plot(Teval, m_i(:,1)) ;
    s_1.Color = [0.3010 0.7450 0.9330]; % Light Blue
    s_1.LineWidth = 1.5;
    hold on
    st = plot(Teval, m);
    st.Color = [0 0.4470 0.7410] ; % Another Blue
    st.LineWidth = 2;
    st.LineStyle = ':'; % : for .......
    hold on
    s1 = plot(Teval, m_i(:,2));
    s1.Color = [0 0 1]; % Blue
    s1.LineWidth = 1.5;
    hold on
else
    st = plot(Teval, m);
    st.Color = [0 0.4470 0.7410] ; % Another Blue
    st.LineWidth = 2;
    st.LineStyle = ':'; % : for .......
    hold on
end

grid on
%grid minor
xlabel("{\it t} (day)")

if validm_11
    ylabel(strcat("{\it P(t), Q(t), m_{-1}(t), m(t), m_{1}(t)}"))
    ylim([min(Qt) 1])
    legend(["\it P(t)", "\it Q(t)", "\it m_{-1}(t)", "\it m(t)", "\it m_{1}(t)"])
else
    ylabel(strcat("{\it P(t), Q(t), m(t)}"))
    ylim([min(Qt) 1])
    legend(["\it P(t)", "\it Q(t)", "\it m(t)"])
end

%yticks([0 0.2 0.4 0.6 0.8 1])


%% Plot Reproduction number
figure ('Name' , 'Reproduction number')
validRept_1 = any(~isnan(Rept_1)) ;
validRept1 = any(~isnan(Rept1)) ;

if validRept_1 &&  validRept1
    s_R_1 = plot(Teval, Rept_1) ;
    s_R_1.Color = [0.3010 0.7450 0.9330]; % Light Blue
    s_R_1.LineWidth = 1.5;
    hold on

    s_R = plot(Teval, Rept) ;
    s_R.Color = [0 0.4470 0.7410]; %  Another Blue
    s_R.LineWidth = 2;
    s_R.LineStyle = ':';
    hold on

    s_R1 = plot(Teval, Rept1) ;
    s_R1.Color = [0 0 1]; %  Blue
    s_R1.LineWidth = 1.5;
    hold on
else
    s_R = plot(Teval, Rept) ;
    s_R.Color = [0 0.4470 0.7410]; %  Another Blue
    s_R.LineWidth = 2;
    s_R.LineStyle = ':';
    hold on
end


grid on
xlabel("{\it t} (day)")
if validRept_1 &&  validRept1
    ylabel(strcat('${\mathcal{R}_{-1}(t), \mathcal{R}(t), \mathcal{R}_{1}(t)}$'), 'Interpreter','latex')
    legend('$\mathcal{R}_{-1}(t)$', '$\mathcal{R}(t) = \frac{S_{-1}(t)}{S(t)} \mathcal{R}_{-1}(t) + \frac{S_{1}(t)}{S(t)} \mathcal{R}_{1}(t)$', '$\mathcal{R}_{1}(t)$', 'Interpreter','latex')
else
    ylabel(strcat('${\mathcal{R}_{-1}(t)}$'), 'Interpreter','latex')
    legend('$\mathcal{R}(t)$', 'Interpreter','latex')
end

end