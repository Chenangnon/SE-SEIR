#'
#' Spiked BSEIR data
#'
#' A simulated dataset from BSEIR model: epidemiological case data with spikes.
#'
#' @format ## `data.frame`
#' A data frame with 601 rows and 2 columns:
#' \describe{
#'   \item{Time}{Time points}
#'   \item{Ct}{Number of new positive cases at \code{Time}}
#'
#' }
#' @source simulated
"sbseir"

## Get data from a BSEIR model
#library(BSEIR)
#Bpars = BSEIR:::get.default.parameters()
#Bpars$params[6:7] <- 0 # add interaction between P and Q

#Bobj = SolveBSEIR(params = Bpars$params, y0 = Bpars$y0,
#                  Horizon = 300, timestep = 0.5)
#
#
#sbseir <- data.frame(Time = Bobj$Teval,
#                    Ct = Bobj$Ct)

# usethis::use_data(sbseir)
