# library(dplyr)
#'
#' Merge Short Transient Features
#'
#' This function provides \code{Sub-Algorithm B} of
#' \insertCite{harvey2023epidemiological;textual}{wavefinder} which identifies
#' pairs of peaks and trough separated by less than \code{duration_cen/2} and merges
#' them if they are transient. This is used by \link{WaveList} to merge short
#' transient features.
#'
#' @param data (Series): The original or smoothed data from which the peaks
#' and troughs are identified
#'
#' @param input_data_df \code{data.frame}, rows corresponding to peaks and
#' troughs to be potentially merged.
#'
#' @param endpoints \code{data.frame} of two rows (start and end of the
#' data series) and four columns (\code{location}, \code{prominence},
#' \code{y_position}, \code{peak_ind}).
#'
#' @param duration_cen numeric, threshold specifying which features should be investigated.
#'
#' @export algorithm_b
#'
#' @return
#' A \code{data.frame} with rows corresponding to left peaks and troughs
#' after merging.
#'
#' @references
#' \insertAllCited{}

algorithm_b <- function (data, input_data_df, duration_cen, endpoints) {

  # avoid overwriting sub_a when values replaced by t0 and t1
  df <- input_data_df
  df <- df[, c("location", "peak_ind", "y_position", "prominence")]

  # Compute left lags
  df$lag <- c(Inf, diff(df$location))

  # if there are fewer than 3 points, the algorithm terminates, return input unchanged
  if (nrow(df) <= 2) {
    return(df)
  }

  # Minimum distance to left extremum
  stopifnot(is.numeric(duration_cen), duration_cen >= 0)
  lag_min <- duration_cen / 2

  # indicator of features
  close_features <- df$lag < lag_min

  # Check if all local extrema have the required minimum distance to their left extremum
  if (any(close_features)) {
    df <- merge_features (df = df,
                          close_features = close_features,
                          duration_cen = duration_cen,
                          data = data)
  }

  df <- update_prominence (df, endpoints = endpoints)

  # recalculate lags
  df$lag <- c(Inf, diff(df$location))

  # regularize rownames of 'df'
  row.names(df) <- 1:nrow(df)

  df <- df[, c("location", "peak_ind", "y_position", "prominence", "lag")]

  return(df)
}


# merge features until no too close peak and trough
merge_features <- function (df, close_features, duration_cen, data) {

  if (nrow(df) < 3 | !any(close_features)) {
    # if there are fewer than 3 points, return input
    return(df)
  }

  # Minimum distance to left extremum
  lag_min <- duration_cen / 2

  nfeatures <- nrow(df)
  while (any(close_features) && nfeatures >= 3) {

    # Get the features ordered in increasing left lag values
    irr_features <- which (close_features)
    irr_features <- irr_features[order(df$lag[irr_features])]

    # Delete the first feature to be 'iregular'
    for (feature in irr_features) {
      df <- delete_feature (df,
                            feature = feature,
                            duration_cen = duration_cen,
                            data = data)

      if (nfeatures != nrow(df)) { # stop once a feature has been deleted
        break
      }
    }

    if (nfeatures == nrow(df)) { # stop if no feature has been deleted
      break
    }
    nfeatures <- nrow(df)

    # Still some too close features?
    close_features <- df$lag < lag_min
  }

  # df is a set of peaks and troughs which are at least a minimum distance apart
  return(df)
}

# b_delete_pairs
# Child function of 'b_merge_peaks'
delete_feature <- function (df, feature, duration_cen, data) {

  if (nrow(df) < 3) {
    return(df)
  }

  # indices of the left and right bounds of the window
  center <- floor((df$location[feature - 1] + df$location[feature]) / 2)
  positions <- c(max(floor(.5 * (df$location[feature - 1] + df$location[feature] - duration_cen)), 1),
                 min(floor(.5 * (df$location[feature - 1] + df$location[feature] + duration_cen)), length(data)))
  diffy <- diff(data[positions])

  if ((df$peak_ind[feature] == 0 & diffy > 0) | # the feature is a trough; but the signal bounced back to its level (within the censored time period)
      (df$peak_ind[feature] == 1 & diffy < 0)) { # the feature is a peak; but ...
    # Delete the pair (the peak and the trough)
    df <- df[- c(feature - 1, feature), , drop = FALSE]

    # recalculate lag
    df$lag <- c(Inf, diff(df$location))
  }

  return(df)
}

# Deprecated old code: unnecessarily too complex
#' @importFrom dplyr `%>%`
#' @importFrom dplyr arrange
algorithm_b0 <- function (data, input_data_df, duration_cen, endpoints) {

  # avoid overwriting sub_a when values replaced by t0 and t1
  df <- input_data_df
  if (nrow(df) <= 2) {
    # if there are fewer than 3 points, the algorithm cannot be run, return input unchanged
    return(df)
  }

  # Pre-define  global variable 'y_distance' to avoid the note "no visible binding for global variable ‘y_distance’"
  y_distance <- NULL

  # flag will be dropped once no pair is found
  sub_b_flag <- TRUE

  # dictionary to hold boundaries for peak-trough pairs too close to each other
  original_data <- list()

  while (sub_b_flag) {
    if (nrow(df) <= 2) {
      break
    }

    # separation here refers to temporal distance S_i
    df$separation <- c(NA, diff(df$location))

    # compute vertical distance V_i
    df$y_distance <- c(NA, abs(diff(df$y_position)))

    # sort in ascending order of height
    df <- df %>% arrange(y_distance)

    # set to false until we find an instance where S_i < duration_cen / 2
    sub_b_flag <- FALSE

    for (i in 2:nrow(df)) {
      if (!is.na(df$separation[i])) {
        if (df$separation[i] < duration_cen / 2) {
          sub_b_flag <- TRUE
          # i <- df$index[x]

          # store the original locations and values to restore them at the end
          original_t_0 <- df$location[i]
          original_t_1 <- df$location[i + 1]
          y_0 <- df$y_position[i]
          y_1 <- df$y_position[i + 1]

          # create boundaries t_0 and t_1 around the peak-trough pair
          t_0 <- max(floor((original_t_0 + original_t_1 - duration_cen) / 2), 0)
          t_1 <- min(floor((original_t_0 + original_t_1 + duration_cen) / 2), length(data))

          # add original locations and value to dictionary
          original_data[[t_0]] <- list(location = original_t_0, y_position = y_0)
          original_data[[t_1]] <- list(location = original_t_1, y_position = y_1)

          # reset the peak locations to the boundaries to be rechecked
          df$location[i] <- t_0
          df$location[i + 1] <- t_1
          df$y_position[i] <- data[as.integer(t_0)]
          df$y_position[i + 1] <- data[as.integer(t_1)]

          # run the resulting peaks for a prominence check
          df <- prominence_updater(df)

          break
        }
      }
    }
  }

  # restore old locations and heights
  if (length(original_data)) {
    for (key in 1:length(original_data)) { # key = t_0 or t_1
      val <- original_data[[key]] # val = list(location = original_t_0 or t_1, y_position = y_0 or y_1)
      if (!is.null(val)) {
        df$y_position[df$location == key] <- val$y_position
        df$location[df$location == key] <- val$location
      }
    }
  }

  # recalculate prominence: use 'prominence'

  # RIGHT HERE

  df <- prominence_updater(df)

  # recalculate lags
  lags <- diff(df$location)
  df$lags <- c(Inf, lags)

  return(df)
}
