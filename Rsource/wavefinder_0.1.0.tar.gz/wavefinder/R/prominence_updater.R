#
# NO LONGER USEFUL?! DELETE???
#
# library(dplyr)
# library(signal)
#'
#' Objects of class \code{ProminenceUpdater}
#'
#' @description
#' The \code{ProminenceUpdater} class provides methods to initialize and update
#' prominence values of peaks and troughs after retrial of some peaks or troughs
#' from a \code{WaveList} object.
#'
#' @details
#' The \code{ProminenceUpdater} class is implemented using the \link[R6]{R6Class} system.
#' The class has:
#' \describe{an *initialize*}{ method to extract the endpoints from the data;}
#' \describe{a *makeframe*}{ method to combine and format peaks and troughs into a dataframe; and}
#' \describe{a *run*}{ method to recalculate the prominence of peaks and troughs.}
#'
#' @export ProminenceUpdater
#' @importFrom R6 R6Class
#'
# Define the ProminenceUpdater class
ProminenceUpdater <- R6::R6Class("ProminenceUpdater",
                             public = list(

                               #' @field endpoints \code{data.frame} of two rows
                               #' (start and end of the data series) and four
                               #' columns (\code{location}, \code{prominence},
                               #' \code{y_position}, \code{peak_ind}).
                               endpoints = NULL,

                               #' @description
                               #' Initialize a new \code{'ProminenceUpdater'} class object.
                               #'
                               #' @param data numerical series: the original data from which the peaks and troughs are to be identified.
                                 initialize = function(data) {
                                 # Extract first and last element from a Series for use in run
                                 initial_value <- data[1]
                                 terminal_value <- data[length(data)]
                                 initial_location <- - 1
                                 terminal_location <- length(data) + 1

                                 self$endpoints <- data.frame(
                                   location = c(initial_location, terminal_location),
                                   prominence = rep(NA, 2),
                                   y_position = c(initial_value, terminal_value),
                                   peak_ind = rep(NA, 2)
                                 )
                               },

                               #' @description
                               #' Format results from prominence updater
                               #'
                               #' @param data numerical series: the original data from which the peaks and troughs are to be identified.
                               #' @param peak a vector of indices of peaks calculated \link[wavefinder]{find_peaks}.
                               #' @param peak_properties the properties of those peaks as returned from \link[wavefinder]{find_peaks}.
                               #' @param trough a vector of indices of troughs calculated by \link[wavefinder]{find_peaks}.
                               #' @param trough_properties the properties of those troughs as returned from \link[wavefinder]{find_peaks}.
                               #'
                               #' @return  data.frame containing the peaks and troughs found in \code{data}, along with their locations, prominences and values.
                               makeframe = function (data, peak, peak_properties, trough, trough_properties) {
                                 data <- as.data.frame(data)

                                 if (length(peak)) {
                                   peaks <- data[peak, ]
                                   peaks$prominence <- peak_properties$prominence
                                   peaks$peak_ind <- 1

                                   results <- peaks
                                 }
                                 else
                                   results <- NULL

                                 if (length(trough)) {
                                   troughs <- data[trough, ]
                                   troughs$prominence <- trough_properties$prominence
                                   troughs$peak_ind <- 0
                                   results <- rbind(results, troughs)
                                 }

                                 if (NROW(results)) {
                                   results <- results[order(results$location), ]
                                   rownames(results) <- NULL
                                 }

                                 return(results)
                               },

                               #' @description
                               #' Function to update prominence: take a data.frame of peaks and recalculate the prominences.
                               #'
                               #' @param data numerical series: the original data from which the peaks and troughs are to be identified.
                               run = function(data) {
                                 data <- data[, c("location", "prominence", "y_position", "peak_ind")]
                                 data <- rbind(data, self$endpoints)
                                 data <- data[order(data$location), ]
                                 y_vals <- data$y_position
                                 peak <- find_peaks(y_vals, prominence = 0, distance = 1)
                                 trough <- find_peaks(-y_vals, prominence = 0, distance = 1)
                                 results <- self$makeframe(data,
                                                           peak=peak$peak,
                                                           peak_properties = peak,
                                                           trough = trough$peak,
                                                           trough_properties = trough)
                                 return(results)
                               }
                             )
)

