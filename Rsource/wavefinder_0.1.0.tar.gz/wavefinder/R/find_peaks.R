# The function \code{find_peaks} is an attempted \code{R} equivalent of \code{Python}'s
# \code{find_peaks} in the Signal Processing Toolbox.
#
#' Find Peaks Inside a Signal
#'
#' Find peaks in a time series based on some specified peak properties. This
#' function takes a 1-D array and finds all local maxima. Optionally, a subset
#' of these peaks can be selected by specifying additional conditions as peak
#' properties.
#'
#' @param x numerical vector taken as a time series and representing a signal
#' with peaks.
#'
#' @param height either \code{NULL} (default), a numeric scalar: required height
#' of peaks. When not \code{NULL}, \code{height} specifies the minimal required
#' height of a peak in the series.
#'
#' @param distance either \code{NULL} (default), a non-negative number: required
#' minimal horizontal distance (\code{distance}\eqn{\geq 1}) in samples between
#' neighboring peaks. Smaller peaks are removed first until the condition is
#' fulfilled for all remaining peaks.
#'
#' @param width either \code{NULL} (default equivalents to \code{width = 2}), a
#' positive number: minimum required width of peaks in samples. If \code{width}
#' is a vector, the first element equal to 2 or more is extracted as supplied
#' \code{width}. Note that \code{width} must be equal to or less than
#' the number of data points in \code{x}. See section \code{'Details'}
#' for details on the definition of the \code{width} of a peak.
#'
#' @param prominence either \code{NULL} (default), a positive number: required
#' minimal prominence of peaks. See argument \code{'reference'} for more on the
#' definition of the \code{prominence} of a peak.
#'
#' @param reference character, specifying the reference point from which the
#' prominence of a peak will be computed, the prominence being the vertical
#' distance between a peak and the shallowest of the left and/or right trough (local
#' minimum) around the trough. The reference left and right troughs can be
#' chosen in three different ways: \code{reference = 'closest'} (the default)
#' takes the closest local point minimum on each side of the target peak; the
#' alternative is \code{reference = 'farthest'} which takes the two
#' limits of the basal segment (starting point at the left side to ending point
#' at the right side) of the target peak.
# and \code{reference = 'deepest'}
# which considers the global minimum over the basal area of the target peak.
#'
#' @export find_peaks
#'
#' @importFrom pracma findpeaks
#'
#' @details
#' \code{find_peaks} takes a 1-D array \code{x} as input, calls
#' \link[pracma]{findpeaks} which utilizes regular expressions to find
#' all spikes in \code{x}. It then filters out peaks that do not satisfy
#' certain properties specified by the optional arguments, and finally
#' returns the indices of the retained peaks, their prominence (vertical
#' significance) as well as their widths (horizontal base).
#'
#' \code{NA}s are not allowed: any missing value in \code{x} (as identified by
#' \code{is.na(x)}) results into an error.
#'
#' The prominence of a peak indicates its vertical significance, \code{i.e.}
#' the height of the peak above the surrounding valley. Argument \code{reference}
#' allows flexibility in the definition of the *surrounding valley*. The default
#' \code{reference = 'closest'} is the most restrictive and will in general
#' lead to smaller or equal (if none of the spikes is filtered out) prominence
#' values as compared to the alternative \code{reference = 'farthest'}.
#  and
# \code{reference = 'deepest'}.
#'
#' The width of a peak is defined as the duration of the peak pattern from increase
#' to decrease, i.e., the distance from where the increase starts before the peak
#' to where the decrease stops after the peak. When there is a flat trough
#' between two peaks, the medium point is placed at 'equal' distance between the
#' end of the left decrease pattern, and the start of the right increase pattern.
#' The first peak always starts at step \code{1}, and the last pattern
#' always ends at the last step (\code{length(x)}). When the number of steps
#' between two patterns is odd, the left pattern is given one step more
#' than the right pattern. Note that the sum of the widths of all peaks is the
#' length of \code{x}.
#'
#' @return An object of class \code{'peak'}, i.e. a named list with the
#' following elements:
#' \item{peak}{ vector of indices/positions of the final peaks in the series
#' \code{x}.}
#' \item{start}{ vector of starting step/points of the peaks.}
#' \item{width}{ vector of widths of the peaks.}
#' \item{prominence}{ vector of prominence of the peaks.}
#' \item{call}{ the matched call to \code{find_peaks.}}
# \item{x}{the supplied argument \code{x}.}
#' \item{spike}{ a five-column matrix of spikes (peaks). Each row of
#' \code{spike} corresponds to a spike in the data series \code{x}. The first
#' four columns are raw results from \link[pracma]{findpeaks} (from package
#' \code{pracma}), and the fifth column show the starting point of each peak.}
#'
#' The first three list elements are vectors of the same length (which can be
#' zero when there is no peak, or no peak meets the specified peak properties).
#'
#' The class \code{'peak'} has a succinct print method.
#'
# @note
# This function is build on the model of the function \code{find_peaks} of the
# Signal Processing Toolbox in \code{Python}. It is mainly used/wrapped in this
# package by \link[wavefinder]{algorithm_init} for the identification of peaks
# and troughs in a data series.
#
#' @seealso
#' \link{prominence} to calculate the *prominences* of selected peaks, and
#' \link{peaks_and_troughs} to list both peaks and troughs in a data series.
#'
#' @examples
#'
#' ### Example with many spikes (sbseir)
#'
#' library(wavefinder)
#' plot(sbseir$Time, sbseir$Ct, type="l", col="navy",
#'      xlab = "Time (day)", ylab = "New positive cases")
#' grid()
#'
#' # Find all peaks with height over 1000
#' pospeaks <- find_peaks(sbseir$Ct, height = 1000,
#'                        distance = 1, prominence = 0)
#' pospeaks
#'
#' # Find all troughs with height over 500
#' negpeaks <- find_peaks(-sbseir$Ct, height = c(- max(sbseir$Ct), -500),
#'                        distance = 1, prominence = 0)
#' negpeaks
#'
#' # Add peaks and troughs to a plot
#' points(sbseir$Time[pospeaks$peak], sbseir$Ct[pospeaks$peak], pch=20, col="maroon")
#' points(sbseir$Time[negpeaks$peak], sbseir$Ct[negpeaks$peak], pch=20, col="blue")
#'
#
# ### Example taken for package 'pracma'
#
# x <- seq(0, 1, len = 1024)
# pos <- c(0.1, 0.13, 0.15, 0.23, 0.25, 0.40, 0.44, 0.65, 0.76, 0.78, 0.81)
# hgt <- c(4, 5, 3, 4, 5, 4.2, 2.1, 4.3, 3.1, 5.1, 4.2)
# wdt <- c(0.005, 0.005, 0.006, 0.01, 0.01, 0.03, 0.01, 0.01, 0.005, 0.008, 0.005)
#
# pSignal <- numeric(length(x))
# for (i in seq(along=pos)) {
#   pSignal <- pSignal + hgt[i]/(1 + abs((x - pos[i])/wdt[i]))^4
# }
#
# # Find and plot all peaks with heights over 4
# peaks <- find_peaks(pSignal, height = 4)
# plot(pSignal, type="l", col="navy")
# grid()
# points(peaks$peak, pSignal[peaks$peak], pch=20, col="maroon")
#

# Modify and Optionally Use parSapply (matteSapply) instead of for loops
find_peaks <- function (x,
                        height = NULL, # rel_height = NULL, #threshold = NULL,
                        distance = NULL,
                        width = NULL,
                        prominence = NULL,
                        reference = 'closest') {
  # Save the call
  mcall <- match.call()

  # General argument checking
  stopifnot(is.numeric(x))
  x <- c(x)
  nax <- is.na(x)
  if (any(nax))
    stop("missing values not allowed in 'x'")
  tot_duration <- length(x)

  # No peak is possible if only two points in 'x'
  if (tot_duration < 3) {
    return(return.empty.peak())
  }

  # Find peaks and troughs using pracma::findpeaks
  spikes <- pracma::findpeaks (x) # Could have used argument ndowns = lag_min (see 'init_peaks_and_troughs')

  # Return empty vectors if no peak
  if (NROW(spikes) == 0) {
    return(return.empty.peak(spikes))
  }

  # Extract peaks (index/location/position)
  peaks <- spikes[,2]

  # peak starting points (used later to define widths)
  if ((npeaks <- length(peaks)) > 2) {
    # Starting point of each pattern (excluding the first and last peaks)
    peak_start <- cbind(spikes[-1, 3], spikes[-length(peaks), 4])
    peak_start <- (peak_start[,1] + peak_start[,2]) / 2
    peak_start <- ceiling(peak_start) # the starting pattern is shorter if odd number of between-steps
    peak_start <- c(1, peak_start)
  }
  else if (npeaks == 2) {
    # Starting point of each pattern
    peak_start <- (spikes[1,4] + spikes[2,3]) / 2
    peak_start <- ceiling(peak_start)
    peak_start <- c(1, peak_start)
  }
  else {
    peak_start <- 1
  }

  # Save peak_start in spikes
  spikes <- cbind(spikes, peak_start)
  colnames(spikes) <- c("height", "location", "start", "end", "start")

  # Filter peaks based on height
  if (!is.null(height)) {
    stopifnot(is.numeric(height))
    height <- height[1]
    peak_values <- x[peaks]
    keep <- peak_values >= height

    # Return empty vectors if no peak
    if (!any(keep)) {
      return(return.empty.peak(spikes))
    }

    # Update peaks and peak_start
    if (!all(keep)) {

      # Shift peak starting points
      peak_start <- move.peak_start (peak_start = peak_start, keep = keep,
                                     x = x, npeaks = npeaks)

      # Keep the selected peaks
      peaks <- peaks[keep]
    }
  }

  # Filter peaks based on distance
  if (!is.null(distance) & length(peaks) > 1) {
    stopifnot(is.numeric(distance), distance >= 0)
    peak_values <- x[peaks]
    if (distance > 1) {
      peaks <- merge_inliers.distance(peaks,
                                      peak_values = peak_values,
                                      peak_start = peak_start,
                                      distance = distance)
      peak_start <- peaks$peak_start
      peaks <- peaks$peaks
    }
  }

  # Get peak widths
  npeaks <- length(peaks)
  if (npeaks > 1)
    widths <- c(peak_start[-1], tot_duration) - peak_start
  else
    widths <- tot_duration

  # Filter peaks based on width
  if (!is.null(width) & npeaks > 1) {
    stopifnot(is.numeric(width))
    if (any(width > 1)) {
      # pick width
      pick_width <- width >= 2 & width >= tot_duration
      if (any(pick_width)) {
        width <- width[which(pick_width)[1]]
        stopifnot(width <= tot_duration)
      }
      else {
        width <- 2
      }
    }
    else {
      width <- 2
    }

    # Indicator of peaks satisfying the width condition
    keep <- widths >= width

    # Return empty vectors if no peak
    if (!any(keep)) {
      return(return.empty.peak(spikes))
    }

    if (!all(keep)) {
      peaks <- merge_inliers.width (peaks,
                                    peak_start = peak_start,
                                    x = x,
                                    width = width)
      peak_start <- peaks$peak_start
      peaks <- peaks$peaks

      # Recalculate peak widths
      npeaks <- length(peaks)
      if (npeaks > 1)
        widths <- c(peak_start[-1], tot_duration) - peak_start
      else
        widths <- tot_duration
    }
  }

  # Return empty vectors if no peak
  if (length(peaks) == 0) {
    return(return.empty.peak(spikes))
  }

  # Calculate peak prominence values
  reference <- match.arg(reference, choices = c('closest', 'farthest')) # , 'deepest'
  switch(reference,
         closest = {
           if (npeaks > 1) {
             left_bases <- find_bases(x = x, peaks=peaks, peak_start = peak_start, direction = "left")
             right_bases <- find_bases(x = x, peaks=peaks, peak_start = peak_start, direction = "right")
             prominences <- x[peaks] - pmax(x[left_bases], x[right_bases])
           }
           else {
             prominences <- max(x)
           }
         },
         farthest = {
           prominences <- x[peaks] - pmax(x[peak_start], x[c(peak_start[-1], tot_duration)])
         }
         #,
         #deepest = {
        #   thalweg <- if (npeaks > 1) sapply (1:(npeaks - 1),
         #                                     FUN = function (j) {
        #                                        indicesj <- peak_start[j]:peak_start[j + 1]

         #                                       return(min(x[indicesj]))
        #                                      })
         #  thalweg <- c(thalweg,
        #                min(x[peak_start[npeaks]:tot_duration]))

         #  prominences <- x[peaks] - thalweg
         #}
  )

  # Filter peaks based on prominence
  if (!is.null(prominence)) {
    stopifnot(is.numeric(prominence))
    prominence <- prominence[1]
    stopifnot(prominence >= 0)
    keep <- prominences >= prominence

    # Return empty vectors if no peak
    if (!any(keep)) {
      return(return.empty.peak(spikes))
    }

    # Keep qualified peaks
    if (!all(keep)) {
      switch(reference,
             closest = {

               # Shift peak starting points
               peak_start <- move.peak_start (peak_start = peak_start, keep = keep,
                                              x = x, npeaks = npeaks)

               # Keep the selected peaks
               peaks <- peaks[keep]
               npeaks <- length(peaks)

               # prominences stay unchanged
               prominences <- prominences[keep]
             },
             farthest = {
               while (!all(keep) & npeaks > 1) {
                 # Shift peak starting points
                 peak_start <- move.peak_start (peak_start = peak_start, keep = keep,
                                                x = x, npeaks = npeaks)

                 # Keep the selected peaks
                 peaks <- peaks[keep]
                 npeaks <- length(peaks)

                 # Recalculate prominences
                 prominences <- x[peaks] - pmin(x[peak_start], x[c(peak_start[-1], tot_duration)])
                 keep <- prominences >= prominence

               }

               # Return empty vectors if no peak (meaning npeaks = 1 but the peak has low prominence)
               if (!any(keep)) {
                 return(return.empty.peak(spikes))
               }
             },
             deepest = {
               while (!all(keep) & npeaks > 1) {
                 # Shift peak starting points
                 peak_start <- move.peak_start (peak_start = peak_start, keep = keep,
                                                x = x, npeaks = npeaks)

                 # Keep the selected peaks
                 peaks <- peaks[keep]
                 npeaks <- length(peaks)

                 # Recalculate prominences
                 thalweg <- sapply(1:(npeaks - 1),
                                   FUN = function (j) {
                                     indicesj <- peak_start[j]:peak_start[j + 1]

                                     return(min(x[indicesj]))
                                   })
                 thalweg <- c(thalweg,
                              min(x[peak_start[npeaks]:tot_duration]))

                 prominences <- x[peaks] - thalweg
                 keep <- prominences >= prominence

               }

               # Return empty vectors if no peak (meaning npeaks = 1 but the peak has low prominence)
               if (!any(keep)) {
                 return(return.empty.peak(spikes))
               }
             })
    }
  }

  # Get final peak widths
  npeaks <- length(peaks)
  if (npeaks > 1)
    widths <- c(peak_start[-1], tot_duration) - peak_start
  else
    widths <- tot_duration

  out <- list(peak = peaks,
              start = peak_start,
              width = widths,
              prominence = prominences,
              call = mcall,
              spike = spikes)
  return(structure(out, class = "peak"))
}

# Return empty vectors if no peak
return.empty.peak <- function(spike = NULL) {

  out <- list(peak = numeric(0),
              prominence = numeric(0),
              width = numeric(0),
              spike = spike)

  return(structure(out, class = "peak"))

}

# Merge peaks that are closer than the specified distance
merge_inliers.distance <- function (peaks, peak_values, peak_start, distance) {

  # Number of peaks
  npeaks <- length(peaks)

  # Distance to the left peak
  hdist <- diff(peaks)

  while (any(hdist < distance) & npeaks > 1) {
    # index of the peak at minimum distance
    themin <- which.min(hdist) # This is the real index in peak (and peak_values) minus 1
    # So if themin = j, then the two peaks of interest are at positions 'j' and j+1' in 'peak_values'

    # Find the peak to delete
    withdraw <- themin + which.min(peak_values[themin + 0:1]) - 1 # withdraw the smaller peak
    # withdraw = themin or themin + 1

    # Update peak_start
    if (withdraw == 1) {
      # nothing changes for the remaining peaks if withdraw == 1 (the second becomes the first, so it now starts at 1)
      peak_start <- peak_start[-2]
    }
    else if (withdraw == npeaks) {
      peak_start <- peak_start[-npeaks] # nothing changes for any peak
    }
    else {
      if (withdraw == themin) {
        peak_start[withdraw + 1] <- peak_start[withdraw]
      }
      peak_start <- peak_start[-withdraw]
    }

    # Delete the peak and its values in 'peak_values'
    peaks <- peaks[-withdraw]
    peak_values <- peak_values[-withdraw]

    # Update 'hdist'
    if (withdraw < npeaks) {
      hdist <- diff(peaks)
    }
    else {
      hdist <- hdist[-withdraw]
    }

    # update 'npeaks'
    npeaks <- npeaks - 1
  }

  return(list(peaks = peaks, peak_start = peak_start))
}

# Merge peaks that have width shorter than the specified width
merge_inliers.width <- function (peaks, peak_start, x, width) {
  # Number of peaks
  npeaks <- length(peaks)

  # Peak values
  peak_values <- x[peaks]

  if (npeaks == 1) { # Return the inputs
    return(list(peaks = peaks, peak_start = peak_start))
  }

  # Calculate widths
  tot_duration <- length(x)
  widths <- c(peak_start[-1], tot_duration) - peak_start

  while (any(widths < width)) {
    # index of the peak with the minimum width
    themin <- which.min(widths) # This is the real index in peak (and peak_values)

    # If themin is 1, merge the first peak with the second one
    if (themin == 1) {
      # nothing changes for the remaining peaks if themin == 1 (the second becomes the first, so it now starts at 1)
      peak_start <- peak_start[-2]

      # Find the peak to delete
      withdraw <- which.min(peak_values[1:2]) # withdraw the smaller peak
      # withdraw = 1 or 2

      # The peak is now at the highest of the first two peaks
      peaks <- peaks[-withdraw]
      peak_values <- peak_values[-withdraw]
    }
    else if (themin == npeaks) { # merge the last two peaks
      peak_start <- peak_start[-npeaks] # nothing changes for any peak

      # Find the peak to delete
      withdraw <- which.min(peak_values[c(npeaks - 1, npeaks)]) # withdraw the smaller peak
      # withdraw = 1 or 2

      # Transform into an index for 'peaks' and 'peak_values'
      withdraw <- if (withdraw == 1) npeaks - 1 else npeaks

      # The peak is now at the highest of the first two peaks
      peaks <- peaks[-withdraw]
      peak_values <- peak_values[-withdraw]
    }
    else {
      # Bounds (start and end points) of the target peak
      bounds <- peak_start[c(themin, themin + 1)]

      # We shall merge the target peak with the peak adjacent to the highest trough around the target
      withdraw <- which.max(x[bounds])
      # withdraw = 1 or 2

      # If the maximum is the trough is at the left side, the target peak now starts at the
      #    starting point of the left peak (themin = themin + withdraw - 1, since withdraw == 1)
      # If the maximum is the right peak, the peak now start at where the target started (remove
      #    position themin + 1 = themin + withdraw - 1, since withdraw == 2)
      peak_start <- peak_start[- (themin + withdraw - 1)]

      # Indices of the two peaks to withdraw one from. The target and:
      # the left when withdraw == 1 (then targets = c(themin -1, themin))
      # the left when withdraw == 2 (then targets = c(themin, themin + 1))
      targets <- c(themin + withdraw - 2, themin + withdraw - 1)

      # Pick the one with the lowest peak values to be withdraw
      withdraw <- targets[which.min(peak_values[targets])]

      # Remove the lower peak
      peaks <- peaks[-withdraw]
      peak_values <- peak_values[-withdraw]
    }

    # Update 'npeaks'
    npeaks <- npeaks - 1

    if (npeaks == 1) {
      break
    }
    else {
      # Recalculate widths
      widths <- c(peak_start[-1], tot_duration) - peak_start
    }
  }

  return(list(peaks = peaks, peak_start = peak_start))
}

# Functions used to compute prominence values ()
find_bases <- function (x, peaks, peak_start, direction) {
  if (direction == "left") {
    bases <- find_previous_minima (peaks = peaks, peak_start = peak_start, x = x)
  }
  else { # if (direction == "right")
    bases <- find_next_minima (peaks = peaks, peak_start = peak_start, x = x)
  }
  return(bases)
}

find_previous_minima <- function (peaks, peak_start, x) {
  bases <- sapply(1:length(peaks),
                 FUN = function(k) {
                   startend <- peak_start[k]:peaks[k]
                   peaksk <- pracma::findpeaks(- x[startend])[,2] # find all local minima on the left cliff of the peak
                   nk <- length(peaksk)
                   if (nk == 0) {
                     return(peak_start[k])
                   }
                   else if (nk == 1) {
                     return(peak_start[k] + peaksk - 1) # 'peaksk' must be 2 or more
                   }
                   else {
                     return(peak_start[k] + tail(peaksk, 1) - 1) # Take the last element of peaksk as 'peaksk'
                   }
                 })

  return(bases)
}

find_next_minima <- function (peaks, peak_start, x) {
  peak_end <- c(peak_start[-1], length(x))
  bases <- sapply(1:length(peaks),
                 FUN = function(k) {
                   startend <- peaks[k]:peak_end[k]
                   peaksk <- pracma::findpeaks(- x[startend])[,2] # find all local minima on the right cliff of the peak
                   nk <- length(peaksk)
                   if (nk == 0) {
                     return(peak_end[k])
                   }
                   else {
                     return(peaks[k] + peaksk[1] - 1) # Take the last element of peaksk as 'peaksk'
                   }
                 })

  return(bases)
}

# Decaler les peak_start
move.peak_start <- function (peak_start, keep, x, npeaks = length(peak_start)) {
  whichNOTkeep <- which(!keep)
  for (withdraw in whichNOTkeep) { # Loop IS NECESSARY, calculations at withdraw + 1 depend on withdraw
    if (withdraw == 1) {
      peak_start[2] <- 1 # Here the second peak starts at 1
    }
    else if (withdraw != npeaks) {
      # if (x[peaks[withdraw + 1]] > x[peaks[withdraw - 1]]) # If the right peak is higher than the left one
      if (x[peak_start[withdraw]] < x[peak_start[withdraw + 1]]) {
        peak_start[withdraw + 1] <- peak_start[withdraw] # Then we shift the start of the right peak to the left (toward the left o peak)
      }
      # Note that otherwise, starting points stay the same (only the end point of the left peak changes, but the right peak is already there to provide this information)
    }
    # Note that withdraw == npeaks, starting points stay the same (same reason as above): only the end point needs to be shifted
  }

  return(peak_start[keep])
}
