#'
#' Merge Low Prominence Waves
#'
#' This function provides \code{Sub-Algorithms C} and \code{D} of
#' \insertCite{harvey2023epidemiological;textual}{wavefinder}. It identifies
#' waves with low prominence and merges them.
#'
#' @export algorithm_c_and_d
#'
#' @importFrom dplyr arrange
#' @importFrom dplyr mutate
#' @importFrom dplyr row_number
#' @importFrom dplyr filter
#'
#' @param data numeric vector, the original data from which the peaks and
#' troughs are identified
#'
#' @param input_data_df \code{data.frame}, rows corresponding to peaks and
#' troughs to be merged.
#'
#' @param prominence_abs numeric (positive scalar), the minimum prominence
#' which a wave must have.
#'
#' @param prominence_rel numeric in the open \code{(0, 1)},
#' the minimum prominence which a peak must have, as a ratio of the value at the peak.
#'
#' @details
#' The function is used by \link{WaveList} to merge waves of low prominence.
#'
#' @return
#' A \code{data.frame} of the list of peaks and troughs after merging.
#'
#' @references
#' \insertAllCited{}

algorithm_c_and_d <- function (data,
                              input_data_df,
                              prominence_abs = NULL,
                              prominence_rel = 0.5) {

  if (nrow(input_data_df) <= 2) {
    # if there are fewer than 3 points, return input
    return(input_data_df)
  }

  # Pre-define globale variables (in 'df') to avoid the notes "no visible binding for global variable ‘peak_ind’, ‘prominence’, and ‘y_position’"
  peak_ind <- prominence <- y_position <- NULL

  df <- input_data_df
  df <- df %>% dplyr::arrange(location) %>% dplyr::mutate(row = dplyr::row_number())

  # filter out troughs and peaks below prominence threshold
  peaks <- df %>% dplyr::filter(peak_ind == 1) %>% dplyr::arrange(location) %>% dplyr::mutate(row = dplyr::row_number())
  troughs <- df %>% dplyr::filter(peak_ind == 0) %>% dplyr::arrange(location) %>% dplyr::mutate(row = dplyr::row_number())

  # filter out a peak and its corresponding trough if the peak does not meet the prominence threshold
  if (!is.null(prominence_abs))
    peaks_c <- peaks %>% dplyr::filter(prominence >= prominence_abs)
  else
    peaks_c <- peaks

  # filter out relatively low prominent peaks
  peaks_d <- peaks_c %>% dplyr::filter(prominence >= prominence_rel * y_position)

  # between each remaining peak, retain the trough with the lowest value
  df <- trough_finder(peaks_d, troughs, data, prominence_abs, prominence_rel)

  df <- df[, c("location", "peak_ind", "y_position", "prominence")]

  return(df)
}
