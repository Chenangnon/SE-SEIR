#
#' Peak Prominence
#'
#' Calculate the prominence or salience of a peak (i.e. its vertical significance)
#' relative to other target peaks and the inter-peak valleys. The prominence is
#' returned for each indexed peak in the supplied signal.
#'
#' @param peaks numerical, integer vector giving the locations of the target
#' peaks/local maxima (positions in \code{signal}).
#'
#' @param signal numerical vector, full original time series from which the
#' peaks were identified.
#'
#' @param reference character, specifying the reference point from which the
#' prominence of a peak will be computed, the prominence being the vertical
#' distance between a peak and the farthest left and/or right trough (local
#' minimum) around the trough. The reference left and right troughs can be
#' chosen in two different ways: \code{reference = 'closest'} (the default)
#' takes the closest local minimum point on each side of the target peak; the
#' alternative is \code{reference = 'farthest'} which considers the endpoints
#' of the basal segment of the target peak.
#'
#' @export prominence
#'
#' @details
#'
#' The original data series \code{signal} must have length 2 or more: no peak
#' can be identified from a signal with only two points.
#'
#' The prominence of a peak is calculated with respect to other (selected)
#' peaks and troughs in \code{signal}. For the default method
#' (\code{reference = 'closest'}), it is the difference between the peak
#' size (value of the signal at the peak) and the value of the signal at the
#' closest trough before (i.e. at the left of) or after (i.e. at the right of)
#' the peak, whichever is the maximum of these two local minima. The alternative
#' method \code{reference = 'farthest'} replaces the closest trough by the
#' endpoints of the basal area of the target peak.
#'
#' @return A named list of two vectors:
#' \item{prominence}{ the heights of the peaks above the surrounding valley, and}
#' \item{width}{ the widths of the peaks, i.e. the distance or 'time' steps
#'  from start (left valley) to end (right valley).}
#'
#' @examples
#' # Find all peaks with height over 1000, distant of 10 steps or more
#' library(wavefinder)
#' peaks <- find_peaks(sbseir$Ct, height = 1000, distance = 10)
#' peaks
#'
#' # Compute prominence values
#' prominence(peaks = peaks$peak, signal = sbseir$Ct)
#'

prominence <- function (peaks, signal, reference = 'closest') {

  # General argument checking
  stopifnot(is.numeric(signal))
  signal <- c(signal)
  nax <- is.na(signal)
  if (any(nax))
    stop("missing values not allowed in 'signal'")
  tot_duration <- length(signal)
  if (tot_duration < 3) {
    stop("'signal' must have length 2 or more")
  }
  reference <- match.arg(reference, choices = c('closest', 'farthest'))

  # Number of target peaks
  npeaks <- length(peaks)

  # Signal values at the peaks
  peak_values <- signal[peaks]

  # Define the starting point of each target peak in the signal
  if (npeaks == 1) {
    peak_start <- 1
  }
  else if (npeaks == 2) {
    # The valley (starting point of the second peak) is defined as lowest point between the two peaks
    peak_start <- c(1,
                    peaks[1] + which.min(signal[peaks[1]:peaks[2]]) - 1)
  }
  else {
  peak_start <- sapply(2:npeaks,
                       FUN = function (k) {
                         return(peaks[k-1] + which.min(signal[peaks[k-1]:peaks[k]]) - 1)
                       })
  peak_start <- c(1, peak_start)
  }

  # Compute prominence values
  switch(reference,
         closest = {
           if (npeaks > 1) {
             left_bases <- find_bases(x = signal, peaks=peaks, peak_start = peak_start, direction = "left")
             right_bases <- find_bases(x = signal, peaks=peaks, peak_start = peak_start, direction = "right")
             prominences <- signal[peaks] - pmax(signal[left_bases], signal[right_bases]) # pmin
           }
           else {
             prominences <- max(signal) # - max(signal[c(1, tot_duration)]) # SHOULD INCLUDE THIS
           }
         },
         farthest = {
           prominences <- signal[peaks] - pmax(signal[peak_start],
                                             signal[c(peak_start[-1], tot_duration)]) # pmin
         }
  )

  # Compute peak widths
  if (npeaks > 1)
    widths <- c(peak_start[-1], tot_duration) - peak_start
  else
    widths <- tot_duration

  return(list(prominence = prominences, width = widths))
}

# Fossil version of 'prominence' using loops (proposed by Chat GPT!)
get_prominences <- function (peaks, signal, reference = 'closest') {
  prominences <- rep(0, length(peaks))
  widths <- rep(0, length(peaks))



  prominences <- rep(0, length(peaks))
  widths <- rep(0, length(peaks))

  peak_values <- signal[peaks]

  for (i in 1:npeaks) {
    index <- peaks[i]
    left_min <- signal[index]
    right_min <- signal[index]
    left_index <- index
    right_index <- index

    while (left_index > 1 && signal[left_index] >= left_min) {
      left_min <- signal[left_index]
      left_index <- left_index - 1
    }

    while (right_index < length(signal) && signal[right_index] >= right_min) {
      right_min <- signal[right_index]
      right_index <- right_index + 1
    }

    prominences[i] <- peak_values[i] - min(left_min, right_min)
    widths[i] <- right_index - left_index
  }

  return(list(prominence = prominences, width = widths))
}
