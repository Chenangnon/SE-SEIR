#Sub-Algorithm A
# depends on 'dplyr'

#' Merge Waves of Short Duration
#'
#' This function implements \code{Sub-Algorithm A} of
#' \insertCite{harvey2023epidemiological;textual}{wavefinder} which merges
#' waves of short duration.
#'
#' @param input_data_df a \code{data.frame} object, listing peaks and troughs
#' to be potentially merged.
#'
#' @param duration_min numeric scalar (positive), threshold specifying minimum
#' wave duration.
#'
#' @param endpoints \code{data.frame} of two rows (start and end of the
#' data series) and four columns (\code{location}, \code{prominence},
#' \code{y_position}, \code{peak_ind}).
#'
#' @details
#' Merges 'short' waves of duration less than \code{duration_min} until no
#' short remains, or only two waves remain.
#'
#' @export algorithm_a
#'
#' @importFrom Rdpack insert_all_ref
# @importFrom dplyr lag
# @importFrom dplyr last
# @importFrom dplyr lead
# @importFrom dplyr first
# @import Rdpack
#'
#' @return
#'  A \code{data.frame} class object giving the final list of peaks and troughs
#'  after merging waves of short duration.
#'
#' @references
#' \insertAllCited{}
#'

algorithm_a <- function (input_data_df, duration_min, endpoints) {
  df <- input_data_df
  df <- df[, c("location", "peak_ind", "y_position", "prominence")]

  # update prominence values
  df <- update_prominence (df, endpoints = endpoints)

  if (nrow(df) < 3) {
    # if there are fewer than 3 points, the algorithm cannot be run, return input unchanged
    return(df)
  }

  # calculate the duration of extremum i as the distance between the extrema
  # to the left and to the right of i
  df <- rbind (df, endpoints)
  df <- df[order(df$location), ]
  df$duration <- NA
  peaks <- which(df$peak_ind == 1)
  peaks <- peaks[(peaks > 1) & (peaks < nrow(df))]
  df$duration[peaks] <- df$location[peaks + 1] - df$location[peaks - 1]
  df <- df[- c(1, nrow(df)), , drop = FALSE]

  # duration <- diff(df$location)
  #df$duration <- c(NA, duration) + c(duration, NA) # NAs ensure (i - 1) and (i + 1) stay in-bounds inside 'delete_pairs'
  #df$duration[df$peak_ind == 0] <- NA
  # df$location - dplyr::lag(df$location, default = dplyr::last(df$location)) - dplyr::lead(df$location, default = dplyr::first(df$location))

  if (!all(is.na(df$duration))) {
    while (min(df$duration, na.rm = TRUE) < duration_min && nrow(df) >= 3) {
      # remove peaks and troughs until the smallest duration meets T_SEP
      df <- delete_pairs(df, duration_min)

      # update prominence
      df <- update_prominence (df, endpoints = endpoints)

      # recalculate duration
      df <- rbind (df, endpoints)
      df <- df[order(df$location), ]
      df$duration <- NA
      peaks <- which(df$peak_ind == 1)
      peaks <- peaks[(peaks > 1) & (peaks < nrow(df))]
      df$duration[peaks] <- df$location[peaks + 1] - df$location[peaks - 1]
      df <- df[- c(1, nrow(df)), , drop = FALSE]
      #duration <- diff(df$location)
      #df$duration <- c(NA, duration) + c(duration, NA)
      #df$location - dplyr::lag(df$location, default = dplyr::last(df$location)) - dplyr::lead(df$location, default = dplyr::first(df$location))

      # recalculate duration
      if (nrow(df) < 3 | all(is.na(df$duration))) {
        break
      }
    }
  }

  # df is a set of peaks and troughs which are at least a minimum distance apart
  return(df)
}

# delete_pairs
# Child function of 'algorithm_a'
# Merges the least prominent wave in data which has duration < duration_min
delete_pairs <- function(data, duration_min) {
  if (min(data$duration, na.rm = TRUE) < duration_min && nrow(data) >= 3) {
    # extract waves of low duration
    low_duration <- data$duration < duration_min
    low_duration[is.na(low_duration)] <- FALSE
    df1 <- data[low_duration, , drop = FALSE]

    # extract those of least prominence
    if (nrow(df1) > 1)
      df2 <- df1[df1$prominence == min(df1$prominence, na.rm = TRUE), , drop = FALSE]
    else
      df2 <- df1

    # find the shortest wave
    i <- which(data$duration == min(df2$duration, na.rm = TRUE))[1]

    if (i == 1) { # Merge with the second wave: remove the first peak and its right trough
      data <- data[- c(1, 2), ]
    }
    else if (i == nrow(data)) {
      data <- data[- c(nrow(data) - 1, nrow(data)), , drop = FALSE]
    }
    else {

      is_peak <- data[i, 'peak_ind'] - 0.5 # No longer useful (always have data[i, 'peak_ind'] == 1, since duration = NA if data[i, 'peak_ind'] == 0)

      # remove whichever adjacent candidate is a greater minimum, (or a lesser maximum? already ruled out). If tied, remove the earlier.
      if (is_peak * (data[i + 1, 'y_position'] - data[i - 1, 'y_position']) > 0) {
        data <- data[-(i + 1), ]
        data <- data[-i, , drop = FALSE]
      }
      else {
        data <- data[-i, ]
        data <- data[-(i - 1), , drop = FALSE]
      }
    }
  }
  return(data)
}

