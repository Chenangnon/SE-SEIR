#'
#' @exportS3Method print peak
#'
print.peak <- function (x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"),
      "\n\n", sep = "")
  if (length(x$peak)) {
    cat("Peaks:\n")
    data <- eval(x$call$x)
    out <- cbind(Position = x$peak,
                 Height = data[x$peak],
                 Prominence = x$prominence,
                 Width = x$width)
    row.names(out) <- paste0("peak", 1:length(x$peak))
    print.default(format(out,
                         digits = digits),
                  print.gap = 2L,
                  quote = FALSE)
  }
  else cat("No peak\n")
  cat("\n")
  invisible(x)
}
