
# Function used by wavefinder to locate troughs between peaks as well as after
# the final peak
#
# Locates the deepest troughs in raw_data between and possibly after the peaks
# in peak_list from candidates in trough_list.
#
# @param peak_list data.frame of peaks in the time series.
#
# @param trough_list data.frame of troughs in the time series, one of which is to be
# retained between each consecutive pair of peaks.
#
# @param prominence_abs the minimum prominence which a wave must have.
# Used for adding a final trough.
#
# @param raw_data the time series
#
# @param proportional_prominence_threshold the minimum prominence which a peak
# must have, as a ratio of the value at the peak. Used for adding a final trough.
#
# @export trough_finder
#
# @return A data.frame containing the final list of peaks and troughs.
#

trough_finder <- function(peak_list,
                          trough_list,
                          raw_data,
                          prominence_abs,
                          prominence_rel) {

  peak_list <- peak_list[order(peak_list$location), ]
  results <- peak_list

  if (nrow(peak_list) > 1) {
    for (i in 1:(nrow(peak_list) - 1)) {
      wave_start <- as.integer(peak_list$location[i])
      wave_end <- as.integer(peak_list$location[i + 1])
      candidate_troughs <- trough_list[(trough_list$location >= wave_start) & (trough_list$location <= wave_end), ]

      if (nrow(candidate_troughs) > 0) {
        candidate_troughs <- candidate_troughs[which.min(candidate_troughs$y_position), ]
        results <- rbind(results, candidate_troughs)
      }
      else {
        trough_idx <- which.min(raw_data[wave_start:wave_end]$y_position)
        candidate_troughs <- data.frame(location = trough_idx, y_position = raw_data[trough_idx]$y_position)
        results <- rbind(results, candidate_troughs)
      }
    }
  }

  results <- results[order(results$location), ]

  # Add final trough after final peak
  if (nrow(peak_list) > 0 & nrow(trough_list)) {
    candidate_troughs <- trough_list[trough_list$location >= peak_list$location[nrow(peak_list)], ]

    if (nrow(candidate_troughs) > 0) {
      candidate_troughs <- candidate_troughs[which.min(candidate_troughs$y_position), ]
      final_maximum <- max(raw_data[seq_len(length(raw_data)) > candidate_troughs$location])

      if (candidate_troughs$y_position <= (1 - prominence_rel) * peak_list$y_position[nrow(peak_list)] &&
          peak_list$y_position[nrow(peak_list)] - candidate_troughs$y_position >= prominence_abs &&
          candidate_troughs$y_position <= (1 - prominence_rel) * final_maximum &&
          final_maximum - candidate_troughs$y_position >= prominence_abs) {
        results <- rbind(results, candidate_troughs)
      }
    }
  }

  return(results)
}

