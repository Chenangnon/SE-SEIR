# Load required libraries
#library(tidyverse)
#
#library(pracma)

#' Initialize a Wave-Finding Procedure
#'
#' DEPRECATED: replaced by \code{peaks_and_troughs}.
#'
#' This function identifies an initial list of peaks and troughs, optionally
#' removes (peaks, troughs) pairs with a troughs height above a specified
#' threshold and initializes a \code{'ProminenceUpdater'} for updating a
#' \link[wavefinder]{WaveList} object.
#'
#' @param data numerical series: the original data from which the peaks and
#' troughs are to be identified.
#'
#' @param distance either \code{NULL} or a non-negative number: required
#' minimal horizontal distance (\code{distance}\eqn{\geq 1}) in samples between
#' neighboring peaks. The specification \code{distance = NULL} is equivalent
#' to the default, \code{distance = 1}. Smaller peaks are removed first until
#' the condition is fulfilled for all remaining peaks.
#'
#' @param prominence either \code{NULL} (default), a non-negative number, or
#' a 2-element sequence of the former: required prominence of peaks. The first
#' element is always interpreted as the minimal and the second, if supplied,
#' as the maximal required prominence.
#'
#' @param trough_max maximal value of the data at an admissible trough. All
#' troughs above this threshold are ignored.
#'
#' @param lag_min either \code{NULL} (default), or a non-negative number
#' giving the minimal horizontal distance from a trough to its closest peak.
#' All troughs with a horizontal distance to any of the adjacent peaks under
#' this threshold are ignored. The default corresponds to
#' \code{lag_min = 0}.
#'
#' @export algorithm_init
#'
#' @details
#' The function calls the routines \link[wavefinder]{init_peaks_and_troughs} (to
#' which the arguments \code{prominence} and \code{distance} are passed) and
#' the public method \code{ProminenceUpdater$new()} of
#' \link[wavefinder]{ProminenceUpdater}.
#'
#' @return an object of class \code{prominence}, i.e. a four column
#' \code{'data.frame'} of peaks and troughs, as returned by
#' \link[wavefinder]{peaks_and_troughs}.
#'

# Define function: algorithm_init
algorithm_init <- function (data,
                            distance = NULL,
                            prominence = NULL,
                            trough_max = Inf,
                            lag_min = NULL) {
  if (length(data) == 0) {
    return(list(NULL, NULL))
  }

  peaks_initial <- peaks_and_troughs (data,
                                      distance = distance,
                                      prominence = prominence,
                                      trough_max = trough_max,
                                      lag_min = lag_min)

  class(peaks_initial) <- c('prominence',
                            class(peaks_initial))

  return(peaks_initial)
}


