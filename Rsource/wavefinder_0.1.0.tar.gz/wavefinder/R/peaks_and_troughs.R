#
#' List Peaks and Troughs
#'
#' Identify peaks (spikes) and troughs (counter-spikes) that satisfy some
#' peak, inter-peak or trough properties.
#'
#' @export peaks_and_troughs
#' @import dplyr
# Importing all of 'dplyr' to ensure we can use the pipe operator (%>%)
# @importFrom dplyr arrange
# @importFrom dplyr mutate
# @importFrom dplyr row_number
# @importFrom dplyr select
#'
#' @param data numerical series, the original data from
#' which the peaks and troughs are to be identified.
#'
#' @param height,distance,width,prominence required peak
#' properties. See \link[wavefinder]{find_peaks} for details.
#'
# @param distance either \code{NULL} (default), a non-negative number: required
# minimal horizontal distance (\code{distance}\eqn{\geq 1}) in samples between
# neighboring peaks. Smaller peaks are removed first until the condition
# is fulfilled for all remaining peaks.
#
# @param prominence either \code{NULL} (default), a positive number: required
# minimal prominence of peaks.
#
#' @param trough_max either \code{NULL} (default), or a number greater than the
#' minimum of the time series \code{data}, giving the maximal value of the data
#' at an admissible trough. All troughs above this threshold are ignored. The
#' default corresponds to \code{trough_max = Inf}.
#'
#' @param lag_min either \code{NULL} (default), or a non-negative number
#' giving the minimal left lag of a trough (horizontal distance from the
#' trough to its left peak). All troughs with a left lag under this threshold
#' are ignored. The default corresponds to \code{lag_min = 0}.
#'
#' @details
#' This function is a wrapper for the routine \link[wavefinder]{find_peaks}. It
#' passes arguments \code{height}, \code{distance}, \code{width} and
#' \code{prominence} to \link[wavefinder]{find_peaks} to find the peaks and
#' the troughs in \code{data} satisfying these properties. Then, some of the
#' peaks/troughs are filtered out based on the troughs properties
#' \code{trough_max} and \code{lag_min}.
#'
#' @return the list of all peaks and troughs in data, with their locations,
#' and prominence values. The returned object is a \code{'data.frame'} with four columns:
#' \itemize{\code{location}}{ locations of the peaks, if any, followed by the troughs, if any.}
#' \itemize{\code{prominence}}{ prominences of the peaks/troughs.}
#' \itemize{\code{peak_ind}}{ peak indicators, \code{1} if a peak, \code{0} if a trough.}
#' \itemize{\code{y_position}}{ values of the series at peak/troughs locations.}
#' \itemize{\code{lag}}{ distance/duration from a trough/peak to its left peak/trough.
#' The first extremum (always a peak) has left \code{lag} equal to \code{Inf}.}
#'
#' @examples
#' ### Example with many spikes (sbseir)
#' library(wavefinder)
#'
#' # Take the same series repeated twice
#' plot(c(sbseir$Time, tail(sbseir$Time, 1) + sbseir$Time[-1]),
#'      c(sbseir$Ct, sbseir$Ct[-1]),
#'      type="l", col="navy",
#'      xlab = "Time (day)", ylab = "New positive cases")
#' grid()
#'
#' # Find peaks with height over 100, and trough below 500, and peak-trough distance above 10 steps
#'
#' peaktroughs <- peaks_and_troughs (c(sbseir$Ct, sbseir$Ct[-1]),
#'                                   height = 100,
#'                                   trough_max = 500,
#'                                   lag_min = 10)
#' peaktroughs
#'


# UPDATE 'init_peaks_and_troughs' to avoid calling twice 'find_peaks'
# (use 'peak_start' saved in spikes ?)
peaks_and_troughs <- function (data,
                               height = NULL,
                               distance = NULL,
                               width = NULL,
                               prominence = NULL,
                               trough_max = NULL,
                               lag_min = NULL) { # all_below = NULL
  # Check 'data' argument
  stopifnot(!any(is.na(data)))
  data <- c(data)

  # Find spikes using find_peaks
  peak <- find_peaks (data,
                      height = height,
                      distance = distance,
                      width = width,
                      prominence = prominence)
  # trough <- find_peaks (-data, prominence = prominence, distance = distance,
                         #height = - trough_max)

  # Infer troughs from 'peak'
  if (length(peak$peak) == 1) {
    # Save the set of all spikes
    spikes <- data.frame (
      location = peak$spike[,2],
      peak_ind = rep(1, length(peak$spike[,2]))
    )

    # Sort the data frame by location
    spikes$height <- data[spikes$location]
    spikes <- spikes[order(spikes$location), , drop = FALSE]
    rownames(spikes) <- 1:NROW(spikes)

    # Create a data frame with location, prominence, peak indicator, and y position
    df <- data.frame (
      location = peak$peak,
      prominence = peak$prominence,
      peak_ind = 1,
      y_position = data[peak$peak]
    )

    # Sort the data frame by location
    df <- df[order(df$location), , drop = FALSE]

    # calculate the lag
    df$lag <- Inf

    df <- df[, c("location", "peak_ind", "y_position", "prominence", "lag"), drop = FALSE]

    return(structure(df, spikes = spikes))
  }

  trough <- peak$start[-1] # Was using the raw 'peak_start', i.e. 'peak$spike[,5]', but that may be longer, and it is independent of arguments 'distance' and 'prominence'!
  trough <- list(peak = trough,
                 prominence = prominence(peaks = trough,
                                         signal = - data)$prominence,
                 width = NA,
                 spike = cbind(NA, peak$start[-1]))

  # Save the set of all spikes
  spikes <- data.frame (
    location = c(peak$spike[,2], trough$spike[,2]),
    peak_ind = c(rep(1, length(peak$spike[,2])), rep(0, length(trough$spike[,2])))
  )

  # Sort the data frame by location
  spikes$height <- data[spikes$location]
  spikes <- spikes[order(spikes$location), , drop = FALSE]
  rownames(spikes) <- 1:NROW(spikes)

  # Minimum of the time series
  min_data <- min(data)[1]

  if (is.null(trough_max))
    trough_max <- Inf
  else {
    stopifnot(is.numeric(trough_max))
    trough_max <- trough_max[1]
    stopifnot(trough_max > min_data)
  }

  # Applying 'trough_max'
  if (is.finite(trough_max)) {
    # Save troughs that are the minimum of the series or satisfies y <= trough_max
    keep <- (data[trough$peak] <= trough_max) ## | (data[trough$peak] == min_data) | (data[trough$peak] < all_below) |
    if (any(keep)) {
      trough$peak <- trough$peak[keep]
      trough$prominence <- trough$prominence[keep]
      # trough$width <- trough$width[keep] # useless
    }
    else {
      trough$peak <- NULL
      trough$prominence <- NULL
    }
  }

  # Create a data frame with location, prominence, peak indicator, and y position
  df <- data.frame (
    location = c(peak$peak, trough$peak),
    prominence = c(peak$prominence, trough$prominence),
    peak_ind = c(rep(1, length(peak$peak)), rep(0, length(trough$peak))),
    y_position = data[c(peak$peak, trough$peak)]
  )

  # Sort the data frame by location
  df <- df[order(df$location), , drop = FALSE]

  # Check if there are successive extrema
  # If any, keep only the smallest trough or the highest peak

  # Index of any double/triple ... peak/trough cluster between two troughs/peaks
  duplicates <- diff(df$peak_ind) == 0
  while (any(duplicates)) {
    duplicates <- which(duplicates)
    startd <- duplicates[1]   # starting point of the duplicated/successive extrema
    endd <- duplicates[1] + 1 # end point if just two successive extrema

    npeaks <- length(df$peak_ind)
    nfixed <- length(duplicates)
    if (nfixed > 1) { # If many (more than two) successive points

      if (all(duplicates == seq(startd, startd + nfixed - 1, by = 1))) {
        # If all successive points form one block
        endd <- startd + nfixed
      }
      else { # otherwise, find the number of successive duplicates
        j <- endd + 1
        while (j <= npeaks) {
          if (df$peak_ind[j] == df$peak_ind[startd]) {
            endd <- j
            j <- j + 1
          }
          else {
            break
          }
        }
      }
    }

    # Keep only the smallest trough or the highest peak
    keep <- rep(TRUE, npeaks)
    startend <- startd:endd
    keep[startend] <- FALSE
    if (df$peak_ind[startd]) {
      # for a peak
      keep[startend[which.max(df$y_position[startend])[1]]] <- TRUE
    }
    else {
      # for a trough
      keep[startend[which.min(df$y_position[startend])[1]]] <- TRUE
    }

    df <- df[keep, , drop = FALSE]
    duplicates <- diff(df$peak_ind) == 0
  }

  # The first and last extrema must be maxima (the interest is in peaks, troughs must be between them)
  if (head(df$peak_ind, 1) == 0) {
    df <- df[-1, , drop = FALSE]
  }
  if (tail(df$peak_ind, 1) == 0) {
    df <- df[-nrow(df), , drop = FALSE]
  }

  # calculate the lag of peak/trough i as its distance to the left peak/trough
  # to the left and to the right of i
  # lag <- diff(df$location);
  # df$lag <- pmin(c(NA, lag), c(lag, NA), na.rm = TRUE) # NAs ensure (i - 1) and (i + 1) stay in-bounds inside 'init_delete_pairs'
  df$lag <- c(Inf, diff(df$location))

  # Check if all troughs have the required minimum distance to their left peaks
  if (!is.null(lag_min) & nrow(df) >= 3) {
    stopifnot(is.numeric(lag_min), lag_min >= 0)
    #close_troughs <- df$peak_ind == 0 # & (df$y_position != min_data)
    close_troughs <- (df$peak_ind == 0) & (df$lag < lag_min)
    if (lag_min > 0 & any(close_troughs)) {

      df <- init_merge_peaks (df = df,
                              close_troughs = close_troughs,
                              lag_min = lag_min)

      #if (all(close_troughs)) { # If no trough is far enough from its left peak, then no trough
      #  df <- data.frame (
      #    location = which.max(data),
      #    prominence = diff(range(data)),
      #    peak_ind = 1,
      #    y_position = max(data)[1],
      #    lag = Inf
      #  )
      #}
      #else {
      # Merge peaks if inter-trough is too close to left peak
      #df <- init_merge_peaks (df = df,
      #                        close_troughs = close_troughs,
      #                        lag_min = lag_min)
      #}
    }
  }

  # Regularize rownames of 'df'
  row.names(df) <- 1:nrow(df)

  df <- df[, c("location", "peak_ind", "y_position", "prominence", "lag"), drop = FALSE]

  return(structure(df, spikes = spikes))
}

# init_peaks_and_troughs <- peaks_and_troughs
# merge peaks until no too close trough
init_merge_peaks <- function (df, close_troughs, lag_min) {
  if (nrow(df) < 3 | !any(close_troughs)) {
    # if there are fewer than 3 points, the algorithm cannot be run, return input unchanged
    return(df)
  }

  # Create a function 'get.max_trough' to identify target trough (highest)
  eval(make.get.max_trough())

  while (any(close_troughs) && nrow(df) >= 3) { # Ensured to end since each and every iteration removes two rows from 'df'
    # Pick the highest trough
    trough <- get.max_trough (close_troughs = close_troughs, df = df)

    # Delete the trough and the lowest adjacent peak
    df <- init_delete_pairs(df,
                            trough = trough,
                            lag_min = lag_min)

    # Still some too close troughs?
    close_troughs <- (df$peak_ind == 0) & (df$lag < lag_min)
  }

  # df is a set of peaks and troughs which are at least a minimum distance apart
  return(df)
}

# Make a function to create a child function 'get.max_trough' to identify target trough
make.get.max_trough <- function() {
  expression(
    if (all(df$y_position >= 0)) { # If 'y_position' is non negative,
      get.max_trough <- function (close_troughs, df) { # we can use multiplication by close_troughs to ignore
        which.max(as.numeric(close_troughs) * df$y_position) # the 'y_position' of any ``non-close_troughs''
      }
    }
    else {
      get.max_trough <- function (close_troughs, df) {
        which(close_troughs & (df$y_position == max(df$y_position[close_troughs])))[1]
      }
    }
  )
}

# init_delete_pairs
# Child function of 'init_merge_peaks'
# Merges peaks separated by a trough at a distance (duration) < lag_min from its left peak
init_delete_pairs <- function (data, trough, lag_min) {
  if (data$lag[trough] < lag_min && nrow(data) >= 3) {

    ## Debugging code
    #ss <- c(data$y_position[trough + 1], data$y_position[trough - 1])
    #if (any(is.na(ss))) {
    #  stop("something went wrong: should not get here!")
      # browser()
    #}

    # Find the peak to be removed along with the target trough
    if (data$y_position[trough + 1] > data$y_position[trough - 1]) {

      # Delete the pair including the peak before the trough
      data <- data[- c(trough - 1, trough), , drop = FALSE]
    }
    else {

      # Delete the pair including the peak after the trough
      data <- data[- c(trough, trough + 1), , drop = FALSE]
    }

    # recalculate lag
    data$lag <- c(Inf, diff(data$location))
  }
  return(data)
}

