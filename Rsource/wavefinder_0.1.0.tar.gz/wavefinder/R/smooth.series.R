
#' @importFrom stats HoltWinters

# Smooth a time series before wave detection
smooth.series <- function (x, control = list()) {

  control <- do.call("control.smooth", control)

  if (identical(control$seasonal, "multiplicative") & any (x == 0)) {
    # If any zero in 'x', do the smoothing for each non zero interval separately


  }
  else {
    fit <- HoltWinters (x,
                        alpha = control$alpha,
                        beta = control$beta,
                        gamma = control$gamma,
                        seasonal = control$seasonal,
                        start.periods = control$start.periods,
                        l.start = control$l.start,
                        b.start = control$b.start,
                        s.start = control$s.start,
                        optim.start = control$optim.start,
                        optim.control = control$optim.control)

    y <- predict.HoltWinters (fit)

  }

  return(y)
}


# Sanitize control arguments for smoothing a time series
control.smooth <- function (alpha = NULL, beta = NULL, gamma = NULL,
                            seasonal = "multiplicative",
                            start.periods = 2,
                            l.start = NULL, b.start = NULL, s.start = NULL,
                            optim.start = c(alpha = 0.3, beta = 0.1, gamma = 0.1),
                            optim.control = list()) {
  seasonal <- match.arg(seasonal,
                        choices = c("additive", "multiplicative"),
                        several.ok = TRUE)


  list(alpha = alpha, beta = beta, gamma = gamma,
       seasonal = seasonal,
       start.periods = start.periods,
       l.start = l.start, b.start = b.start, s.start = s.start,
       optim.start = optim.start,
       optim.control = optim.control)
}
