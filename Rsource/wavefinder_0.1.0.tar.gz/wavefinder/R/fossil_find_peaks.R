
# @param height either \code{NULL} (default), a numeric, or a 2-element
# sequence of the former: required height of peaks. The first element is
# always interpreted as the minimal and the second, if supplied, as the
# maximal required height.
#
# @param prominence either \code{NULL} (default), a non-negative number, or
# a 2-element sequence of the former: required prominence of peaks. The first
# element is always interpreted as the minimal and the second, if supplied,
# as the maximal required prominence. See argument \code{'reference'}
# for more on the definition of the \code{prominence} of a peak.
#
# @param plateau_size either \code{NULL} (default equivalents to zero),
# or a non-negative number: required size of the flat top of peaks in samples.
# If \code{plateau_size} is a numeric vector, its first non-negative element
# is extracted and used as plateau size. Note that argument \code{plateau_size}
# can be useful to detect troughs in a series \code{x} (using
# \code{find_peaks(-x)}) large enough to indicate e.g. the end of patterns
# or waves.


# Modify and Optionally Use parSapply (matteSapply) instead of for loops?
fossil_find_peaks <- function (x,
                        height = NULL, # rel_height = NULL, #threshold = NULL,
                        distance = NULL,
                        width = NULL,
                        wlen = NULL,
                        plateau_size = NULL,
                        prominence = NULL) {
  # Save the call
  mcall <- match.call()

  # General argument checking
  stopifnot(is.numeric(x))
  x <- c(x)
  nax <- is.na(x)
  if (any(nax))
    stop("missing values not allowed in 'x'")

  # Find peaks using pracma::findpeaks
  pracma_peaks <- pracma::findpeaks (x)

  # Return empty vectors if no peak
  if (NROW(pracma_peaks) == 0) {
    return.empty.peak(pracma_peaks)
  }

  # Extract peak (index/position)
  peaks <- pracma_peaks[,2]

  # Filter peaks based on height
  if (!is.null(height)) {
    stopifnot(is.numeric(height)) #  all(height > 0)
    height <- unique(height)
    peak_values <- x[peaks]

    if (length(height) == 1)
      keep <- peak_values >= height
    else {
      keep <- peak_values >= height[1] & peak_values <= height[2]
    }

    # Return empty vectors if no peak
    if (!any(keep)) {
      return.empty.peak(pracma_peaks)
    }

    peaks <- peaks[keep]
  }

  # Filter peaks based on distance
  if (!is.null(distance) & length(peaks) > 1) {
    stopifnot(is.numeric(distance), distance >= 0)
    peak_values <- x[peaks]
    peaks <- reject_inliers0(peaks, peak_values = peak_values, distance = distance)
  }

  # Get peak widths
  left_bases <- find_bases(x, peaks, "left")
  right_bases <- find_bases(x, peaks, "right")
  widths <- right_bases - left_bases

  # Filter peaks based on width
  if (!is.null(width)) {
    if (length(width) > 1) {
      wlen <- width[2]
      width <- width[1]
    }

    # Default value for 'wlen'
    if (is.null(wlen)) {
      wlen <- 3
    }

    keep <- widths > width & widths < wlen

    # Return empty vectors if no peak
    if (!any(keep)) {
      return.empty.peak(pracma_peaks)
    }

    peaks <- peaks[keep]
    widths <- widths[keep]

  }

  # Filter peaks based on plateau size
  if (!is.null(plateau_size)) {
    stopifnot(is.numeric(plateau_size), all(plateau_size >= 0))
    if (plateau_size[1] > 0) {
      filtered_peak_indices <- sapply(peaks,
                                      FUN = filtered_peak_index,
                                      plateau_size = plateau_size,
                                      x = x)
      peaks <- peaks[filtered_peak_indices]
    }
  }

  # Return empty vectors if no peak
  if (length(peaks) == 0) {
    return.empty.peak(pracma_peaks)
  }

  # Get peak prominence values
  peak_values <- x[peaks]
  left_bases <- find_bases(x, peaks, "left")
  right_bases <- find_bases(x, peaks, "right")
  prominences <- peak_values - pmin(x[left_bases], x[right_bases])

  # Filter peaks based on prominence
  if (!is.null(prominence)) {
    stopifnot(is.numeric(prominence))
    if (length(prominence) == 1) {
      keep <- prominences > prominence
    }
    else {
      keep <- prominences > prominence[1] & prominences < prominence[2]
    }

    # Return empty vectors if no peak
    if (!any(keep)) {
      return.empty.peak(pracma_peaks)
    }

    peaks <- peaks[keep]


    # Recalculate prominences
    prominences <- prominences[keep]
  }

  out <- list(peak = peaks,
              prominence = prominences,
              width = widths,
              call = mcall,
              #x = x,
              spike = pracma_peaks)
  return(structure(out, class = "peak"))
}

reject_inliers0 <- function (peaks, peak_values, distance) {

  # Number of peaks
  npeaks <- length(peaks)

  # Distance to the left peak
  hdist <- diff(peaks)

  while (any(hdist < distance) & npeaks > 1) {
    # index of the peak at minimum distance
    themin <- which.min(hdist) # This is the real index in peak (and peak_values) minus 1
    # So if themin = j, then the two peaks of interest are at positions 'j' and j+1' in 'peak_values'

    # Find the peak to delete
    withdraw <- which.min(peak_values[themin + 0:1]) # withdraw the smaller peak

    # Delete the peak and its values in 'peak_values'
    peaks <- peaks[-withdraw]
    peak_values <- peak_values[-withdraw]

    # Update 'hdist'
    if (withdraw < npeaks) {
      hdist <- diff(peaks)
    }
    else {
      hdist <- hdist[-withdraw]
    }

    # update 'npeaks'
    npeaks <- npeaks - 1
  }

  return(peaks)
}



filtered_peak_index <- function(peak_index, plateau_size, x) {
  plateau_start <- max(1, peak_index - plateau_size[1])
  plateau_end <- min(length(x), peak_index + plateau_size)
  plateau <- x[plateau_start:plateau_end]
  keep <- x[peak_index] == max(plateau)
  return (keep)
}

# Example usage
#signal <- c(1, 2, 3, 2, 1, 2, 3, 4, 3, 2, 1)
#result <- find_peaks(signal, prominence = 0.5, width = 2)
#peak_indices <- result$indices
#peak_heights <- result$heights

#print(peak_indices)   # Indices of the peaks
#print(peak_heights)   # Heights of the peaks


# @import pracma
# Note that in R, you need to install the pracma package using install.packages("pracma") before running the code.
#find_peaks0 <- function(x, height=NULL, threshold=NULL, distance=1,
#                       prominence=0, width=NULL, wlen=NULL,
#                       rel_height=0.5, plateau_size=NULL) {
#
#  peaks <- pracma::findpeaks (x, nups = 1, ndowns = nups, zero = "0", peakpat = NULL,
#                              minpeakheight = -Inf, minpeakdistance = 1,
#                              threshold = 0, npeaks = 0, sortstr = FALSE)
#}

# Fossil code used in lieu of 'pracma::findpeaks'
fossil_find_peaks0 <- function () {
  expression({
    # Calculate first difference
    dx <- diff(x)

    # Mask any plateau
    zerodx <- dx == 0
    if (any(zerodx[-1])) { # Ensure there is no zero in 'dx', except maybe the first element
      while(any(zerodx[-1])) {
        zerodx <- which(zerodx)
        dx[zerodx] <- dx[pmax(1, zerodx - 1)]
        zerodx <- dx == 0
      }
    }

    # Find zero-crossings of the first difference
    zero_crossings <- which(dx[-1] * dx[-length(dx)] < 0)

    if (length(zero_crossings) == 0) {
      return(list(peak = numeric(0), prominence = numeric(0), width = numeric(0)))
    }

    # Find the peaks using zero-crossings and relative_height
    peaks <- numeric(0)
    for (i in zero_crossings) {
      if (dx[i] > 0 && dx[i+1] < 0 && x[i+1] > rel_height * max(x[i], x[i+2])) {
        peaks <- c(peaks, i+1)
      }
    }

  })
}

# Function used to compute prominence values
find_bases0 <- function (x, peaks, direction) {
  if (direction == "left") {
    bases <- find_previous_minima0(x, peaks)
  }
  else { # if (direction == "right")
    bases <- find_next_minima0(x, peaks)
  }
  return(bases)
}

find_previous_minima0 <- function(x, peaks) {
  bases <- numeric(0)
  for (peak in peaks) {
    prev_min <- peak - 1
    while (prev_min > 1 && x[prev_min] >= x[prev_min - 1]) {
      prev_min <- prev_min - 1
    }
    bases <- c(bases, prev_min)
  }
  return(bases)
}

find_next_minima0 <- function(x, peaks) {
  bases <- numeric(0)
  for (peak in peaks) {
    next_min <- peak + 1
    while (next_min < length(x) && x[next_min] >= x[next_min + 1]) {
      next_min <- next_min + 1
    }
    bases <- c(bases, next_min)
  }
  return(bases)
}

# Find peaks inside a signal.
#
# Find peaks in a time series based on some specified peak properties. This
# function takes a 1-D array and finds all local maxima by simple comparison
# of neighboring values. Optionally, a subset of these peaks can be selected
# by specifying additional conditions as peak properties.
#
# @param x numerical vector taken as a time series and representing a signal with peaks.
#
# @param height either \code{NULL} (default), a positive
# number, or a 2-element sequence of the former: required height of peaks.
# The first element is always interpreted as the minimal and the second,
# if supplied, as the maximal required height.
#
# @param rel_height numeric scalar, used to avoid the identification of
# subsequent spikes as peaks. E.g., \code{rel_height = 0.5}  means that the
# size of a the signal right after a peak must be at least half the maximum
# of the peak and the second signal after the peak. Defaults to \code{NULL}
# which is equivalent to \code{rel_height = 0}.
#
# @param threshold either \code{NULL} (default), a positive
# number, or a 2-element sequence of the former: required threshold of peaks,
# \code{i.e.}, the vertical distance to its neighboring samples.  The first
# element is always interpreted as the minimal and the second, if supplied,
# as the maximal required threshold.
#
# @param distance either \code{NULL} (default), a non-negative number: required
# minimal horizontal distance (\code{distance}\eqn{\geq 1}) in samples between neighboring peaks.
# Smaller peaks are removed first until the condition is fulfilled for all remaining peaks.
#
# @param width either \code{NULL} (default), a positive number or or 2-element
# sequence of the former: required width of peaks in samples. The first element
# is always interpreted as the minimal and the second, if supplied, as the
# maximal required width.
#
# @param wlen a positive number or \code{NULL} (default, meaning \code{wlen = 3}).
# Used as maximum peak width when \code{width} is not \code{NULL}, thus it is
# only used if \code{width} is given but has only one element.
#
# @param plateau_size either \code{NULL} (default), or a non-negative number:
# required size of the flat top of peaks in samples.
#
# @param prominence either \code{NULL} (default), a non-negative number, or
# a 2-element sequence of the former: required prominence of peaks. The first
# element is always interpreted as the minimal and the second, if supplied,
# as the maximal required prominence.
#
# The prominence of a peak is the difference between the peak size (value of the
# signal at the peak) and the value of the signal at the closest trough before
# (i.e. at the left of) or after (i.e. at the right of) the peak, whichever is
# the minimum of these two minima.
#
# @export find_peaks
#
# @details
# \code{find_peaks} is a low level function that takes a 1-D array \code{x} as
# input and returns the indices of the peaks, their prominence (vertical
# significance) as well as their widths (horizontal base).
# It also supports optional parameters for additional filtering of the peaks.
#
# The function uses the first-order difference of the signal to find points
# where the difference changes from positive to negative, indicating the presence
# of a peak. It then filters out peaks that are not higher than their neighboring
# points to obtain the final set of peaks.
#
# \code{NA}s are not allowed: any missing value in \code{x} (as identified by
# \code{is.na(x)}) results into an error.
#
# @return a named list with the following elements:
# \item{peak}{index of the peaks in the series \code{x}.}
# \item{prominence}{prominence of the peaks.}
# \item{widths}{widths of the peaks.}
#
# These list elements are vectors of the same length (which can be zero when
# there is no peak, or no peak meets the specified peak properties).
#
# @note
# This function is build on the model of the function \code{find_peaks} of the Signal Processing
# Toolbox in \code{Python}. It is used/wrapped by \link[wavefinder]{algorithm_init}
# for the identification of peaks and trough in a data series.
#
# @seealso For an alternative to \code{find_peaks}, see \link[pracma]{findpeaks} of the \code{pracma} package.
#
