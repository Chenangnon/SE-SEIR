# This is for "wavelist.py"

# library(dplyr)
#'
#' Objects of class \code{WaveList}
#'
#' @description
#' A \code{WaveList} class object holds a time series, the parameters used to
#' find waves in the time series, and the waves identified at different stages
#' of the algorithm. This class provides a simple interface to the successive
#' use of \code{Sub-Algorithms A}, \code{B}, \code{C} and \code{D} of
#' \insertCite{harvey2023epidemiological;textual}{wavefinder} to find waves in
#' an epidemiological data.
#'
#' @export WaveList
#'
#' @details
#' The \code{WaveList} class is implemented using the \link[R6]{R6Class} system.
#' The class has:
#' \describe{an *initialize*}{ method to create an instance of the
#' \code{WaveList} class, set parameters and call \code{run} to execute
#' the full wave detection algorithm;}
#' \describe{a *waves*}{ method to extract the most recent list of peaks
#' and troughs;}
#' \describe{a *run*}{ method to find the list of peaks and troughs
#' in raw_data, then calls the \code{Sub-Algorithms A}, \code{B}, \code{C} and
#' \code{D} to find the waves; and}
#' \describe{a *cross_validate*}{ method to impute additional waves in
#' a \code{WaveList} object (stored in the field \code{peaks_cross_validated}).}
#'
#' @references
#' \insertAllCited{}
#'
#  waves (DataFrame): An alias for peaks_cross_validated if calculated, else peaks_sub_c, for better access to the final results.
#  Index: RangeIndex
#  Columns:
#   location: The index of the peak or trough within raw_data.
#   y_position: The value of the peak or trough within raw_data.
#   prominence: The prominence of the peak or trough (as calculated with respect to other peaks and troughs, not with respect to all of raw_data).
#   peak_ind: 0 for a trough, 1 for a peak.

# METHODS
#  __init__: After setting the parameters, this calls run to immediately execute the algorithm.
#  waves: Gets the most recent list of peaks and troughs
#  run: Finds the list of peaks and troughs in raw_data, then calls the Sub-Algorithms A, B, C and D to find the waves.
#  cross_validate: Imputes the presence of additional waves in the from those in a second wavelist.

# WRITE THE ROUTINE 'plot_cross_validator'

WaveList <- R6::R6Class(classname = "WaveList",
                        public = list(
                          #'
                          #' @field raw_data numerical vector, the original data
                          #' series.
                          raw_data = NULL,
                          #'
                          #' @field series_name character, the name of the series,
                          #' for labeling plots.
                          series_name = 'New positives',
                          #'
                          #' @field smooth.data logical, should the data series
                          #' be smoothed before processing? Only used when
                          #' \code{data} is \code{NULL}.
                          #'
                          #' NOT YET IMPLEMENTED
                          #'
                          smooth.data = FALSE,
                          #'
                          #' @field control.smooth list, control argument for smoothing
                          #' \code{raw_data}. Only used when \code{data = NULL}
                          #' and \code{smooth.data = TRUE}. Elements passed to
                          #' \link[stats]{HoltWinters} which does the smoothing.
                          control.smooth = list(),
                          #'
                          #' @field data numerical vector, the (non) smoothed
                          #' data series from which peaks and troughs are identified.
                          #' This is set to \code{raw_data} when \code{smooth = FALSE}.
                          data = NULL,
                          #'
                          #' @field endpoints \code{data.frame} of two rows
                          #' (start and end of the data series) and four
                          #' columns (\code{location}, \code{prominence},
                          #' \code{y_position}, \code{peak_ind}).
                          endpoints = NULL,
                          #'
                          #' @field trough_max numeric, maximal value of the data
                          #' at an admissible trough. All troughs in the data above this
                          #' threshold are ignored.
                          trough_max = Inf,
                          #'
                          #' @field lag_min either \code{NULL} (default), or
                          #' a non-negative number giving the minimal horizontal
                          #' distance from a trough to its closest peak
                          lag_min = 3,
                          #'
                          #' @field duration_min numeric, threshold specifying
                          #' minimum wave duration.
                          duration_min = 7,
                          #'
                          #' @field duration_cen numeric, threshold specifying the
                          #' duration of the time window to identify and discard
                          #' irregular features as waves.
                          duration_cen = 6,
                          #'
                          #' @field prominence_abs numeric (positive real),
                          #' the minimum prominence which a wave must have.
                          prominence_abs = NULL,
                          #'
                          #' @field prominence_rel numeric in
                          #' the open \code{(0, 1)}, the minimum prominence which
                          #' a peak must have, as a ratio of the value at the peak.
                          prominence_rel = 0.5,
                          #'
                          #' @field spikes \code{data.frame} listing primary spikes
                          #' and anti-spikes (peaks and troughs) in \code{data}.
                          spikes = NULL,
                          #'
                          #' @field peaks_initial \code{data.frame} listing initial
                          #' peaks and troughs in \code{data} after filtering based
                          #' on \code{trough_max}, and \code{lag_min}.
                          peaks_initial = NULL,

                          #' @field peaks_sub_a \code{data.frame} listing remaining
                          #' peaks and troughs after Sub-Algorithm A has merged short waves.
                          peaks_sub_a = NULL,
                          #'
                          #' @field peaks_sub_b \code{data.frame} listing peaks and troughs after
                          #' Sub-Algorithm B has merged short transient features.
                          peaks_sub_b = NULL,
                          #'
                          #' @field peaks_sub_c \code{data.frame} listing peaks and troughs after
                          #' Sub-Algorithms C and D have merged less prominent waves.
                          peaks_sub_c = NULL,
                          #'
                          #' @field peaks_cross_validated \code{data.frame} listing peaks and troughs
                          #' after cross-validation.
                          peaks_cross_validated = NULL,

                          #' @description
                          #' Creates the \code{'WaveList'} object
                          #' and calls \code{run} to find the
                          #' waves using the set parameters.
                          #'
                          #' @param raw_data numeric, the original data from
                          #' which the peaks and troughs are identified.
                          #'
                          #' @param series_name character, the name of the
                          #' series, for labeling plots
                          #'
                          #' @param duration_min integer, threshold specifying
                          #' minimum wave duration.
                          #'
                          #' @param duration_cen integer, censored window length.
                          #'
                          #' @param trough_max non negative real, maximal value
                          #' of the data at an admissible trough
                          #'
                          #' @param lag_min non-negative numeric, threshold
                          #' specifying the minimal horizontal distance from a trough to its closest peak.
                          #'
                          #' @param prominence_abs the minimum prominence
                          #' which a wave must have.
                          #'
                          #' @param prominence_rel numeric in the
                          #' open \code{(0, 1)}, proportional prominence threshold.
                          #
                          initialize = function(raw_data,
                                                series_name = 'New positives',
                                                duration_min = 7,
                                                duration_cen = 6,
                                                trough_max,
                                                lag_min,
                                                prominence_abs = NULL,
                                                prominence_rel = 0.5) {
                            # input data
                            self$raw_data <- raw_data
                            self$series_name <- series_name

                            # configuration parameters
                            if (!missing(trough_max))
                              self$trough_max <- trough_max
                            if (!missing(lag_min))
                              self$lag_min <- lag_min
                            stopifnot(duration_cen < duration_min)
                            self$duration_min <- duration_min
                            self$duration_cen <- duration_cen
                            self$prominence_abs <- prominence_abs
                            self$prominence_rel <- prominence_rel

                            # peaks and troughs of waves are calculated by run()
                            self$run()
                          },

                          #' @description
                          #' Gets the most recent list
                          #' of peaks and troughs
                          #'
                          waves = function() {
                            if (!is.null(self$peaks_cross_validated)) {
                              return (self$peaks_cross_validated)
                            }
                            else {
                              return(self$peaks_sub_c)
                            }
                          },

                          #' @description
                          #' Finds the list of peaks
                          #' and troughs in raw_data,
                          #' then calls the Sub-Algorithms
                          #' A, B, C and D to find the waves.
                          #'
                          run = function() {
                            # smooth the data if required
                            if (is.null(self$data)) {
                              if (self$smooth.data) {
                                self$data <- smooth.series (self$raw_data, control = self$control.smooth)
                              }
                              else {
                                self$data <- self$raw_data
                              }
                            }

                            # Extract first and last element from a Series for use in run
                            self$endpoints <- data.frame (
                              location = c(1, length(self$data)),
                              peak_ind = rep(0, 2),
                              y_position = c(self$data[1], self$data[length(self$data)]),
                              prominence = rep(NA, 2)
                            )

                            # Initial List Peaks and Troughs
                            peaks_initial <- peaks_and_troughs (self$data,
                                                                distance = 1,
                                                                prominence = 0,
                                                                trough_max = self$trough_max,
                                                                lag_min = self$lag_min)

                            self$spikes <- attr(peaks_initial, "spikes")

                            # Calculate peaks_sub_a using algorithm_a
                            peaks_sub_a <- algorithm_a (input_data_df = peaks_initial,
                                                        endpoints = self$endpoints,
                                                        duration_min = self$duration_min)

                            # Calculate peaks_sub_b using algorithm_b
                            peaks_sub_b <- algorithm_b (data = self$data,
                                                        input_data_df = peaks_sub_a,
                                                        endpoints = self$endpoints,
                                                        duration_cen = self$duration_cen)

                            # Calculate peaks_sub_c using algorithm_c_and_d
                            peaks_sub_c <- algorithm_c_and_d (data = self$data,
                                                              input_data_df = peaks_sub_b,
                                                              prominence_abs = self$prominence_abs,
                                                              prominence_rel = self$prominence_rel)

                            self$peaks_initial <- peaks_initial
                            self$peaks_sub_a <- peaks_sub_a
                            self$peaks_sub_b <- peaks_sub_b
                            self$peaks_sub_c <- peaks_sub_c
                          },

                          #' @description
                          #' Imputes the presence of
                          #' additional waves from those
                          #' in \code{reference_wavelist}
                          #' and stores them in
                          #' \code{peaks_cross_validated}.
                          #'
                          #' @param reference_wavelist a \code{'WaveList'} object
                          #' which will be used to impute the additional waves.
                          #'
                          #' @param plot logical, whether the output should be plotted.
                          #'
                          #' @param plot_path path to save (or connection to) the
                          #' location to store plots. description.
                          #'
                          #' @param title character, title for plots.
                          #'
                          #' @return a \code{data.frame} with the peaks and troughs
                          #' after cross-validation against \code{reference_wavelist}.
                          cross_validate = function (reference_wavelist,
                                                     plot = FALSE,
                                                     plot_path = "",
                                                     title = "") {
                            # cross_validate
                            # Imputes the presence of additional waves from those in a reference_wavelist and stores them in peaks_cross_validated.
                            #
                            # Parameters:
                            #    reference_wavelist (WaveList): The WaveList object which will be used to impute the additional waves.
                            #    plot (bool): Whether the output should be plotted.
                            #    plot_path (str): Location to store plots.
                            #    title (str): Title for plots

                            # Returns:
                            #    cross_validate(reference_wavelist, plot, plot_path, title): A DataFrame with the peaks and troughs after
                            #    cross-validation against reference_wavelist.

                            # Extract relevant data and parameters from the WaveList objects
                            prominence_abs = self$prominence_abs
                            prominence_rel = self$prominence_rel

                            input_data = self$data
                            input_sub_b = self$peaks_sub_b
                            input_sub_c = self$peaks_sub_c

                            reference_sub_c <- reference_wavelist$peaks_sub_c
                            reference_peaks <- reference_sub_c[reference_sub_c$peak_ind == 1, "location"]
                            reference_troughs <- reference_sub_c[reference_sub_c$peak_ind == 0, "location"]

                            results <- input_sub_c

                            # iterate through the waves in the reference time series
                            for (i in seq_along(reference_peaks)) {
                              window_start <- ifelse(i > 1,
                                                     reference_troughs[i - 1], 0)
                              window_end <- ifelse(i <= length(reference_troughs),
                                                   reference_troughs[i],
                                                   input_data$index[length(input_data$index)])

                              if (any(input_sub_c[input_sub_c$peak_ind == 1, "location"] >= window_start &
                                      input_sub_c[input_sub_c$peak_ind == 1, "location"] <= window_end)) {
                                next
                              }

                              candidates <- input_sub_b[input_sub_b$peak_ind == 1 &
                                                          input_sub_b$location >= window_start &
                                                          input_sub_b$location <= window_end, ]

                              if (nrow(candidates) > 0) {
                                new_peak <- candidates[which.max(candidates$y_position), ]
                                results <- rbind(results, new_peak)
                              }
                            }

                            result_troughs <- input_sub_b[input_sub_b$peak_ind == 0, ]
                            results <- results[results$peak_ind == 1, ]
                            results <- trough_finder(peak_list = results,
                                                     trough_list = result_troughs,
                                                     raw_data = input_data,
                                                     prominence_abs = prominence_abs,
                                                     prominence_rel = prominence_rel)

                            if (plot) {
                              plot_cross_validator(self, reference_wavelist, results, title, plot_path)
                            }

                            self$peaks_cross_validated <- results

                            return(results)
                          }
                        )
)

# Create an instance of the WaveList class
#raw_data <- # Provide the raw data
#  series_name <- # Provide the series name
#  duration_min <- # Provide the duration_min value
#  prominence_abs <- # Provide the prominence threshold value
#  prominence_rel <- # Provide the prominence height threshold value
#
#  wavelist <- WaveList$new(raw_data, series_name, duration_min, prominence_abs, prominence_rel)

## Access the waves (peaks and troughs)
# waves <- wavelist$waves

#algorithm_init <- function(raw_data) {
# Implementation of algorithm_init function
#}

#algorithm_a <- function(input_data_df, prominence_updater, duration_min) {
# Implementation of algorithm_a function
#}

#algorithm_b <- function(raw_data, input_data_df, prominence_updater, duration_min) {
# Implementation of algorithm_b function
#}

#algorithm_c_and_d <- function(raw_data, input_data_df, prominence_abs, prominence_rel) {
# Implementation of algorithm_c_and_d function
#}
