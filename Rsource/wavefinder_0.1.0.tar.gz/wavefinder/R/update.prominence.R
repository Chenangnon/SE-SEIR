
update_prominence <- function (object, endpoints, ...) {

  # Include starting and end points of the original data series
  object <- object[, c("location", "peak_ind", "y_position", "prominence")]
  object <- rbind (object, endpoints)
  object <- object[order(object$location), ]

  # index of peaks in object
  peak_index <- which(object$peak_ind == 1)

  # Stating point of peaks
  peak_start <- object$location[peak_index - 1]

  # Compute prominence values
  prominences <- object$y_position[peak_index] - pmax(object$y_position[peak_index - 1],
                                                      object$y_position[peak_index + 1])

  # Store in object
  object$prominence <- NA # NAs for troughs
  object$prominence[peak_index] <- prominences

  # Remove endpoints
  object <- object[- c(1, nrow(object)), , drop = FALSE]

  return(object)

}

# Deprecated codes: calls 'find_peaks' twice when none is required
update.prominence0 <- function (object, endpoints, ...) {

  # Include starting and end points of the original data series
  object <- object[, c("location", "peak_ind", "y_position", "prominence")]
  object <- rbind (object, endpoints)
  object <- object[order(object$location), ]

  # Use 'find_peaks' to identify peaks and troughs, and compute prominence values
  y_vals <- object$y_position
  peak <- find_peaks (y_vals, prominence = NULL, distance = NULL)
  trough <- find_peaks (-y_vals, prominence = NULL, distance = NULL)
  results <- reframe.prominence (object,
                                 peak=peak$peak,
                                 peak_properties = peak,
                                 trough = trough$peak,
                                 trough_properties = trough)
  return(results)

}

# Deprecated codes: only used by 'update.prominence0' which deprecated
# Format results when updating prominence values. Deprecated now
reframe.prominence <- function (data, peak, peak_properties, trough, trough_properties) {
  data <- as.data.frame(data)

  if (length(peak)) {
    peaks <- data[peak, ]
    peaks$prominence <- peak_properties$prominence
    peaks$peak_ind <- 1

    results <- peaks
  }
  else
    results <- NULL

  if (length(trough)) {
    troughs <- data[trough, ]
    troughs$prominence <- trough_properties$prominence
    troughs$peak_ind <- 0
    results <- rbind(results, troughs)
  }

  if (NROW(results)) {
    results <- results[order(results$location), ]
    rownames(results) <- NULL
  }

  return(results)
}
