function [Npos, dlogNpos, rate, exp_eta] = RBnewpositives0 (t, rho_d, tau, omega, nu, K, eps)
%% New positive cases from a Bertalanffy-Richards growth curve-based prevalence

% Here, the curve of infectives is assumed to be a BR growth curve and the
% curve of new positives is derived from that curve.

%% Inputs
% t       = time points at which growth rate ... are desired
% rho_d   = removal rate from the class of detected cases
% tau     = time offset, determines the growth rate at time t = 0
% omega   = intrisic growth rate (>0)
% nu      = shape parameter of the Richards growth curve (>0); nu = 1 <==> logistic growth 

%% Outputs
% rate       = growth rate ( ~ Id )
% drate      = growth acceleration
% exp_eta = exponential of the negative of the linear predictor in the growth curve

%% Default arguments
if nargin == 4
    nu = 1 ;
    K = 1 ;
    eps = 0; %0.00001 ;
elseif nargin == 5
    K = 1 ;
    eps = 0 ;
elseif nargin ==  6
    eps = 0 ;
end

if nu * omega >= rho_d
    error("nu * omega < rho_d does not hold.")
end

%% Function body
exp_eta = exp(-nu .* omega .* (t - tau)) ;

rate = K .* omega .* exp_eta ./ ( (1 + exp_eta).^((nu+1)./nu) ) ;

rel_acc = nu .* omega .* ( ((nu+1)./nu) .* exp_eta ./ (1 + exp_eta) - 1 ) ;

Npos = (rho_d + rel_acc) .* rate ;

dlogNpos = - nu .* (nu + 1) .* (omega.^2) .* exp_eta ./ (1 + exp_eta).^2 ;

zeropos = rate <= eps ;

dlogNpos = dlogNpos ./ (rho_d + rel_acc) + rel_acc ;

dlogNpos(zeropos) = zeros(sum(zeropos), 1) ;

end