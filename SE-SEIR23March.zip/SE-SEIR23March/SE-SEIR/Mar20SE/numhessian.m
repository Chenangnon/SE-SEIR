%% Calculate Numerical Hessian Matrix
% Calculate a numerical approximation to the Hessian matrix of a scalar 
% valued function at a sigle parameter vector value using 'Richardson'
% method.
function H = numhessian (func, x, d, r, v, eps, zero_tol)
% This is a reproduction of the 'hessian' function from the R package
% 'numDeriv'. All function evaluations are performed by the child routine
% 'genD' which generate Bates and Watts D Matrix.
        if 1 ~= length(func(x))
            error("The function 'func' must be scalar valued.")
        end
        
        % Set default parameter values
        if nargin<3
            d = 0.1;
            r = 4 ; 
            v = 2 ; 
            eps = 1e-4 ;
            zero_tol = 1.781029e-05;
        elseif nargin == 3
            r = 4 ; 
            v = 2 ; 
            eps = 1e-4 ;
            zero_tol = 1.781029e-05;
        elseif nargin == 4
            v = 2 ; 
            eps = 1e-4 ;
            zero_tol = 1.781029e-05;
        elseif nargin == 5
            eps = 1e-4 ;
            zero_tol = 1.781029e-05;
        elseif nargin == 6
            zero_tol = 1.781029e-05;
        end
        
        % Initialize computations
        nvars = length(x);
        D = genD(func, x, d, r, v, eps, zero_tol);
        if 1 ~= size(D,1)
            error("E bou ali!")
        end
        H = zeros(nvars, nvars);
        u = nvars;
        iv = 1:nvars;
        
        % Computations
        for i = iv
            for j = 1:i
                u = u + 1;
                H(i,j) = D(:,u);
            end
        end
        H = H + H';
        H(sub2ind([nvars, nvars], iv, iv)) = diag(H)/2;
end
