function [m, C, P, Q, eta] = Testmi_t (PlotC, PlotPQ)

%%
m0 = [0.15 0.15 0.15]';
alpha = [1 1 1]';
delta = log(1./ (m0.^alpha) - 1) ;
ap = [20 20 20]' ;
aq = [0   2  0]' ;
up = [0   0  0]' ;
uq = [0   0  5]' ;
v =  [0   5  5]' ;

%ap = [30 15 0]' ;
%aq = [0 15 30]' ;

%%
if nargin == 0
    PlotC = 0 ;
    PlotPQ = 0 ;
elseif nargin == 1
    PlotPQ = 0 ;
end

N = 100000 ;
tauC = 60;
maxt = (2 * tauC) ;
omegaC = 1/10;
nuC = 1;
KC = 1;
rho_d = omegaC * nuC + 0.01; %  have rho_d > omegaC * nuC  to ensure P is never too high, like 50%!

%%
t = ((0):0.1:maxt)' ;

[P, Q, C, ~] = RBnewpositives (t, rho_d, tauC, omegaC, nuC, KC) ;
C = N.* C ;
%display(C)

[m, eta] = mi_t(P, Q, alpha, delta, ap, aq, up, uq, v);

%% Plot New positives
if PlotC
    figure ('Name' , 'New positives')
    FC = plot(t, C) ;
    FC.Color = [0 0 0]; %  Black
    FC.LineWidth = 1.5;
    hold on
    grid on
end

%% Plot of P and Q
if PlotPQ
    figure ('Name' , 'P and Q')
    Fp = plot(t, P) ;
    Fp.Color = [0 0 0]; % Black
    Fp.LineWidth = 1.5;
    hold on 
    Fq = plot(t, Q) ;
    Fq.Color = [0 0 0]; %  Black
    Fq.LineWidth = 1.5;
    Fq.LineStyle = "--" ;
    hold on
    grid on
end

%Fe = plot(t, eta(:,1)) ;
%Fe.Color = [0 0 0]; %  Black
%Fe.LineWidth = 1.5;
%hold on

figure ('Name' , 'm vs t')
Fm1 = plot(t, m(:,1)) ;
Fm1.Color = [0 0 1]; % Blue
Fm1.LineWidth = 1.5;
hold on

Fm3 = plot(t, m(:,2)) ;
Fm3.Color = [0.3010 0.7450 0.9330]; % Light Blue
Fm3.LineWidth = 1.5;
hold on

Fm3 = plot(t, m(:,3)) ;
Fm3.Color = [1 0 0]; % Red
Fm3.LineWidth = 1.5;
hold on

grid on
% xlabel("{\it t} (day)")
% ylim([-0.2, 1])
%ylabel(strcat('${\mathcal{R}_{-1}(t), \mathcal{R}_{1}(t), \mathcal{R}(t)}$'), 'Interpreter','latex')
%legend('$\mathcal{R}_{-1}(t)$', '$\mathcal{R}_{1}(t)$', '$\mathcal{R}(t) = \mathcal{R}_{-1}(t) + \mathcal{R}_{1}(t)$', 'Interpreter','latex')

figure ('Name' , 'm vs P')
Fm1 = plot(P, m(:,1)) ;
Fm1.Color = [0 0 1]; % Blue
Fm1.LineWidth = 1.5;
hold on

Fm3 = plot(P, m(:,2)) ;
Fm3.Color = [0.3010 0.7450 0.9330]; % Light Blue
Fm3.LineWidth = 1.5;
hold on

Fm3 = plot(P, m(:,3)) ;
Fm3.Color = [1 0 0]; % Red
Fm3.LineWidth = 1.5;
hold on

grid on

end