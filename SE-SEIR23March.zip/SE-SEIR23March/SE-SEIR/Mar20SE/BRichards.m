function [rate, drate, exp_eta] = BRichards (t, tau, omega, nu, K)
%% Bertalanffy-Richards growth curve

%% Inputs
% t       = time points at which growth rate ... are desired
% tau     = time offset, determines the growth rate at time t = 0
% omega   = intrisic growth rate (>0)
% nu      = shape parameter of the Richards growth curve (>0); nu = 1 <==> logistic growth 

%% Outputs
% rate       = growth rate
% drate      = growth acceleration
% exp_eta = exponential of the negative of the linear predictor in the growth curve

%% Default arguments
if nargin == 3
    nu = 1 ;
    K = 1 ;
elseif nargin == 4
    K = 1 ;
end

%% Function body
exp_eta = exp(-nu .* omega .* (t - tau)) ;

rate = K .* omega .* exp_eta ./ ( (1 + exp_eta).^((nu+1)./nu) ) ;

drate = nu .* omega .* ( ((nu+1)./nu) .* exp_eta ./ (1 + exp_eta) - 1 ) .* rate ;

end