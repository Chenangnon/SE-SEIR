function [Npos, dlogNpos, rate, drate, ddrate, size, z] = KBnewpositives (t, rho_d, tmin, tau, shape1, shape2, K)
%% New positive cases from a Kumaraswamy Beta growth curve-based prevalence

% NOT OK

%% Inputs
% t               = time points at which growth rate ... are desired
% tmin            = time offset, minimum time point
% tau             = time frame (must be > 0), distance from tmin to maximum time point
% shape1,shape2   = shape parameters (must be > 1) of the growth curve
% K               = Final population size (must be > 0)
%% Outputs
% rate       = growth rate
% drate      = growth acceleration
% exp_eta = exponential of the negative of the linear predictor in the growth curve


%%
if tau <= 0
   error("tau must be a positive scalar") 
end

if shape1 <= 1
   error("shape1 must be > 1") 
end

%% Default arguments
if nargin == 7
    if K <= 0
        error("K must be a positive scalar") 
    end
    if shape2 <= 1
        error("shape2 must be > 1") 
    end    
elseif nargin == 6
    if shape2 <= 1
        error("shape2 must be > 1") 
    end
    K = 1 ;
elseif nargin == 5
    shape2 = 1 ;
    K = 1 ;
end

%% Function body
z = (t - tmin) ./ tau ;
validz = (z > 0) + (z < 1) == 2 ;

size = validz + 0;
size(validz) = K .* ( 1 - (1 - z(validz).^shape1).^shape2 ) ;

rate = validz + 0;
rate(validz) = (K ./ tau) .* shape1 .* shape2 .* (z(validz).^(shape1 - 1)) .* ((1 - z(validz).^shape1).^(shape2 - 1)) ;

drate = rate;
drate(validz) = (K ./ tau.^2) .* shape1 .* shape2 .* (z(validz).^(shape1 - 2)) .* ((1 - z(validz).^shape1).^(shape2 - 2)) ;
drate(validz) = drate(validz) .* ( (shape1 - 1) .* (1 - z(validz)) - shape1 .* (shape2 - 1) .* z(validz) ) ;

Npos = rho_d .* rate + drate;

ddrate = rate;
ddrate(validz) = (shape1.^2) .* (shape2 - 1) .* (shape2 - 2) .* (z(validz).^(2 * shape1)) ;
ddrate(validz) = ddrate(validz) + (shape1 - 1) .* (shape1 - 2) .* (1 - z(validz).^shape1).^2 ;
ddrate(validz) = ddrate(validz) - 3 * (shape1 - 1) .* (shape2 - 1) .* (z(validz).^shape1) .* (1 - z(validz).^shape1) ;
ddrate(validz) = ddrate(validz) .* (K ./ tau.^3) .* shape1 .* shape2 .* (z(validz).^(shape1 - 3)) .* ((1 - z(validz).^shape1).^(shape2 - 3)) ;

dlogNpos = rho_d .* drate + ddrate;
end