function [Teval, XevalR, Pt, Ct, Qt, Id, Rept, Rept1, Rept_1, Rep0, S, m] = SolveB0SEIR(vparam, x0, Horizon, Ylim, PlotC)

% Extract parameters from the vector 'vparam'
[m0, beta_0, kappa, phi_a, phi_s, sigma, theta, pi, gamma_a, gamma_s, rho_a, rho_s, ~, N] = getB0SEIRparams(vparam);

if nargin == 3
    Ylim = N;
end

% Solve the differential system with no information available
Hsol = ode45(@(t,y) B0SEIR(t,y, vparam), [0, Horizon], x0);

%% Evaluate the solution at equally spaced points between t_0 and t_f
Teval = linspace(0.05,Horizon, 4*Horizon+1);
Xeval = deval(Hsol, Teval);

%% Get P and Q
Ct = pi .* theta .* Xeval(3,:) + gamma_a .* Xeval(4,:) + gamma_s .* Xeval(5,:);
Id = Xeval(6,:);

dotCt = gradient(Ct(:)) ./ gradient(Teval(:));
Pt = Id' ./ N;
Qt = dotCt ./ Ct(:);
Teval = Teval';
Xeval = Xeval';

%% Deduce R
R = N - sum(Xeval, 2);
XevalR = [Xeval, R];

%% Compute prophylactic proportions
S = sum(Xeval(:,1:2), 2) ;
m = sum(Xeval(:,1:2) .* m0, 2) ./ S ;

%% Compute reproduction numbers
Rep0 = beta_0 * (1 - pi) * (phi_a * (1 - sigma) / (gamma_a + rho_a) + phi_s * sigma / (gamma_s + rho_s));
Rept_1 = Rep0 .* Xeval(:,1) .* (1 - kappa * m0(:,1)) ./ (N - Xeval(:,6));
Rept1 = Rep0 .* Xeval(:,2) .* (1 - kappa * m0(:,2)) ./ (N - Xeval(:,6));
Rept = Rept_1 + Rept1;

%% Rescale Rept_1 and Rept1
Rept_1 = Rept_1 .* S ./ Xeval(:,1) ;
Rept1 = Rept1 .* S ./ Xeval(:,2) ;

%% Plot the solution and New positives
figure ('Name' , 'BSEIR')
sCt = plot(Teval, Xeval(:,1)) ;
sCt.Color = [0.3010 0.7450 0.9330]; % Degraded Blue
sCt.LineWidth = 1.5;
hold on
s1 = plot(Teval, Xeval(:,2));
s1.Color = [0 0 1]; % Blue
s1.LineWidth = 2.5;
hold on
E = plot(Teval, Xeval(:,3));
E.Color = [0.4940 0.1840 0.5560]; % Purpule like [0.6350 0.0780 0.1840]; % Brown?
E.LineWidth = 2.5;
hold on
Ia = plot(Teval, Xeval(:,4));
Ia.Color = [0.9290 0.6940 0.1250]; % Yellow like
Ia.LineWidth = 2.5;
Ia.LineStyle = ':';
hold on
Is = plot(Teval, Xeval(:,5));
Is.Color = [1 0 0]; % Red
Is.LineWidth = 2.5;
Is.LineStyle = '--';
hold on
Id = plot(Teval, Xeval(:,6));
Id.Color = [1 0 1]; % Magenta
Id.LineWidth = 2.5;
hold on
R = plot(Teval, R);
R.Color = [0.2 0.6740 0.1880]; % Green
R.LineWidth = 2.5;
hold on

if PlotC == 1
    grid on
    %grid minor
    xlabel("{\it t} (day)")
    ylabel(strcat("{\it S_{i}(t), E(t), I_{j}(t), R(t)}"))
    ylim([0 Ylim]) % ylim([0 max(max(XevalR))])
    yticks(100000 *[0 0.2 0.4 0.6 0.8 1])
    legend(["\it S_{-1}(t)", "\it S_{1}(t)", "\it E(t)", "\it I_{a}(t)", "\it I_{s}(t)", "\it I_{d}(t)", "\it R(t)"])


    %% Plot New positives
    figure ('Name' , 'New positives')
    sCt = plot(Teval, Ct) ;
    sCt.Color = [0 0 0]; % Black
    sCt.LineWidth = 1.5;
    hold on

    maxC = N * ceil(1000 * max(Ct) / N) / 1000;

    grid on
    %grid minor
    xlabel("{\it t} (day)")
    ylabel(strcat("{\it C(t)}"))
    ylim([0 maxC]) % ylim([0 max(max(XevalR))])
    %yticks(100000 *[0 0.2 0.4 0.6 0.8 1])
    legend("\it New positives")

else
    sCt = plot(Teval, Ct) ;
    sCt.Color = [0 0 0]; % Black
    sCt.LineWidth = 1.5;
    hold on
    grid on
    %grid minor
    xlabel("{\it t} (day)")
    ylabel(strcat("{\it S_{i}(t), E(t), I_{j}(t), R(t), C(t)}"))
    ylim([0 Ylim]) % ylim([0 max(max(XevalR))])
    yticks(100000 *[0 0.2 0.4 0.6 0.8 1])
    legend(["\it S_{-1}(t)", "\it S_{1}(t)", "\it E(t)", "\it I_{a}(t)", "\it I_{s}(t)", "\it I_{d}(t)", "\it R(t)", "\it C(t)"])

end

%% Plot Prevalence
figure ('Name' , 'Prevalence')
sp = plot(Teval, Pt); % scatter(P, m_i(:,1),10,"filled", "blue", 'LineWidth',2) ;
sp.Color = [0 0 0]; % Black
sp.LineWidth = 1.5;
%sp.LineStyle = ':';
hold on
sq = plot(Teval, Qt); 
sq.Color = [0 0 0]; % Black
sq.LineWidth = 2.5;
sq.LineStyle = ':';
%sq.LineStyle = '-.';
hold on
grid on
%grid minor
xlabel("{\it t} (day)")
ylabel(strcat("{\it P(t), Q(t)}"))

ytick = 0:0.05:1; % [0 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1] ;
seltick = ytick < max(max(Pt), 0.1) ;
yticks(ytick)
ylim([min(Qt) ytick(sum(seltick) + 1)])
legend(["\it P(t)", "\it Q(t)", ])

%% Plot Reproduction number
figure ('Name' , 'Reproduction number')
s_R_1 = plot(Teval, Rept_1) ;
s_R_1.Color = [0.3010 0.7450 0.9330]; % Light Blue
s_R_1.LineWidth = 1.5;
hold on
s_R1 = plot(Teval, Rept1) ;
s_R1.Color = [0 0 1]; %  Blue
s_R1.LineWidth = 1.5;
hold on
s_R = plot(Teval, Rept) ;
s_R.Color = [0 0 0]; %  Black
s_R.LineWidth = 1.5;
hold on
grid on
xlabel("{\it t} (day)")
ylabel(strcat('${\mathcal{R}_{-1}(t), \mathcal{R}_{1}(t), \mathcal{R}(t)}$'), 'Interpreter','latex')
legend('$\mathcal{R}_{-1}(t)$', '$\mathcal{R}_{1}(t)$', '$\mathcal{R}(t) = \frac{S_{-1}(t)}{S(t)} \mathcal{R}_{-1}(t) + \frac{S_{1}(t)}{S(t)} \mathcal{R}_{1}(t)$', 'Interpreter','latex')

end