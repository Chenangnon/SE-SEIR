function xdot = B0SEIR(~,x,vparam) % B0SEIR(t,x,vparam)
%% Differential system of equations when there is no information (t <= 0)

% Real state variables
S_1 = x(1);
S1 = x(2);
E = x(3);
Ia = x(4);
Is = x(5);
Id = x(6);

% Extract parameters from the vector 'vparam'
[m0, beta_0, kappa, phi_a, phi_s, sigma, theta, pi, gamma_a, gamma_s, rho_a, rho_s, rho_d, N] = getB0SEIRparams(vparam);

% Total mixing population
NId = N - Id;

% Compute contact rates
beta_ia = beta_0 * (1 - kappa .* m0) * phi_a;
beta_is = beta_0 * (1 - kappa .* m0) * phi_s;

% Compute forces of infection
lambda_1 = (beta_ia(1) * Ia + beta_is(1) * Is) / NId;
lambda1  = (beta_ia(2) * Ia + beta_is(2) * Is) / NId;

% Initialize 'xdot'
xdot = zeros(6,1);

% Differential equations
xdot(1)= - lambda_1 .* S_1;                                               % dot{S}_1
xdot(2)= - lambda1 .* S1;                                                 % dot{S}1
xdot(3)= - xdot(1) - xdot(2) - theta .* E;                                % dot{E}
xdot(4)= (1 - sigma) .* (1 - pi) .* theta .* E - (gamma_a + rho_a) .* Ia; % dot{I}a
xdot(5)= sigma .* (1 - pi) .* theta .* E - (gamma_s + rho_s) .* Is;       % dot{I}s
xdot(6)= pi .* theta .* E + gamma_a .* Ia + gamma_s .* Is - rho_d .* Id;  % dot{I}d
end